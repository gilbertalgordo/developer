#!/bin/bash
# ========================================================
# Turntable & Remix Equalizer HUD - Linux Desktop Launcher
# Compatible with Ubuntu, Debian, Fedora, Arch, SteamOS
# Engineered by Gilbert Algordo
# ========================================================

echo "[TURNTABLE HUD] Launching Linux Standalone Desktop App..."
APP_URL="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"

if command -v google-chrome &> /dev/null; then
    google-chrome --app="$APP_URL" &
elif command -v chromium-browser &> /dev/null; then
    chromium-browser --app="$APP_URL" &
elif command -v chromium &> /dev/null; then
    chromium --app="$APP_URL" &
elif command -v brave-browser &> /dev/null; then
    brave-browser --app="$APP_URL" &
elif command -v xdg-open &> /dev/null; then
    xdg-open "$APP_URL" &
else
    echo "Please open your web browser and visit: $APP_URL"
fi
