# ========================================================
# Turntable & Remix Equalizer HUD - Desktop Shortcut Installer
# Engineered by Gilbert Algordo
# ========================================================

Write-Host "Installing Turntable & Remix Equalizer HUD Desktop Shortcut..." -ForegroundColor Cyan

$WshShell = New-Object -comObject WScript.Shell
$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$ShortcutPath = Join-Path -Path $DesktopPath -ChildPath "Turntable & Remix HUD.lnk"

# Look for Edge or Chrome
$EdgePath = $env:ProgramFiles + '\Microsoft\Edge\Application\msedge.exe'
$ChromePath = $env:ProgramFiles + '\Google\Chrome\Application\chrome.exe'

$TargetExe = ""
if (Test-Path $EdgePath) {
    $TargetExe = $EdgePath
} elseif (Test-Path $ChromePath) {
    $TargetExe = $ChromePath
} else {
    $TargetExe = "msedge.exe"
}

$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetExe
$Shortcut.Arguments = "--app=https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
$Shortcut.Description = "Turntable & Remix Sound Equalizer HUD - Gilbert Algordo"
$Shortcut.Save()

Write-Host "SUCCESS! Shortcut created on your Desktop: $ShortcutPath" -ForegroundColor Green
Write-Host "Double-click 'Turntable & Remix HUD' to launch as a standalone desktop app!" -ForegroundColor Yellow
Start-Sleep -Seconds 3
