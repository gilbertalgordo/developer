#!/bin/bash
# ========================================================
# Turntable & Remix Equalizer HUD - macOS Desktop Launcher
# Engineered by Gilbert Algordo
# ========================================================

echo "=== Turntable & Remix Equalizer HUD ==="
echo "Opening in Dedicated App Window on macOS..."

APP_URL="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"

if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args --app="$APP_URL"
elif [ -d "/Applications/Brave Browser.app" ]; then
    open -na "Brave Browser" --args --app="$APP_URL"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    open -na "Microsoft Edge" --args --app="$APP_URL"
else
    # Fallback to Safari
    open "$APP_URL"
fi
