# Turntable & Remix Sound Equalizer HUD - Cross-Platform Installation Guide
Engineered by Gilbert Algordo | Profile: https://g.dev/gilbert_algordo

This package contains automated launchers, desktop shortcuts, and offline runners for Windows, macOS, Linux, Android, and iOS.

---

## 1. WINDOWS (Windows 10 & Windows 11)

### Option A: 1-Click Desktop Launcher
- Double-click `Launch-Windows.bat`.
- This immediately opens the app in a sleek, borderless native window without browser address bars!

### Option B: Create Desktop Shortcut (PowerShell)
- Right-click `Install-Windows-Desktop-Shortcut.ps1` and select **Run with PowerShell**.
- A desktop shortcut called **"Turntable & Remix HUD"** will be created directly on your Windows desktop.

### Option C: Native PWA Install via Browser
- Open Chrome or Edge.
- Look at the right side of the address bar for the **Install App** icon (monitor with a down-arrow).
- Click **Install** to add the application to your Windows Start Menu and Taskbar.

---

## 2. macOS (Sonoma, Ventura, Monterey, etc.)

### Option A: Shell Launcher
1. Open Terminal and navigate to this folder:
   ```bash
   chmod +x Launch-macOS.command
   ```
2. Double-click `Launch-macOS.command` in Finder to launch in dedicated app window.

### Option B: Safari 17+ "Add to Dock" (Native Mac App)
1. In Safari, visit: `https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D`
2. Click **File** in the top Mac menu bar.
3. Select **Add to Dock...**
4. Click **Add**. The Turntable HUD is now a real macOS app in your Dock and Launchpad!

---

## 3. LINUX (Ubuntu, Debian, Fedora, Arch, SteamOS)

### Option A: Shell Script
1. Make the script executable:
   ```bash
   chmod +x Launch-Linux.sh
   ./Launch-Linux.sh
   ```

### Option B: Desktop Integration
1. Copy `turntable-hud.desktop` to your applications directory:
   ```bash
   cp turntable-hud.desktop ~/.local/share/applications/
   chmod +x ~/.local/share/applications/turntable-hud.desktop
   ```
2. Search for "Turntable" in your application menu (GNOME, KDE, App Launcher).

---

## 4. ANDROID (Phones & Tablets)

### Native WebAPK Installation:
1. Open Google Chrome, Brave, or Samsung Internet on your Android device.
2. Navigate to: `https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D`
3. Tap the in-app **"INSTALL APP"** button, or tap the three dots **(⋮)** in Chrome and tap **"Install app"** or **"Add to Home screen"**.
4. The system will create a native WebAPK with full offline audio DSP cache and hardware acceleration!

---

## 5. iOS & iPadOS (iPhone & iPad)

### Apple Safari Standalone Home Screen App:
1. Open Safari on iPhone or iPad and navigate to: `https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D`
2. Tap the **Share** button (box with an arrow pointing up at the bottom/top of Safari).
3. Scroll down and tap **"Add to Home Screen"** (+ icon).
4. Tap **Add** in the top right corner.
5. Launch from your home screen. It will run in full-screen standalone mode without any browser URL bar or navigation buttons!

---

## 6. OFFLINE STANDALONE RUNNER
- Open `offline-runner.html` directly in any browser on any PC without an internet connection.
- Includes embedded Web Audio DSP synth, drum machine, 3-band equalizer, and audio scratch engine!
