@echo off
title Turntable & Remix Equalizer HUD - Windows Launcher
color 0b
echo ========================================================
echo  TURNTABLE & REMIX EQUALIZER HUD v3.5
echo  Engineered by Gilbert Algordo
echo  Launching in Dedicated Standalone Desktop App Mode...
echo ========================================================

:: Check for Google Chrome
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
    exit
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
    exit
)

:: Check for Microsoft Edge
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
    exit
)

:: Fallback to default browser
echo Opening in default browser...
start "" "https://ais-dev-lrzfvhms5v47jxlrwciwm4-274403024452.asia-southeast1.run.app/?__aistudio_auth_token=Bagt8TFdpoQxvk2lYxowCstKjGB8GPGYTSHkC3sUfvQ%3D"
exit
