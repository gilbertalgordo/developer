# Active AI for Google Search Console (Pro Edition)

**Engineered by Gilbert Algordo**  
[Developer Profile](https://g.dev/gilbert_algordo)

## Features
- Real-time Active AI Agent HUD overlay on Google Search Console
- Shadow DOM isolation preventing style leakage
- Automated CTR and query cannibalization telemetry
- Fast Manifest V3 Service Worker architecture

## Quick Install
1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** in the top right corner
3. Click **Load unpacked** and select the `active-ai-gsc-pro` folder
4. Open Google Search Console (`https://search.google.com/search-console/`) to see the Active AI HUD!