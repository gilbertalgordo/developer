// Active AI Service Worker - Background Runtime & Auto-Update Engine
chrome.runtime.onInstalled.addListener((details) => {
  console.log("[Active AI Core] Initialized successfully. Author: https://g.dev/gilbert_algordo", details);
  chrome.storage.local.set({ 
    aiStatus: "active", 
    version: "2.0.0", 
    installedAt: Date.now(),
    autoUpdateEnabled: true,
    lastUpdateCheck: Date.now()
  });

  // Set up periodic auto-update alarm (every 60 minutes)
  if (chrome.alarms) {
    chrome.alarms.create("active-ai-update-check", { periodInMinutes: 60 });
  }
});

// Periodic Auto-Update Alarm Listener
if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "active-ai-update-check") {
      console.log("[Active AI Auto-Update] Running scheduled version check...");
      if (chrome.runtime.requestUpdateCheck) {
        chrome.runtime.requestUpdateCheck((status, details) => {
          console.log("[Active AI Auto-Update] Update status:", status, details);
          chrome.storage.local.set({ lastUpdateCheck: Date.now(), updateStatus: status });
        });
      }
    }
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTelemetry") {
    // Handle secure background operations or API sync bridges
    chrome.storage.local.get(["aiStatus", "telemetryLogs", "autoUpdateEnabled", "lastUpdateCheck"], (data) => {
      sendResponse({
        status: "success",
        telemetry: "Active telemetry nominal",
        storedState: data.aiStatus || "active",
        autoUpdate: data.autoUpdateEnabled ?? true,
        lastUpdateCheck: data.lastUpdateCheck,
        timestamp: new Date().toISOString()
      });
    });
    return true; // Keep message channel open for async response
  }
  if (request.action === "triggerUpdateCheck") {
    if (chrome.runtime.requestUpdateCheck) {
      chrome.runtime.requestUpdateCheck((status, details) => {
        sendResponse({ status, details, checkedAt: new Date().toISOString() });
      });
      return true;
    }
    sendResponse({ status: "no_update", checkedAt: new Date().toISOString() });
  }
  if (request.action === "logAnomaly") {
    console.warn("[Active AI Anomaly]", request.data);
    sendResponse({ received: true });
  }
});