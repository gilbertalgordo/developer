(function () {
  'use strict';

  const DEVELOPER_PROFILE = "https://g.dev/gilbert_algordo";
  console.log(`[Active AI Engine] Injected into Google Search Console. Verified profile: ${DEVELOPER_PROFILE}`);

  // Inject user interface module via Shadow DOM to prevent CSS conflicts
  function injectUI() {
    if (document.getElementById('active-ai-root')) return;

    const container = document.createElement('div');
    container.id = 'active-ai-root';
    container.style.position = 'fixed';
    container.style.bottom = '24px';
    container.style.right = '24px';
    container.style.zIndex = '999999';

    const shadow = container.attachShadow({ mode: 'open' });
    
    const styleLink = document.createElement('style');
    styleLink.textContent = `
      .ai-hud-card {
        background: rgba(15, 23, 42, 0.95);
        color: #f8fafc;
        padding: 16px;
        border-radius: 12px;
        font-family: system-ui, -apple-system, sans-serif;
        width: 320px;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(56, 189, 248, 0.4);
        backdrop-filter: blur(12px);
        transition: all 0.2s ease-in-out;
      }
      .ai-hud-card:hover {
        border-color: rgba(56, 189, 248, 0.8);
      }
      .ai-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 8px;
        margin-bottom: 10px;
      }
      .ai-title { font-size: 13px; font-weight: 700; color: #38bdf8; letter-spacing: 0.5px; }
      .ai-badge { background: #0284c7; color: #fff; font-size: 9px; padding: 2px 6px; border-radius: 99px; font-weight: 600; text-transform: uppercase; }
      .ai-body { font-size: 11px; color: #cbd5e1; line-height: 1.5; }
      .ai-stats { display: flex; gap: 8px; margin-top: 8px; font-size: 10px; color: #94a3b8; }
      .ai-stat-pill { background: rgba(255,255,255,0.06); padding: 4px 8px; border-radius: 6px; }
      .ai-footer { margin-top: 10px; font-size: 9px; color: #64748b; border-top: 1px solid rgba(255, 255, 255, 0.05); padding-top: 6px; display: flex; justify-content: space-between; }
      .ai-footer a { color: #38bdf8; text-decoration: none; font-weight: 500; }
      .ai-footer a:hover { text-decoration: underline; }
    `;

    const widget = document.createElement('div');
    widget.className = 'ai-hud-card';
    widget.innerHTML = `
      <div class="ai-header">
        <span class="ai-title">ACTIVE AI AGENT</span>
        <span class="ai-badge">ONLINE</span>
      </div>
      <div class="ai-body">
        Monitoring Google Search Console interface indices, anomaly tracking, and automated performance diagnostics.
      </div>
      <div class="ai-stats">
        <div class="ai-stat-pill">⚡ Index Radar: Active</div>
        <div class="ai-stat-pill">🔍 CTR Audit: Live</div>
      </div>
      <div class="ai-footer">
        <span>Active AI Core v2.0</span>
        <span>By <a href="https://g.dev/gilbert_algordo" target="_blank">Gilbert Algordo</a></span>
      </div>
    `;

    shadow.appendChild(styleLink);
    shadow.appendChild(widget);
    document.body.appendChild(container);
  }

  // Target initialization loop for Single Page Application navigation changes
  const observer = new MutationObserver(() => {
    if (window.location.href.includes('search-console')) {
      injectUI();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    injectUI();
  }
})();