// Active AI Extension Popup Controller
console.log("Popup active state loaded for Active AI Pro.");

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const currentTab = tabs[0];
  if (currentTab && currentTab.url && currentTab.url.includes("search-console")) {
    console.log("[Active AI] Currently active on Search Console tab:", currentTab.url);
  }
});