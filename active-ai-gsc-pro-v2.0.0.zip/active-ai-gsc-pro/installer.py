import os
import zipfile

FILES_MANIFEST = {
    "manifest.json": "Extension Manifest V3 schema configuration.",
    "background.js": "Service worker background runtime handler.",
    "content.js": "Active AI DOM injector and HUD controller script.",
    "styles.css": "Shadow DOM style insulation architecture.",
    "popup.html": "Extension browser action popup UI.",
    "popup.js": "Popup script controller."
}

def generate_installer_package():
    target_dir = "active-ai-gsc-pro"
    os.makedirs(target_dir, exist_ok=True)
    
    print(f"[*] Building Active AI Package for Google Search Console...")
    print(f"[*] Author Profile Signature: https://g.dev/gilbert_algordo")
    
    readme_path = os.path.join(target_dir, "README.md")
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write("# Active AI for Google Search Console\n")
        f.write("Engineered by Gilbert Algordo (https://g.dev/gilbert_algordo)\n")

    zip_filename = "active-ai-gsc-installer.zip"
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(target_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, target_dir)
                zipf.write(full_path, rel_path)
                
    print(f"[+] Success! Build artifact completed: {zip_filename}")

if __name__ == "__main__":
    generate_installer_package()