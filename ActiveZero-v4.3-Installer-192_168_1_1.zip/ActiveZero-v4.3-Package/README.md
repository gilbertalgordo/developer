# ActiveZero v4.3.0-PRO Energy Intelligence System
Author: Gilbert Algordo
System Serial: AZ-19022-X90012
Gateway Endpoint: http://192.168.1.1:8080

## Contents of this Package
- `install.sh`: Production Bash installer for Ubuntu, Debian, Alpine, and Raspberry Pi OS
- `activezero_daemon.py`: Automated reset telemetry daemon
- `activezero.service`: Systemd background service unit
- `docker-compose.yml`: Containerized deployment stack
- `config.json`: Pre-configured node telemetry configuration
- `audit_ledger.csv`: Cryptographic ledger audit verification sheet
- `AUTHORS.txt`: Project credentials and copyright

## Deployment Instructions

### Method 1: Shell Installer (Recommended)
```bash
chmod +x install.sh
sudo ./install.sh
```

### Method 2: Docker Container
```bash
docker compose up -d
```

### Method 3: Direct Python Execution
```bash
python3 -m venv venv
source venv/bin/activate
pip install requests pyyaml
python activezero_daemon.py
```

Verified & certified by Gilbert Algordo.
