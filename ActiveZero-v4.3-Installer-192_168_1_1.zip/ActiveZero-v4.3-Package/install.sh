#!/usr/bin/env bash
# ==============================================================================
# ActiveZero Energy Intelligence System - Production Node Installer
# Version: 4.3.0-PRO
# Author: Gilbert Algordo
# Gateway Target: 192.168.1.1:8080
# ==============================================================================

set -euo pipefail

echo "========================================================"
echo " ActiveZero v4.3.0 Energy Intelligence System Installer"
echo " Author: Gilbert Algordo"
echo " Gateway Endpoint: http://192.168.1.1:8080"
echo "========================================================"

INSTALL_DIR="/opt/activezero"
echo "[1/4] Creating installation directory at ${INSTALL_DIR}..."
sudo mkdir -p "${INSTALL_DIR}"
sudo cp activezero_daemon.py "${INSTALL_DIR}/"
sudo cp config.json "${INSTALL_DIR}/"

echo "[2/4] Setting up Python virtual environment..."
python3 -m venv "${INSTALL_DIR}/venv"
"${INSTALL_DIR}/venv/bin/pip" install --upgrade pip requests pyyaml

echo "[3/4] Installing systemd service..."
sudo cp activezero.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable activezero.service

echo "[4/4] Starting ActiveZero daemon..."
sudo systemctl restart activezero.service

echo "ACTIVEZERO NODE DEPLOYED SUCCESSFULLY."
echo "Serial: AZ-19022-X90012 | Gateway: 192.168.1.1:8080"
