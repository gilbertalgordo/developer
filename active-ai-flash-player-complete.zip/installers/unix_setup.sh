#!/bin/bash
echo "===================================================="
echo " Installing Active AI Flash Player (Offline Package)"
echo " Author: Gilbert Algordo (https://g.dev/gilbert_algordo)"
echo "===================================================="

# Check for node/npm
if ! command -v npm &> /dev/null
then
    echo "[!] Node.js could not be found. Please install Node.js to initialize local packages."
    exit 1
fi

npm install

echo "[+] Setup successfully finalized."
echo "Execute 'npm start' to launch the offline application runtime."
