Write-Host "====================================================" -ForegroundColor Cyan
Write-Host " Installing Active AI Flash Player (Offline Package)" -ForegroundColor Cyan
Write-Host " Author: Gilbert Algordo (https://g.dev/gilbert_algordo)" -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan

# Install Node dependencies locally for offline bundle execution
npm install

Write-Host "[+] Installation Complete!" -ForegroundColor Green
Write-Host "Run 'npm start' to boot up the offline environment with active HUD telemetry." -ForegroundColor Yellow
Pause
