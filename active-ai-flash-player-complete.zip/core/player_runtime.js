/**
 * Active AI Flash Player - Offline Runtime Handler
 * Integrated with Ruffle WebAssembly engine & local canvas renderer
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

class FlashPlayerRuntime {
  constructor(containerElement, options = {}) {
    this.container = containerElement;
    this.targetFps = options.fps || 60;
    this.ruffle = null;
    this.player = null;
    this.state = 'idle';
  }

  async initRuffle() {
    if (window.RufflePlayer) {
      this.ruffle = window.RufflePlayer.newest();
      this.player = this.ruffle.createPlayer();
      this.container.innerHTML = '';
      this.container.appendChild(this.player);
      this.state = 'ready';
      return true;
    }
    return false;
  }

  async loadSwfBuffer(buffer) {
    if (!this.player) await this.initRuffle();
    if (this.player) {
      await this.player.load({ data: buffer });
      this.state = 'playing';
    }
  }

  pause() {
    if (this.player && typeof this.player.pause === 'function') {
      this.player.pause();
      this.state = 'paused';
    }
  }

  play() {
    if (this.player && typeof this.player.play === 'function') {
      this.player.play();
      this.state = 'playing';
    }
  }
}

if (typeof module !== 'undefined') {
  module.exports = FlashPlayerRuntime;
}
