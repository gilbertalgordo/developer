/**
 * IPC Node-to-Python Bridge Handler
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */
const { spawn } = require('child_process');
const path = require('path');

class ActiveAIBridge {
  constructor(scriptPath) {
    this.scriptPath = scriptPath || path.join(__dirname, 'active_ai_core.py');
    this.worker = null;
    this.callbacks = [];
  }

  start() {
    this.worker = spawn('python', [this.scriptPath]);
    this.worker.stdout.on('data', (data) => {
      const lines = data.toString().trim().split('\n');
      lines.forEach((line) => {
        try {
          const parsed = JSON.parse(line);
          this.callbacks.forEach((cb) => cb(parsed));
        } catch (e) {
          console.warn('Bridge parse non-JSON:', line);
        }
      });
    });
    this.worker.stderr.on('data', (err) => console.error('Bridge STDERR:', err.toString()));
  }

  sendTelemetry(payload) {
    if (this.worker && this.worker.stdin.writable) {
      this.worker.stdin.write(JSON.stringify(payload) + '\n');
    }
  }

  onTelemetry(callback) {
    this.callbacks.push(callback);
  }

  stop() {
    if (this.worker) this.worker.kill();
  }
}

module.exports = ActiveAIBridge;
