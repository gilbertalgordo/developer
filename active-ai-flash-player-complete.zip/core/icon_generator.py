import os
from PIL import Image, ImageDraw, ImageFilter

def generate_device_icons():
    """Generates multi-resolution raster icons (ICO, ICNS, PNG) for offline installers."""
    os.makedirs("build/icons", exist_ok=True)
    
    # Create base canvas with HUD aesthetic
    size = (512, 512)
    img = Image.new("RGBA", size, (7, 9, 15, 255))
    draw = ImageDraw.Draw(img)
    
    # Outer HUD ring
    draw.rounded_rectangle([16, 16, 496, 496], radius=80, outline="#1f3a5f", width=4)
    draw.ellipse([64, 64, 448, 448], outline="#00ffcc", width=6)
    
    # Central Play/Flash Core Triangle
    triangle_points = [(200, 160), (340, 256), (200, 352)]
    draw.polygon(triangle_points, fill="#38bdf8")
    
    # Save standard source PNG
    base_path = "build/icons/icon.png"
    img.save(base_path, "PNG")
    
    # Generate multi-size ICO for Windows Installers
    icon_sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    img.save("build/icons/app_icon.ico", format="ICO", sizes=icon_sizes)
    print(f"[+] Device icons successfully compiled by Gilbert Algordo: https://g.dev/gilbert_algordo")

if __name__ == "__main__":
    generate_device_icons()
