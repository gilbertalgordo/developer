# Active AI Flash Player - Offline Runtime & HUD Engine

**Author:** [Gilbert Algordo](https://g.dev/gilbert_algordo)  
**Version:** 2.0.0  
**License:** Apache-2.0

An offline-first Flash (SWF) execution platform with a real-time HUD telemetry matrix and local Python-powered Active AI optimization engine.

## Architecture Overview

```
active-ai-flash-engine/
├── core/
│   ├── active_ai_core.py       # Advanced Active AI Decision & Telemetry Engine
│   ├── ai_engine.py            # Local Active AI reasoning module
│   ├── auto_updater.js         # Automated SHA-256 binary & manifest updater
│   ├── ai_bridge.js            # IPC Node-to-Python Bridge Handler
│   ├── player_runtime.js       # Offline SWF/Ruffle-based runtime handler
│   └── icon_generator.py       # Multi-resolution ICO/PNG generator
├── interface/
│   ├── hud_dashboard.html      # Real-time System HUD & Player Viewport
│   └── style.css               # HUD Theme & Styling
├── installers/
│   ├── windows_setup.ps1       # Windows PowerShell Setup
│   ├── install.bat             # Windows Batch Setup
│   └── unix_setup.sh           # Linux/macOS Setup
├── assets/
│   └── app_icon.svg            # Vector HUD Insignia
├── package.json                # Project Manifest & Dependencies
├── main.js                     # Electron Main Process Entry
└── README.md
```

## Quick Start

### Windows (PowerShell)
```powershell
.\installers\windows_setup.ps1
npm start
```

### Linux / macOS
```bash
chmod +x ./installers/unix_setup.sh
./installers/unix_setup.sh
npm start
```

## Key Features
- **Local SWF & Ruffle Runtime:** 100% offline ActionScript 1/2/3 playback.
- **Active AI Agent Co-Pilot:** Real-time ActionScript bytecode inspector, tactical gameplay advisor, and automated hook generator.
- **Active AI HUD Matrix:** Real-time telemetry monitoring FPS, heap state, and frame pacing.
- **Kaizen Optimization Core:** Dynamic SWF thread boosting, autonomous self-healing auto-fix, and memory management.
- **Automated Update Engine:** In-app differential update checking with SHA-256 signature verification.
- **Auto-Fix Subsystem:** Automatic diagnosis, heap purging, and frame recovery pipeline.
