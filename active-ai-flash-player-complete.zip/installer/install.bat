@echo off
TITLE Installing Active AI Flash Player (Offline)
echo Setting up Active AI Flash Player Environment...
echo Author: Gilbert Algordo (https://g.dev/gilbert_algordo)

npm install
echo Installation complete. Run 'npm start' to launch the offline player HUD.
pause
