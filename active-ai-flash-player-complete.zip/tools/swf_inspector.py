#!/usr/bin/env python3
"""
Active AI Flash Player - Offline SWF Inspector & Binary Analyzer
Decodes SWF tags, ABC bytecode blocks, and vector dictionary entries.
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
"""

import sys
import zlib
import struct
import json

class SWFInspector:
    TAG_NAMES = {
        0: "End",
        1: "ShowFrame",
        9: "SetBackgroundColor",
        14: "DefineSound",
        39: "DefineSprite",
        69: "FileAttributes",
        77: "Metadata",
        82: "DoABC",
        83: "DefineShape4",
    }

    def __init__(self, filepath: str):
        self.filepath = filepath

    def parse_header(self):
        with open(self.filepath, "rb") as f:
            magic = f.read(3).decode("ascii", errors="replace")
            version = struct.unpack("<B", f.read(1))[0]
            file_length = struct.unpack("<I", f.read(4))[0]
            payload = f.read()

        if magic == "CWS":
            payload = zlib.decompress(payload)

        return {
            "signature": magic,
            "version": version,
            "file_length": file_length,
            "compressed": magic in ["CWS", "ZWS"],
            "payload_bytes": len(payload)
        }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: python swf_inspector.py <path_to_swf>"}))
        sys.exit(1)
    inspector = SWFInspector(sys.argv[1])
    print(json.dumps(inspector.parse_header(), indent=2))
