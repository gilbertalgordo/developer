const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const { AutoUpdater } = require('./core/auto_updater');

let mainWindow;
let aiWorker;
let updater;

function bootstrapApp() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 850,
    backgroundColor: '#0a0e17',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'interface', 'hud_dashboard.html'));

  // Initialize the local background Active AI process
  aiWorker = spawn('python', [path.join(__dirname, 'core', 'active_ai_core.py')]);

  aiWorker.stdout.on('data', (data) => {
    mainWindow.webContents.send('ai-telemetry-push', data.toString());
  });

  aiWorker.stderr.on('data', (err) => {
    console.error(`AI Engine Error: ${err}`);
  });

  // Initialize Auto-Update Subsystem with g.dev upstream channel
  updater = new AutoUpdater({ currentVersion: '2.0.0' });
  updater.attachWindow(mainWindow);
  updater.startAutoUpdate();
}

app.whenReady().then(bootstrapApp);

app.on('window-all-closed', () => {
  if (updater) updater.stopAutoUpdate();
  if (aiWorker) aiWorker.kill();
  if (process.platform !== 'darwin') app.quit();
});
