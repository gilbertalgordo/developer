package com.gilbertalgordo.activeai.tv.core

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// -----------------------------------------------------------------
// Hardware & Software Over-The-Air Update Daemon
// -----------------------------------------------------------------
class HardwareSoftwareUpdater(private val context: Context) {
    suspend fun checkAndApplyOverTheAirPatches() {
        withContext(Dispatchers.IO) {
            // Evaluates remote firmware and repository update descriptors from https://github.com/gilbertalgordo
            Log.d("OTAUpdater", "Scanning remote repository manifests for hardware abstraction layer and app upgrades.")
        }
    }
}