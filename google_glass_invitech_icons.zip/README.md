# Google Glass Sports Shades (Invitech Icon Package)

Vector SVG icon suite and graphics generation package for Google Glass Sports Shades (Invitech Invisible Technology Edition).

## Included Icons
- `icons/icon_google_glass_shades.svg`: Complete sports eyewear frame rendering with invisible waveguide overlay.
- `icons/icon_hidden_hologram_emitter.svg`: Close-up of hidden optical projection engine inside eyewear holder hinge.
- `icons/icon_hud_telemetry_display.svg`: Holographic cycling HUD telemetry display icon (Speed, Cadence, HR).

## Links
- Developer Profile: https://g.dev/gilbert_algordo
- Source Configuration: https://github.com/gilbertalgordo/developer/blob/main/gem.yaml