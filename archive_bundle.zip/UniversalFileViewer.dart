import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:crypto/crypto.dart';

void main() {
  runApp(const AdvancedFileViewerApp());
}

class AdvancedFileViewerApp extends StatelessWidget {
  const AdvancedFileViewerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Advanced Universal File Viewer',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.cyanAccent,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const ViewerDashboard(),
    );
  }
}

class FileMetadata {
  final String name;
  final String path;
  final int sizeBytes;
  final String extension;
  final String sha256Hash;
  final String previewContent;
  final List<String> hexChunks;

  FileMetadata({
    required this.name,
    required this.path,
    required this.sizeBytes,
    required this.extension,
    required this.sha256Hash,
    required this.previewContent,
    required this.hexChunks,
  });
}

class ViewerDashboard extends StatefulWidget {
  const ViewerDashboard({super.key});

  @override
  State<ViewerDashboard> createState() => _ViewerDashboardState();
}

class _ViewerDashboardState extends State<ViewerDashboard> {
  bool _isLoading = false;
  FileMetadata? _metadata;
  File? _activeFile;
  int _selectedTab = 0; // 0: Preview, 1: Metadata & Hash, 2: Hex Inspector

  static Future<FileMetadata> _processFileInBackground(String filePath) async {
    final file = File(filePath);
    final bytes = await file.readAsBytes();
    final name = file.path.split('/').last;
    final extension = name.contains('.') ? name.split('.').last.toLowerCase() : '';
    
    final digest = sha256.convert(bytes);
    
    String content = '';
    if (['txt', 'json', 'md', 'csv', 'xml', 'html', 'log', 'dart', 'js', 'py'].contains(extension)) {
      try {
        content = utf8.decode(bytes);
      } catch (_) {
        content = 'Unable to decode text payload using UTF-8.';
      }
    }

    List<String> hexChunks = [];
    final limit = bytes.length > 512 ? 512 : bytes.length;
    for (int i = 0; i < limit; i += 16) {
      final chunk = bytes.sublist(i, i + 16 > limit ? limit : i + 16);
      final hexString = chunk.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
      final asciiString = chunk.map((b) => (b >= 32 && b <= 126) ? String.fromCharCode(b) : '.').join();
      hexChunks.add('${i.toRadixString(16).padLeft(4, '0')}:  ${hexString.padRight(48)}  [$asciiString]');
    }

    return FileMetadata(
      name: name,
      path: filePath,
      sizeBytes: bytes.length,
      extension: extension,
      sha256Hash: digest.toString(),
      previewContent: content,
      hexChunks: hexChunks,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Universal File Viewer HUD')),
      body: const Center(child: Text('Inspect files seamlessly.')),
    );
  }
}
