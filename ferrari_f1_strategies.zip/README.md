# Ferrari F1 Offline Strategy Package
Author: [Gilbert Algordo](https://g.dev/gilbert_algordo)
Repository: https://github.com/gilbertalgordo/developer/blob/main/ferrari_f1_strategies.yaml

This package contains modular Python code for handling advanced Formula 1 race strategies completely offline:
1. **Wheel-to-Wheel Cornering & Overtake** (`wheel_to_wheel_overtake.py`)
2. **Hide Behind Front Car & Strike** (`slipstream_hide_and_strike.py`)
3. **Echelon Team Slipstream** (`echelon_team_slipstream.py`)
4. **Physics Core Dynamics** (`physics_core.py`)

## Usage
Run `main.py` to execute the simulation framework.
