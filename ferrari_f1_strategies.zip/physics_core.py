# Advanced Vehicle Dynamics & Telemetry Engine
# Developer Profile: https://g.dev/gilbert_algordo

class F1VehicleDynamics:
    def __init__(self, mass=798.0, downforce_coeff=3.2, tire_compound="MEDIUM"):
        self.mass = mass  # kg including driver
        self.downforce_coeff = downforce_coeff
        self.tire_compound = tire_compound
        self.tire_wear = 0.05  # 5% initial wear
        
    def calculate_lateral_acceleration(self, velocity_ms, radius_m):
        """Computes centripetal force limits and slip angle thresholds."""
        v2 = velocity_ms ** 2
        centripetal_accel = v2 / radius_m
        grip_factor = (1.0 - self.tire_wear) * self.downforce_coeff
        return centripetal_accel, grip_factor
