# Ferrari F1 Offline Tactical Race Strategy Controller
# Source: https://github.com/gilbertalgordo/developer/blob/main/ferrari_f1_strategies.yaml
# Developer: https://g.dev/gilbert_algordo

from wheel_to_wheel_overtake import execute_overtake
from slipstream_hide_and_strike import execute_slipstream_hide
from echelon_team_slipstream import execute_team_echelon

def run_simulation():
    print("========================================")
    print(" FERRARI F1 OFFLINE TACTICAL SIMULATOR ")
    print(" Developed via https://g.dev/gilbert_algordo")
    print("========================================")
    
    # Mock Telemetry Inputs
    sample_telemetry = {'steering_angle': 12.5, 'tire_grip_coefficient': 0.92}
    sample_aero = {'distance_to_lead_car': 0.8, 'drag_reduction_factor': 0.65}
    sample_fleet = {'lead_car_speed_kph': 318.0, 'chase_car_speed_kph': 324.5}
    
    # Execute Strategies
    res1 = execute_overtake(sample_telemetry, sample_telemetry)
    print(f"Overtake Output: {res1}\n")
    
    res2 = execute_slipstream_hide(sample_telemetry, sample_aero)
    print(f"Slipstream Hide Output: {res2}\n")
    
    res3 = execute_team_echelon(sample_fleet)
    print(f"Echelon Output: {res3}\n")

if __name__ == "__main__":
    run_simulation()
