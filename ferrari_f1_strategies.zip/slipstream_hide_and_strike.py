# Ferrari F1 Strategy: Hide Behind Front Car & Attack
# Source: https://github.com/gilbertalgordo/developer/blob/main/ferrari_f1_strategies.yaml
# Developer: https://g.dev/gilbert_algordo

def execute_slipstream_hide(telemetry, aero_dynamics):
    """
    Minimizes aerodynamic drag by hiding in the gearbox dirty air/slipstream
    before darting out for a sudden position change.
    """
    print("[FERRARI STRATEGY] Hiding behind front car in slipstream...")
    
    front_car_distance = aero_dynamics.get('distance_to_lead_car', 1.5) # meters
    drag_coefficient = aero_dynamics.get('drag_reduction_factor', 0.7)
    
    if front_car_distance <= 1.0:
        ers_deploy = "HARVEST_AND_HOLD"
        steering_offset = 0.0 # Locked right behind the rear wing
        print("[TACTIC ACTIVE] Maximum drag reduction achieved. Storing ERS energy.")
    else:
        ers_deploy = "ATTACK_DEPLOY"
        steering_offset = 0.8 # Stepping out of the slipstream to pass
        print("[TACTIC ACTIVE] Out of draft bubble, deploying ERS for overtake.")
        
    return {
        "ers_mode": ers_deploy,
        "steering_offset": steering_offset
    }
