# OmniOS Enterprise Suite v2.1.0 — Universal Multi-OS Installation Guide

Welcome to the **OmniOS Advanced Web & OS Suite** universal installer. OmniOS is engineered for full cross-platform compatibility across **Windows, macOS, Linux, and ChromeOS**.

---

## 🚀 Quick Automated Installation by OS

### 🪟 Windows (10, 11, Server)
1. Extract the downloaded `omnios-enterprise-suite.zip`.
2. Double-click **`install.bat`** (or run `installers\windows\install-windows.bat`).
3. Alternatively, in PowerShell (Administrator or standard):
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\installers\windows\install-windows.ps1
   ```
4. The installer automatically deploys the extension to `%LOCALAPPDATA%\OmniOS\extension`, creates a Desktop shortcut, and launches Google Chrome with OmniOS loaded!

---

### 🍏 macOS (Sequoia, Sonoma, Ventura, Monterey — Apple Silicon & Intel)
1. Extract the downloaded ZIP archive.
2. Open Terminal in the extracted folder and run:
   ```bash
   chmod +x ./install.sh
   ./install.sh
   ```
   *(Or double-click `installers/macos/start-omnios-macos.command` directly in Finder!)*
3. The script deploys OmniOS to `~/Library/Application Support/OmniOS/extension`, creates a desktop launcher, and launches Google Chrome with `--load-extension`.

---

### 🐧 Linux (Ubuntu, Debian, Fedora, Arch, Manjaro, openSUSE)
1. Extract the downloaded ZIP file.
2. Open terminal and run:
   ```bash
   chmod +x ./install.sh
   ./install.sh
   ```
3. OmniOS copies to `~/.local/share/omnios/extension`, registers an XDG Freedesktop menu launcher (`omnios-chrome.desktop`), and starts Chrome/Chromium.

---

### 💻 ChromeOS (Chromebooks)
1. Extract the ZIP inside the ChromeOS **Files** app (e.g. into **My Files > Downloads**).
2. Open Google Chrome on your Chromebook and navigate to:
   `chrome://extensions`
3. Toggle **Developer mode** in the top right.
4. Click **Load unpacked** and select the `omnios-enterprise-suite` folder.
5. OmniOS is now permanently pinned to your ChromeOS shelf!

---

## 🛠 Manual Installation (Any Platform)

If you prefer to load without running installer scripts:
1. Open Google Chrome, Brave, or Microsoft Edge.
2. Enter `chrome://extensions` in the URL address bar.
3. Turn on the **Developer mode** switch in the top right corner.
4. Click the **Load unpacked** button in the top left.
5. Select the `omnios-enterprise-suite` folder containing `manifest.json`.
6. Click the Puzzle icon in your browser toolbar and pin **OmniOS Enterprise Suite**!

---

## 📦 What's Included in this Package

- `manifest.json`: Manifest V3 specification with DeclarativeNetRequest, sidePanel, storage, and system telemetry APIs.
- `background.js`: High-speed AI security threat detection and background service worker.
- `popup.html` & `popup.js`: 5-Tab enterprise Control Hub (AI Security, System Boosters, 3D Sandbox, Telemetry, Google Workspace).
- `viewer.html`: Hardware-accelerated 3D WebGL viewport for CAD models and files.
- `content.js`: Real-time active DOM sanitization & telemetry scrubbing.
- `icons/`: High-resolution icons (16px, 32px, 48px, 128px).
- `installers/`: Native OS automated scripts for Windows, macOS, Linux, and ChromeOS.

---
© 2026 OmniOS Technologies — Enterprise Manifest V3 Standard.
