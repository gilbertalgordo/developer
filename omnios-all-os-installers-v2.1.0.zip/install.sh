#!/usr/bin/env bash
OS="$(uname -s)"
case "$OS" in
    Darwin*)
        echo "[OmniOS] Detected macOS ($OS)"
        chmod +x "$(dirname "$0")/installers/macos/install-macos.sh"
        "$(dirname "$0")/installers/macos/install-macos.sh"
        ;;
    Linux*)
        echo "[OmniOS] Detected Linux ($OS)"
        chmod +x "$(dirname "$0")/installers/linux/install-linux.sh"
        "$(dirname "$0")/installers/linux/install-linux.sh"
        ;;
    *)
        echo "[OmniOS] Unknown OS ($OS). Please refer to INSTALL_ALL_OS.md."
        exit 1
        ;;
esac
