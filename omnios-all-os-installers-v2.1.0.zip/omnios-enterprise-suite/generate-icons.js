/**
 * OmniOS Extension Icon Generator
 * Requires Node.js and the 'canvas' package (`npm install canvas`)
 */
const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');

const SIZES = [16, 32, 48, 128];
const OUTPUT_DIR = path.join(__dirname, 'icons');

if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

function drawOmniOsIcon(size) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  const scale = size / 128; // Base coordinate system on 128x128 standard

  // 1. Background Rounded Rect with Dark Obsidian Plate style
  ctx.save();
  ctx.beginPath();
  const radius = 28 * scale;
  ctx.roundRect(4 * scale, 4 * scale, 120 * scale, 120 * scale, radius);
  
  const bgGrad = ctx.createLinearGradient(0, 0, 128 * scale, 128 * scale);
  bgGrad.addColorStop(0, '#0f172a');
  bgGrad.addColorStop(1, '#020617');
  ctx.fillStyle = bgGrad;
  ctx.fill();

  // Subtle border highlight (Iridescent Cyan/Indigo HUD border)
  ctx.lineWidth = 3 * scale;
  const borderGrad = ctx.createLinearGradient(0, 0, 128 * scale, 128 * scale);
  borderGrad.addColorStop(0, '#0ea5e9');
  borderGrad.addColorStop(0.5, '#6366f1');
  borderGrad.addColorStop(1, '#10b981');
  ctx.strokeStyle = borderGrad;
  ctx.stroke();
  ctx.restore();

  // 2. Central Core Symbol: 3D Multi-Layered Hyper-Cube / Shield Grid
  ctx.save();
  ctx.translate(64 * scale, 64 * scale);

  // Outer Telemetry Ring (Boosters & OS Subsystems)
  ctx.beginPath();
  ctx.arc(0, 0, 36 * scale, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(14, 165, 233, 0.3)';
  ctx.lineWidth = 2 * scale;
  ctx.setLineDash([4 * scale, 3 * scale]);
  ctx.stroke();
  ctx.setLineDash([]);

  // Inner 3D Geometric Vector Representation (3D Viewer & AI Security Core)
  ctx.beginPath();
  const hexRadius = 22 * scale;
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI) / 3 - Math.PI / 6;
    const hx = Math.cos(angle) * hexRadius;
    const hy = Math.sin(angle) * hexRadius;
    if (i === 0) ctx.moveTo(hx, hy);
    else ctx.lineTo(hx, hy);
  }
  ctx.closePath();
  
  const coreGrad = ctx.createLinearGradient(-hexRadius, -hexRadius, hexRadius, hexRadius);
  coreGrad.addColorStop(0, '#0ea5e9');
  coreGrad.addColorStop(1, '#10b981');
  ctx.fillStyle = coreGrad;
  ctx.fill();
  ctx.lineWidth = 2 * scale;
  ctx.strokeStyle = '#ffffff';
  ctx.stroke();

  // Center Core Node (Google Direct Integration & Account Nexus)
  ctx.beginPath();
  ctx.arc(0, 0, 8 * scale, 0, Math.PI * 2);
  ctx.fillStyle = '#0f172a';
  ctx.fill();
  ctx.lineWidth = 2 * scale;
  ctx.strokeStyle = '#38bdf8';
  ctx.stroke();

  ctx.restore();
  return canvas;
}

// Generate files for all Chrome specification scales
SIZES.forEach(size => {
  const canvas = drawOmniOsIcon(size);
  const buffer = canvas.toBuffer('image/png');
  const filePath = path.join(OUTPUT_DIR, `icon${size}.png`);
  fs.writeFileSync(filePath, buffer);
  console.log(`Generated: icon${size}.png successfully.`);
});
