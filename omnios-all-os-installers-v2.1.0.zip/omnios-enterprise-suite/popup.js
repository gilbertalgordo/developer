function switchTab(evt, paneId) {
  document.querySelectorAll('.pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(paneId).classList.add('active');
  evt.currentTarget.classList.add('active');
}

// 1. AI Security Automation Handler
document.getElementById('run-ai-audit').addEventListener('click', () => {
  const output = document.getElementById('ai-output');
  output.innerText = "Analyzing client-side DOM vectors...";
  chrome.runtime.sendMessage({ action: "executeAiSecurityAudit" }, (response) => {
    output.innerText = `Status: ${response.status} | Neutralized Threats: ${response.threatsNeutralized} | Fixations: ${response.domFixationsApplied}`;
  });
});

// 2. Booster Execution Handler
document.getElementById('exec-booster').addEventListener('click', () => {
  const output = document.getElementById('booster-output');
  output.innerText = "Purging memory cache and optimizing network routing...";
  setTimeout(() => {
    output.innerText = "Success: 412 MB recovered, TCP keep-alive stabilized.";
  }, 600);
});

// 3. 3D Viewer Launcher
document.getElementById('launch-3d-viewer').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
});

// 4. OS Subsystems Telemetry Loader
function loadTelemetry() {
  chrome.runtime.sendMessage({ action: "fetchSystemTelemetry" }, (res) => {
    if (res && res.success) {
      const cores = res.cpu.numOfProcessors;
      const totalRam = Math.round(res.memory.capacity / (1024 * 1024));
      const freeRam = Math.round(res.memory.availableCapacity / (1024 * 1024));
      document.getElementById('telemetry-box').innerHTML = `
        <strong>Processor Cores:</strong> ${cores}<br>
        <strong>Total RAM:</strong> ${totalRam} MB<br>
        <strong>Available RAM:</strong> ${freeRam} MB
      `;
    }
  });
}
loadTelemetry();

// 5. Google Workspace App Redirector
function openApp(url) {
  chrome.tabs.create({ url });
}
