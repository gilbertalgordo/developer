@echo off
call "%~dp0installers\windows\install-windows.bat"
