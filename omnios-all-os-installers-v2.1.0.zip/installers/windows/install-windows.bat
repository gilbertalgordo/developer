@echo off
:: ============================================================================
:: OmniOS Enterprise Suite v2.1.0 - Windows Automated Installer & Sideload
:: Compatible: Windows 10, Windows 11, Windows Server (64-bit & ARM64)
:: ============================================================================
setlocal enabledelayedexpansion
title OmniOS Suite - Automated Installer

echo ===============================================================================
echo                OmniOS Enterprise Suite v2.1.0 - Windows Installer
echo ===============================================================================
echo.

:: 1. Define Target Directories
set "INSTALL_DIR=%LOCALAPPDATA%\OmniOS\extension"
set "SOURCE_DIR=%~dp0..\omnios-enterprise-suite"
if not exist "!SOURCE_DIR!\manifest.json" (
  set "SOURCE_DIR=%~dp0omnios-enterprise-suite"
)
if not exist "!SOURCE_DIR!\manifest.json" (
  set "SOURCE_DIR=%~dp0"
)

echo [*] Target installation directory: !INSTALL_DIR!
echo [*] Source extension package:     !SOURCE_DIR!
echo.

:: 2. Verify Manifest presence
if not exist "!SOURCE_DIR!\manifest.json" (
  echo [ERROR] Could not find manifest.json in !SOURCE_DIR!
  echo Please make sure this script is extracted alongside the extension files.
  pause
  exit /b 1
)

:: 3. Create Target Directory & Copy Files
echo [1/4] Copying OmniOS extension files to local app repository...
if not exist "!INSTALL_DIR!" mkdir "!INSTALL_DIR!"
xcopy /E /I /Y "!SOURCE_DIR!\*" "!INSTALL_DIR!\" >nul
if %ERRORLEVEL% NEQ 0 (
  echo [WARNING] xcopy warning encountered, continuing...
)
echo [OK] Files synchronized to !INSTALL_DIR!

:: 4. Locate Chrome / Chromium / Edge / Brave
echo [2/4] Detecting installed Chromium-based browsers...
set "BROWSER_EXE="

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  set "BROWSER_NAME=Google Chrome"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  set "BROWSER_NAME=Google Chrome (x86)"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
  set "BROWSER_EXE=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
  set "BROWSER_NAME=Google Chrome (User)"
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  set "BROWSER_NAME=Microsoft Edge"
) else if exist "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" (
  set "BROWSER_EXE=%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe"
  set "BROWSER_NAME=Brave Browser"
)

if "!BROWSER_EXE!"=="" (
  echo [WARNING] Could not automatically locate Google Chrome or Edge.
  echo Extension files are ready at: !INSTALL_DIR!
  echo In Chrome, open chrome://extensions, enable 'Developer mode', and click 'Load unpacked'.
  pause
  exit /b 0
)

echo [OK] Detected browser: !BROWSER_NAME! (!BROWSER_EXE!)

:: 5. Create Desktop Shortcut for OmniOS Launched Chrome
echo [3/4] Creating OmniOS Quick-Launch Desktop Shortcut...
set "SHORTCUT_PATH=%USERPROFILE%\Desktop\OmniOS Chrome Suite.lnk"
set "VBS_SCRIPT=%TEMP%\CreateOmniOsShortcut.vbs"

echo Set oWS = WScript.CreateObject("WScript.Shell") > "!VBS_SCRIPT!"
echo sLinkFile = "!SHORTCUT_PATH!" >> "!VBS_SCRIPT!"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "!VBS_SCRIPT!"
echo oLink.TargetPath = "!BROWSER_EXE!" >> "!VBS_SCRIPT!"
echo oLink.Arguments = "--load-extension=""!INSTALL_DIR!"" --no-first-run" >> "!VBS_SCRIPT!"
echo oLink.Description = "OmniOS Enterprise Suite v2.1.0" >> "!VBS_SCRIPT!"
echo oLink.Save >> "!VBS_SCRIPT!"
cscript /nologo "!VBS_SCRIPT!" >nul 2>&1
del "!VBS_SCRIPT!" >nul 2>&1
echo [OK] Created desktop shortcut: !SHORTCUT_PATH!

:: 6. Launch Browser with OmniOS Loaded
echo [4/4] Launching !BROWSER_NAME! with OmniOS Extension attached...
start "" "!BROWSER_EXE!" --load-extension="!INSTALL_DIR!" --no-first-run

echo.
echo ===============================================================================
echo [SUCCESS] OmniOS Enterprise Suite has been installed and loaded!
echo.
echo Next steps:
echo 1. In Chrome, click the Puzzle icon in the top-right toolbar.
echo 2. Click the Pin icon next to 'OmniOS' to keep it visible on your toolbar.
echo ===============================================================================
echo.
pause
