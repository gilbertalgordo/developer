# ==============================================================================
# OmniOS Enterprise Suite v2.1.0 - PowerShell Automated Installer (Windows 10/11)
# ==============================================================================
[CmdletBinding()]
param(
    [string]$TargetDir = "$env:LOCALAPPDATA\OmniOS\extension",
    [switch]$LaunchBrowser = $true
)

$ErrorActionPreference = "Stop"

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "               OmniOS Enterprise Suite v2.1.0 - PowerShell Installer           " -ForegroundColor Cyan
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Locate Source Directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Candidates = @(
    (Join-Path $ScriptDir "..\omnios-enterprise-suite"),
    (Join-Path $ScriptDir "omnios-enterprise-suite"),
    $ScriptDir
)

$SourceDir = $null
foreach ($Candidate in $Candidates) {
    if (Test-Path (Join-Path $Candidate "manifest.json")) {
        $SourceDir = $Candidate
        break
    }
}

if (-not $SourceDir) {
    Write-Error "Could not find manifest.json in any expected folder. Please ensure extension files are extracted."
    exit 1
}

Write-Host "[*] Source path: $SourceDir" -ForegroundColor Gray
Write-Host "[*] Destination: $TargetDir" -ForegroundColor Gray
Write-Host ""

# 2. Synchronize Extension Files
Write-Host "[1/4] Deploying extension payload..." -ForegroundColor Yellow
if (-not (Test-Path $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

Copy-Item -Path "$SourceDir\*" -Destination $TargetDir -Recurse -Force
Write-Host "[OK] Payload synchronized to $TargetDir" -ForegroundColor Green

# 3. Detect Chrome / Edge / Brave
Write-Host "[2/4] Detecting Chromium browsers..." -ForegroundColor Yellow
$BrowserPaths = @(
    @{ Name = "Google Chrome"; Path = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe" },
    @{ Name = "Google Chrome (x86)"; Path = "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe" },
    @{ Name = "Google Chrome (Local)"; Path = "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe" },
    @{ Name = "Microsoft Edge"; Path = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe" },
    @{ Name = "Brave Browser"; Path = "$env:ProgramFiles\BraveSoftware\Brave-Browser\Application\brave.exe" }
)

$FoundBrowser = $null
foreach ($Browser in $BrowserPaths) {
    if (Test-Path $Browser.Path) {
        $FoundBrowser = $Browser
        break
    }
}

if (-not $FoundBrowser) {
    Write-Warning "Could not locate a default Chromium executable. Extension is ready at: $TargetDir"
    exit 0
}

Write-Host "[OK] Found browser: $($FoundBrowser.Name) at $($FoundBrowser.Path)" -ForegroundColor Green

# 4. Create Desktop Shortcut
Write-Host "[3/4] Generating desktop shortcut..." -ForegroundColor Yellow
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $DesktopPath = [System.Environment]::GetFolderPath('Desktop')
    $Shortcut = $WshShell.CreateShortcut((Join-Path $DesktopPath "OmniOS Chrome Suite.lnk"))
    $Shortcut.TargetPath = $FoundBrowser.Path
    $Shortcut.Arguments = "--load-extension=""$TargetDir"" --no-first-run"
    $Shortcut.Description = "OmniOS Enterprise Suite v2.1.0"
    $Shortcut.Save()
    Write-Host "[OK] Desktop shortcut created successfully" -ForegroundColor Green
} catch {
    Write-Warning "Shortcut generation non-critical warning: $_"
}

# 5. Launch
if ($LaunchBrowser) {
    Write-Host "[4/4] Launching $($FoundBrowser.Name) with OmniOS attached..." -ForegroundColor Yellow
    Start-Process -FilePath $FoundBrowser.Path -ArgumentList "--load-extension=""$TargetDir"" --no-first-run"
}

Write-Host ""
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "[SUCCESS] OmniOS Enterprise Suite has been installed successfully!" -ForegroundColor Green
Write-Host "===============================================================================" -ForegroundColor Cyan
