#!/usr/bin/env bash
# ==============================================================================
# OmniOS Enterprise Suite v2.1.0 - Linux Automated Installer
# Compatible: Ubuntu 20.04+, Debian 11+, Fedora 38+, Arch Linux, Manjaro, openSUSE
# ==============================================================================
set -e

BLUE='\033[0;34m'
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}===============================================================================${NC}"
echo -e "${CYAN}                 OmniOS Enterprise Suite v2.1.0 - Linux Installer              ${NC}"
echo -e "${CYAN}===============================================================================${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/.local/share/omnios/extension"

# Locate source
if [ -f "$SCRIPT_DIR/../omnios-enterprise-suite/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR/../omnios-enterprise-suite"
elif [ -f "$SCRIPT_DIR/omnios-enterprise-suite/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR/omnios-enterprise-suite"
elif [ -f "$SCRIPT_DIR/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR"
else
    echo -e "${RED}[ERROR] Could not find manifest.json! Ensure ZIP is fully extracted.${NC}"
    exit 1
fi

echo -e "[*] Source path: ${SOURCE_DIR}"
echo -e "[*] Target path: ${TARGET_DIR}"
echo ""

# 1. Synchronize Files
echo -e "${YELLOW}[1/4] Copying extension to ~/.local/share/omnios/...${NC}"
mkdir -p "$TARGET_DIR"
cp -r "$SOURCE_DIR/"* "$TARGET_DIR/"
echo -e "${GREEN}[OK] Extension installed at ${TARGET_DIR}${NC}"

# 2. Browser Detection
echo -e "${YELLOW}[2/4] Searching for Linux Chromium binaries in \$PATH...${NC}"
BROWSER_BIN=""
for candidate in google-chrome google-chrome-stable chromium-browser chromium brave-browser microsoft-edge-stable; do
    if command -v "$candidate" >/dev/null 2>&1; then
        BROWSER_BIN="$candidate"
        break
    fi
done

if [ -z "$BROWSER_BIN" ]; then
    echo -e "${YELLOW}[WARNING] No Chromium binary found in \$PATH.${NC}"
    echo -e "Files installed at: ${TARGET_DIR}"
    echo -e "In Chrome or Chromium, navigate to chrome://extensions and Load Unpacked from ${TARGET_DIR}."
    exit 0
fi

echo -e "${GREEN}[OK] Found browser binary: ${BROWSER_BIN}${NC}"

# 3. Create XDG Freedesktop Application Menu Entry (.desktop)
echo -e "${YELLOW}[3/4] Registering Linux Desktop Application entry...${NC}"
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"
cat << EOF > "$DESKTOP_DIR/omnios-chrome.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=OmniOS Chrome Suite
Comment=OmniOS Enterprise Extension with AI Security, 3D Sandbox, and System Boosters
Exec=$BROWSER_BIN --load-extension="$TARGET_DIR" --no-first-run %U
Icon=$TARGET_DIR/icons/icon128.png
Terminal=false
Categories=Network;WebBrowser;Development;
StartupNotify=true
EOF

chmod +x "$DESKTOP_DIR/omnios-chrome.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
echo -e "${GREEN}[OK] Created desktop menu entry: ${DESKTOP_DIR}/omnios-chrome.desktop${NC}"

# 4. Launch
echo -e "${YELLOW}[4/4] Launching ${BROWSER_BIN} with OmniOS Extension...${NC}"
"$BROWSER_BIN" --load-extension="$TARGET_DIR" --no-first-run >/dev/null 2>&1 &

echo ""
echo -e "${GREEN}===============================================================================${NC}"
echo -e "${GREEN}[SUCCESS] OmniOS Enterprise Suite has been successfully installed on Linux!${NC}"
echo -e "${GREEN}===============================================================================${NC}"
