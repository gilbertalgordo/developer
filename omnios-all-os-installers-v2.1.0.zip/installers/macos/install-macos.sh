#!/usr/bin/env bash
# ==============================================================================
# OmniOS Enterprise Suite v2.1.0 - macOS Automated Installer
# Compatible: macOS Sequoia (15.x), Sonoma (14.x), Ventura (13.x), Monterey
# Architecture: Apple Silicon (M1/M2/M3/M4) & Intel x86_64
# ==============================================================================
set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}===============================================================================${NC}"
echo -e "${CYAN}                 OmniOS Enterprise Suite v2.1.0 - macOS Installer              ${NC}"
echo -e "${CYAN}===============================================================================${NC}"
echo ""

# 1. Resolve Script and Target Directories
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/Library/Application Support/OmniOS/extension"

# Look for extension directory
if [ -f "$SCRIPT_DIR/../omnios-enterprise-suite/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR/../omnios-enterprise-suite"
elif [ -f "$SCRIPT_DIR/omnios-enterprise-suite/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR/omnios-enterprise-suite"
elif [ -f "$SCRIPT_DIR/manifest.json" ]; then
    SOURCE_DIR="$SCRIPT_DIR"
else
    echo -e "${RED}[ERROR] Could not locate manifest.json! Ensure ZIP is extracted properly.${NC}"
    exit 1
fi

echo -e "[*] Source path: ${SOURCE_DIR}"
echo -e "[*] Destination: ${TARGET_DIR}"
echo ""

# 2. Deploy Files
echo -e "${YELLOW}[1/4] Deploying OmniOS files to macOS Application Support...${NC}"
mkdir -p "$TARGET_DIR"
cp -R "$SOURCE_DIR/"* "$TARGET_DIR/"
echo -e "${GREEN}[OK] Files synchronized successfully to ${TARGET_DIR}${NC}"

# 3. Detect Chrome / Brave / Chromium / Edge
echo -e "${YELLOW}[2/4] Detecting macOS Chromium browser application...${NC}"
BROWSER_APP=""

if [ -d "/Applications/Google Chrome.app" ]; then
    BROWSER_APP="Google Chrome"
elif [ -d "$HOME/Applications/Google Chrome.app" ]; then
    BROWSER_APP="Google Chrome"
elif [ -d "/Applications/Brave Browser.app" ]; then
    BROWSER_APP="Brave Browser"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    BROWSER_APP="Microsoft Edge"
elif [ -d "/Applications/Chromium.app" ]; then
    BROWSER_APP="Chromium"
fi

if [ -z "$BROWSER_APP" ]; then
    echo -e "${YELLOW}[WARNING] Could not detect installed Google Chrome or Brave in /Applications.${NC}"
    echo -e "Files installed at: ${TARGET_DIR}"
    echo -e "Open your browser to chrome://extensions, enable Developer Mode, and click 'Load unpacked'."
    exit 0
fi

echo -e "${GREEN}[OK] Detected browser application: ${BROWSER_APP}${NC}"

# 4. Create Desktop Terminal Launcher & CLI Alias
echo -e "${YELLOW}[3/4] Creating macOS Desktop launch runner...${NC}"
DESKTOP_RUNNER="$HOME/Desktop/Start OmniOS Chrome.command"
cat << 'EOF' > "$DESKTOP_RUNNER"
#!/usr/bin/env bash
TARGET_DIR="$HOME/Library/Application Support/OmniOS/extension"
open -a "Google Chrome" --args --load-extension="$TARGET_DIR" --no-first-run
EOF
chmod +x "$DESKTOP_RUNNER"
echo -e "${GREEN}[OK] Desktop launcher created: ${DESKTOP_RUNNER}${NC}"

# 5. Launch Browser with OmniOS
echo -e "${YELLOW}[4/4] Launching ${BROWSER_APP} with OmniOS attached...${NC}"
open -a "$BROWSER_APP" --args --load-extension="$TARGET_DIR" --no-first-run

echo ""
echo -e "${GREEN}===============================================================================${NC}"
echo -e "${GREEN}[SUCCESS] OmniOS Enterprise Suite v2.1.0 installed and running!${NC}"
echo -e "${GREEN}===============================================================================${NC}"
echo -e "Pin the OmniOS puzzle piece in your browser toolbar to get started."
