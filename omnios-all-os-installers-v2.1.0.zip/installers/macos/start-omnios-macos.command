#!/usr/bin/env bash
# Double-clickable macOS Finder command script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/install-macos.sh" ]; then
    chmod +x "$SCRIPT_DIR/install-macos.sh"
    "$SCRIPT_DIR/install-macos.sh"
else
    echo "Running direct loader..."
    open -a "Google Chrome" --args --load-extension="$SCRIPT_DIR/../omnios-enterprise-suite" --no-first-run
fi
