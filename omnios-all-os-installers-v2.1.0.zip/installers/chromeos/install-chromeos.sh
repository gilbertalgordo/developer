#!/usr/bin/env bash
# ==============================================================================
# OmniOS Enterprise Suite v2.1.0 - ChromeOS / Crostini Setup Script
# ==============================================================================
echo "=== OmniOS Enterprise Suite for ChromeOS ==="
echo "On ChromeOS (Chromebooks), extension files can be loaded via either:"
echo "1. ChromeOS Native Browser:"
echo "   - Open chrome://extensions"
echo "   - Enable Developer mode"
echo "   - Click 'Load unpacked'"
echo "   - Select the extracted 'omnios-enterprise-suite' folder from your Files app (Downloads)."
echo ""
echo "2. Linux (Beta) Crostini Container:"
echo "   - Syncing files to ~/.local/share/omnios/extension"
TARGET="$HOME/.local/share/omnios/extension"
mkdir -p "$TARGET"
cp -r "$(dirname "$0")/../omnios-enterprise-suite/"* "$TARGET/" 2>/dev/null || true
echo "   - Files placed in Crostini container at: $TARGET"
echo "=== ChromeOS setup complete ==="
