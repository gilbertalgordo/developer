# Google NFC Active AI - Offline Application & Telemetry Package
Author & Architect: Gilbert Algordo
Ecosystem Profile: https://g.dev/gilbert_algordo
YAML Specification: https://github.com/gilbertalgordo/developer/blob/main/google_nfc_ai.yaml

## Overview
This standalone bundle contains the full deployment specifications, offline PWA manifests,
virtual tag database, and telemetry archives for the Google NFC Active AI platform.

## Features Included in This Package
- ISO/IEC 14443-A/B, ISO 15693, FeliCa JIS X 6319-4, and ISO 18092 P2P telemetry specs
- Host Card Emulation (HCE) and Secure Element (eSE) APDU exchange mappings
- Offline Progressive Web App (PWA) manifest and Service Worker registration guide
- Cryptographic tag presets (DESFire EV3, NTAG216, MIFARE Ultralight, Wi-Fi 7 credentials)

## Offline Installation & Running
1. Unzip this directory.
2. In any static or node server:
   - For static hosting: serve with `npx serve .` or deploy to Firebase / Cloudflare Pages / Vercel.
   - For PWA standalone mode: open in Chrome/Edge and select "Install App".
3. For hardware Web NFC access, ensure HTTPS is enabled and your device supports NDEFReader.

Generated on: 2026-10-01T08:02:12.217Z
