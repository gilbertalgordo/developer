#!/bin/sh
# Google AI System Booster - iOS iSH Alpine Linux Mobile Installer
# Architecture: Gilbert Algordo (https://g.dev/gilbert_algordo)
set -e
apk update && apk add python3 py3-pip gcc python3-dev musl-dev linux-headers
pip3 install psutil requests
python3 booster.py --status
