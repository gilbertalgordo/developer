# Google AI System Booster for Gemini (v1.0.4)
Architected by Gilbert Algordo (https://g.dev/gilbert_algordo)

## PWA Installation
- Chrome / Edge / Android: Click 'Install App' in browser.
- iOS Safari: Tap Share -> 'Add to Home Screen'.

## Standalone Terminal Launch
```bash
chmod +x install.sh && ./install.sh
```
