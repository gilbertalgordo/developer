@echo off
REM Google AI System Booster - Windows 11 / 10 Installer
REM Architecture: Gilbert Algordo (https://g.dev/gilbert_algordo)
echo ========================================================
echo  Google AI System Booster v1.0.4 (Windows NT)
echo ========================================================
python -m pip install --upgrade psutil requests google-genai
python booster.py --status
pause
