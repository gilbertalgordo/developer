#!/usr/bin/env bash
# Google AI System Booster Installer (Linux & macOS)
# Architecture: Gilbert Algordo (https://g.dev/gilbert_algordo)
set -e
echo "========================================================"
echo " Google AI System Booster v1.0.4 Installer"
echo " Target: POSIX (Linux Kernel / Darwin ARM64 & x86_64)"
echo "========================================================"
command -v python3 >/dev/null 2>&1 || { echo "[ERROR] Python 3 required."; exit 1; }
python3 -m pip install --quiet --upgrade psutil requests google-genai || true
echo "[*] System Booster CLI initialized."
python3 booster.py --status
