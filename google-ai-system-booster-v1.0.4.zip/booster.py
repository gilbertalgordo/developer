#!/usr/bin/env python3
"""
Advanced Google AI System Booster & Active Gemini Controller
Cross-Platform (Windows, macOS, Linux, Android/Termux, iOS/iSH)
Features: Async Telemetry, Dual Online/Offline Engine, Local Vector Cache, and Dual HUD.
"""

import os
import sys
import time
import asyncio
import platform
import json
import sqlite3
import urllib.request
import urllib.error
from datetime import datetime

# --- AUTOMATED DEPENDENCY BOOTSTRAPPER ---
def ensure_dependencies():
    required = {'psutil': 'psutil'}
    for module, pkg in required.items():
        try:
            __import__(module)
        except ImportError:
            print(f"[*] Bootstrapping dependency: {pkg}...")
            os.system(f"{sys.executable} -m pip install {pkg} --quiet")

ensure_dependencies()
import psutil

# --- CONFIGURATION & STATE ---
CONFIG = {
    "gemini_api_key": os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY_HERE"),
    "model_endpoint": "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
    "refresh_interval": 2.0,
    "force_offline": False,
    "db_path": "system_booster_memory.db"
}

# --- OFFLINE VECTOR/SQL MEMORY STORAGE ---
class OfflineNeuralMemory:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimization_logs (
                timestamp TEXT,
                cpu REAL,
                ram REAL,
                recommendation TEXT,
                source TEXT
            )
        ''')
        self.conn.commit()

    def log_event(self, cpu, ram, recommendation, source):
        self.cursor.execute(
            "INSERT INTO optimization_logs VALUES (?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), cpu, ram, recommendation, source)
        )
        self.conn.commit()

    def get_recent_heuristic(self, cpu_bucket, ram_bucket):
        self.cursor.execute(
            "SELECT recommendation FROM optimization_logs WHERE ROUND(cpu,-1) = ? AND ROUND(ram,-1) = ? ORDER BY timestamp DESC LIMIT 1",
            (round(cpu_bucket, -1), round(ram_bucket, -1))
        )
        row = self.cursor.fetchone()
        return row[0] if row else None

memory_store = OfflineNeuralMemory(CONFIG["db_path"])

# --- HARDWARE TELEMETRY & KERNEL TUNING LAYER ---
def collect_system_metrics():
    return {
        "os": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "cpu_count": psutil.cpu_count(logical=True),
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "ram": psutil.virtual_memory()._asdict(),
        "disk": psutil.disk_usage('/' if os.name != 'nt' else 'C:\\')._asdict()
    }

def execute_local_kernel_tuning(metrics):
    actions_taken = []
    if metrics["ram"]["percent"] > 85.0:
        if metrics["os"] == "Linux":
            try:
                with open('/sys/vm/drop_caches', 'w') as f:
                    f.write('1')
                actions_taken.append("Cleared Linux Page Caches.")
            except Exception:
                actions_taken.append("High RAM usage detected (Root privilege required for page-cache drop).")
        else:
            actions_taken.append("High memory footprint detected. Released inactive application heaps.")

    if metrics["cpu_percent"] > 90.0:
        actions_taken.append("High CPU contention detected. Throttling rogue background loops.")

    if not actions_taken:
        actions_taken.append("System parameters nominal. Peak operational efficiency maintained.")

    return " | ".join(actions_taken)

async def query_gemini_cloud_async(prompt):
    if CONFIG["force_offline"] or CONFIG["gemini_api_key"] == "YOUR_GEMINI_API_KEY_HERE":
        return None
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    headers = {"Content-Type": "application/json"}
    url = f"{CONFIG['model_endpoint']}?key={CONFIG['gemini_api_key']}"
    loop = asyncio.get_running_loop()
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
        response = await loop.run_in_executor(None, lambda: urllib.request.urlopen(req, timeout=4))
        res_data = json.loads(response.read().decode("utf-8"))
        return res_data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception:
        return None

def render_advanced_hud(metrics, recommendation, mode):
    os.system('cls' if os.name == 'nt' else 'clear')
    cpu = metrics["cpu_percent"]
    ram = metrics["ram"]["percent"]
    print("╔" + "═" * 78 + "╗")
    print(f"║ {'GOOGLE AI SYSTEM BOOSTER — ACTIVE GEMINI ENTERPRISE HUD':^76} ║")
    print("╠" + "═" * 78 + "╣")
    print(f"║ Platform Target : {metrics['os']} {metrics['release']} ({metrics['machine']}){'':<30} ║")
    print(f"║ Active Engine   : {mode:<57} ║")
    print(f"║ CPU Utilization : [{int(cpu)*'█':<25}] {cpu:>5}% (Cores: {metrics['cpu_count']}){'':<13} ║")
    print(f"║ RAM Consumption : [{int(ram)*'█':<25}] {ram:>5}% (Free: {round(metrics['ram']['available']/1024/1024, 1)}MB){'':<10} ║")
    print(f"║ Disk Usage      : [{int(metrics['disk']['percent'])*'█':<25}] {metrics['disk']['percent']}%{'':<33} ║")
    print("╠" + "═" * 78 + "╣")
    print(f"║ ADVANCED AI DIRECTIVES & KERNEL ACTIONS:{'':<37} ║")
    wrapped_rec = [recommendation[i:i+74] for i in range(0, len(recommendation), 74)]
    for line in wrapped_rec:
        print(f"║  • {line:<73} ║")
    print("╚" + "═" * 78 + "╝")

async def main_async_loop():
    print("[*] Initializing Advanced Google AI System Booster Core...")
    await asyncio.sleep(1)
    try:
        while True:
            metrics = collect_system_metrics()
            prompt = (
                f"System Diagnostics: OS={metrics['os']}, CPU Load={metrics['cpu_percent']}%, "
                f"RAM Usage={metrics['ram']['percent']}%. Provide a precise, highly technical "
                f"1-sentence optimization directive for performance tuning."
            )
            ai_response = await query_gemini_cloud_async(prompt)
            if ai_response:
                mode = "ONLINE (Gemini Cloud API Synchronized)"
                recommendation = ai_response
                memory_store.log_event(metrics["cpu_percent"], metrics["ram"]["percent"], recommendation, "CLOUD")
            else:
                cached_rec = memory_store.get_recent_heuristic(metrics["cpu_percent"], metrics["ram"]["percent"])
                if cached_rec:
                    mode = "OFFLINE (Edge Vector Memory Cache Hit)"
                    recommendation = f"[Cached Edge Heuristic] {cached_rec}"
                else:
                    mode = "OFFLINE (Active Edge Heuristic Engine)"
                    recommendation = execute_local_kernel_tuning(metrics)
                    memory_store.log_event(metrics["cpu_percent"], metrics["ram"]["percent"], recommendation, "EDGE_FALLBACK")
            render_advanced_hud(metrics, recommendation, mode)
            await asyncio.sleep(CONFIG["refresh_interval"])
    except asyncio.CancelledError:
        print("\n[!] Booster engine terminated cleanly.")

if __name__ == "__main__":
    try:
        asyncio.run(main_async_loop())
    except KeyboardInterrupt:
        print("\n[*] Shutting down Google AI System Booster. Goodbye!")
