#!/data/data/com.termux/files/usr/bin/bash
# Google AI System Booster - Android Termux Mobile Installer
# Architecture: Gilbert Algordo (https://g.dev/gilbert_algordo)
set -e
echo "========================================================"
echo " Google AI System Booster - Termux Mobile Engine"
echo "========================================================"
pkg update -y && pkg install -y python clang libffi libxml2 libxslt
pip install --upgrade pip
pip install psutil requests google-genai
echo "[*] Android Termux AI Booster Daemon Ready."
python booster.py --mode auto
