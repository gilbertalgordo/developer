import random
from datetime import datetime, timedelta

class GeneticFestivalScheduler:
    """Coachella Active AI - Genetic Heuristic Timetable Optimizer"""
    def __init__(self, artists: list, stages: list, population_size: int = 50):
        self.artists = artists
        self.stages = stages
        self.population_size = population_size

    def _create_chromosome(self) -> dict:
        schedule = {stage['name']: [] for stage in self.stages}
        shuffled = self.artists.copy()
        random.shuffle(shuffled)
        
        pointers = {s['name']: datetime.strptime("12:00", "%H:%M") for s in self.stages}
        for artist in shuffled:
            stage_name = min(pointers, key=pointers.get)
            start = pointers[stage_name]
            end = start + timedelta(minutes=artist['duration'])
            if end.hour <= 1 or end.hour >= 12:
                schedule[stage_name].append({
                    "artist": artist['name'],
                    "genre": artist['genre'],
                    "start": start.strftime("%H:%M"),
                    "end": end.strftime("%H:%M")
                })
                pointers[stage_name] = end + timedelta(minutes=15) # 15-min changeover buffer
        return schedule

    def evaluate_fitness(self, schedule: dict) -> float:
        score = 1000.0
        # Penalize overlapping genre conflicts and sound bleed bottlenecks
        seen_slots = set()
        for stage, slots in schedule.items():
            for slot in slots:
                key = (slot['start'], slot['artist'])
                if key in seen_slots:
                    score -= 150.0
                seen_slots.add(key)
        return max(score, 0.0)

    def optimize(self, generations: int = 100) -> dict:
        population = [self._create_chromosome() for _ in range(self.population_size)]
        best_schedule = max(population, key=self.evaluate_fitness)
        return {
            "optimized_schedule": best_schedule,
            "fitness_score": self.evaluate_fitness(best_schedule)
        }