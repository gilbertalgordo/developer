"""
Coachella Spatial Grounds & Acoustic Bleed Matrix Engine
Pairwise acoustic attenuation and 2D GIS grounds monitoring.
"""
import math
import numpy as np

def calculate_acoustic_bleed(source_spl_db, distance_meters):
    # Standard inverse square law drop: ~6dB per doubling of distance (ref 10m)
    attenuation = 20 * math.log10(max(10, distance_meters) / 10.0)
    received_db = max(35.0, source_spl_db - attenuation)
    is_violation = received_db > 68.0 and distance_meters < 300
    return {
        "distance_m": distance_meters,
        "received_spl_db": round(received_db, 2),
        "is_bleed_violation": is_violation
    }
