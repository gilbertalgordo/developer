# Active AI for Coachella Pro Suite
AI-powered festival intelligence platform for Coachella.

## Modules:
1. `core/genetic_scheduler.py`: Multi-stage Genetic Heuristic Timetable Optimizer.
2. `core/structural_standards.py`: Finite Element / Physics Stage & ADA Standards Engine.
3. `core/srt_stream_engine.py`: Multi-Stage Ultra-Low Latency SRT / WebRTC Broadcaster with YOLOv10-Spatial-Audio-Sync.
4. `core/spatial_acoustic_matrix.py`: Inter-Stage Acoustic Bleed & 2D GIS Grounds Matrix with automated crisis mitigations.
5. `package/builder.py`: Automated App Packaging & ZIP Installer Utility.

## Quickstart:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 main.py
```
