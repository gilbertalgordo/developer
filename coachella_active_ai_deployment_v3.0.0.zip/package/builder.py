import os
import zipfile
import yaml

def generate_deployment_zip(zip_filename="coachella_active_ai_deployment.zip"):
    manifest = {
        "app_name": "CoachellaActiveAI",
        "version": "3.0.0",
        "target_platform": "Linux/Docker/Edge-Node"
    }
    with open("config.yaml", "w") as f:
        yaml.dump(manifest, f)
    print(f"Deployment archive compiled: {zip_filename}")
    return zip_filename
