from core.genetic_scheduler import GeneticFestivalScheduler
from core.structural_standards import StageStandardsEngine
from core.srt_stream_engine import StageBroadcastingEngine
from package.builder import generate_deployment_zip

if __name__ == "__main__":
    print("=== Initializing Active AI for Coachella Pro Suite ===")

    # 1. Genetic Scheduler
    artists = [{"name": "Sabrina Carpenter", "genre": "Pop", "duration": 75}, {"name": "Anyma", "genre": "Electronic", "duration": 90}]
    stages = [{"name": "Coachella Stage"}, {"name": "Sahara Tent"}]
    scheduler = GeneticFestivalScheduler(artists, stages)
    print("Optimization Output:", scheduler.optimize())

    # 2. Standards Audit
    audit_engine = StageStandardsEngine({"max_load_kg": 65000, "rigging_weight_kg": 42000, "wind_tolerance_kmh": 140, "ada_egress_width_m": 2.5, "max_db_perimeter": 88.5})
    print("Engineering Audit:", audit_engine.run_all_audits())

    # 3. SRT Broadcaster
    broadcaster = StageBroadcastingEngine("Coachella Stage", "srt://stream.coachella.internal:9001")
    print("Stream Profile:", broadcaster.get_stream_manifest())

    # 4. Generate Archive
    generate_deployment_zip()