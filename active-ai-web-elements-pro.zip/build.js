/**
 * Advanced Build & Zip Compiler with Icon Assets and Auto-Update Sync
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

const outputFileName = 'active-ai-web-elements-pro.zip';

function compileBundle() {
  console.log('⚡ Initializing Advanced Build Engine [Gilbert Algordo SDK]...');

  if (!fs.existsSync('src') || !fs.existsSync('icons')) {
    console.error('❌ Error: "src" or "icons" directory missing. Aborting compilation.');
    process.exit(1);
  }

  const zip = new AdmZip();
  
  zip.addLocalFile('package.json');
  zip.addLocalFile('manifest.json');
  zip.addLocalFolder('icons', 'icons');
  zip.addLocalFolder('src', 'src');

  zip.writeZip(outputFileName);
  console.log(`[SUCCESS] Distribution archive successfully compiled: ${path.resolve(outputFileName)}`);
}

compileBundle();
