/**
 * Active AI Web Elements - Advanced Neural Core Engine & Auto-Fix Repair
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */
class AINeuralScanner {
  constructor() {
    this.scannedNodes = new Set();
    this.observer = null;
    this.isRealtimeActive = false;
    this.totalRepairs = 0;
  }

  scan(mode = 'standard') {
    this.clear();
    const selector = mode === 'deep' 
      ? 'button, input, select, textarea, article, [data-ai-element], ai-widget, iframe' 
      : 'button, input, select, textarea, [data-ai-element]';

    const elements = document.querySelectorAll(selector);
    elements.forEach(el => {
      el.classList.add('ai-neural-target');
      this.scannedNodes.add(el);
    });

    this.inspectShadowDOM(document.body);
    return this.scannedNodes.size;
  }

  autoFix() {
    let repaired = 0;
    const all = document.querySelectorAll('button, input, textarea, [data-ai-element], ai-widget, ai-element');
    all.forEach(el => {
      const tag = el.tagName.toLowerCase();
      // Auto-repair missing ARIA labels
      if ((tag === 'button' || el.getAttribute('role') === 'button') && !el.getAttribute('aria-label') && !el.innerText?.trim()) {
        el.setAttribute('aria-label', el.getAttribute('title') || 'Interactive AI Button');
        repaired++;
      }
      // Auto-repair inputs
      if ((tag === 'input' || tag === 'textarea') && !el.getAttribute('aria-label') && !el.getAttribute('placeholder')) {
        el.setAttribute('aria-label', 'AI Input Field');
        el.setAttribute('placeholder', 'Type input...');
        repaired++;
      }
      // Auto-index AI tags
      if (tag.includes('ai-') && !el.hasAttribute('data-ai-element')) {
        el.setAttribute('data-ai-element', 'auto-healed');
        repaired++;
      }
    });
    this.totalRepairs += repaired;
    this.scan('deep');
    return { repaired, total: this.totalRepairs };
  }

  inspectShadowDOM(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.shadowRoot) {
        const shadowElements = node.shadowRoot.querySelectorAll('button, input, [data-ai-element]');
        shadowElements.forEach(el => {
          el.classList.add('ai-neural-target');
          this.scannedNodes.add(el);
        });
        this.inspectShadowDOM(node.shadowRoot);
      }
    }
  }

  toggleRealtime(enable) {
    this.isRealtimeActive = enable;
    if (enable) {
      this.observer = new MutationObserver((mutations) => {
        let hasNewElements = false;
        mutations.forEach(mutation => {
          if (mutation.addedNodes.length > 0) {
            hasNewElements = true;
          }
        });
        if (hasNewElements) {
          this.scan('deep');
        }
      });
      this.observer.observe(document.body, { childList: true, subtree: true });
    } else if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
  }

  clear() {
    this.scannedNodes.forEach(el => el.classList.remove('ai-neural-target'));
    this.scannedNodes.clear();
  }
}

window.aiNeuralEngine = new AINeuralScanner();
