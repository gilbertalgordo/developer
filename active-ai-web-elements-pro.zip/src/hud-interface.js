/**
 * Active AI Web Elements - Advanced Telemetry HUD Interface
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */
(function() {
  const hudTemplate = `
    <div id="ai-pro-hud">
      <div class="ai-hud-header">
        <span>⚡ AI Neural HUD [v2.0]</span>
        <button id="ai-hud-minimize" style="background:none; border:none; color:#00ffcc; cursor:pointer; font-weight:bold;">_</button>
      </div>
      <div class="ai-hud-body">
        <div class="ai-hud-grid">
          <div class="ai-metric-card">
            <span>Indexed Nodes</span>
            <strong id="ai-node-count">0</strong>
          </div>
          <div class="ai-metric-card">
            <span>Kaizen Engine</span>
            <strong>Active</strong>
          </div>
        </div>
        <div class="ai-hud-controls">
          <label for="ai-scan-mode">Neural Depth Profile:</label>
          <select id="ai-scan-mode">
            <option value="standard">Standard DOM Index</option>
            <option value="deep">Deep Shadow DOM Grid</option>
          </select>

          <label for="ai-realtime-toggle">Real-time Observer Sync:</label>
          <select id="ai-realtime-toggle">
            <option value="off">Disabled</option>
            <option value="on">Continuous Mutation Watch</option>
          </select>
        </div>
        <div class="ai-hud-actions">
          <button class="ai-action-btn" id="ai-btn-scan">Execute Scan</button>
          <button class="ai-action-btn secondary" id="ai-btn-clear">Purge</button>
        </div>
      </div>
    </div>
  `;

  const container = document.createElement('div');
  container.innerHTML = hudTemplate;
  document.body.appendChild(container);

  const engine = window.aiNeuralEngine;
  const countDisplay = document.getElementById('ai-node-count');

  document.getElementById('ai-btn-scan').addEventListener('click', () => {
    const mode = document.getElementById('ai-scan-mode').value;
    const total = engine.scan(mode);
    countDisplay.textContent = total;
  });

  document.getElementById('ai-btn-clear').addEventListener('click', () => {
    engine.clear();
    countDisplay.textContent = '0';
  });

  document.getElementById('ai-realtime-toggle').addEventListener('change', (e) => {
    engine.toggleRealtime(e.target.value === 'on');
  });

  document.getElementById('ai-hud-minimize').addEventListener('click', () => {
    document.getElementById('ai-pro-hud').classList.toggle('minimized');
  });
})();
