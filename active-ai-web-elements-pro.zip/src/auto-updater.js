/**
 * Active AI Web Elements - Background Auto-Update Service Worker
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

const UPDATE_INTERVAL_MINUTES = 60;

// Setup periodic auto-update check alarm on install
chrome.runtime.onInstalled.addListener(() => {
  console.info('[AutoUpdate] Extension initialized. Registering update check alarm...');
  chrome.alarms.create('ai_auto_update_check', {
    periodInMinutes: UPDATE_INTERVAL_MINUTES
  });
});

// Periodic alarm handler to request update checks from distribution channel
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'ai_auto_update_check') {
    console.info('[AutoUpdate] Checking for newest AI Web Elements patches and manifests...');
    if (chrome.runtime.requestUpdateCheck) {
      chrome.runtime.requestUpdateCheck((status, details) => {
        if (status === 'update_available') {
          console.info(`[AutoUpdate] Update available: v${details.version}. Applying patch...`);
          chrome.runtime.reload();
        } else {
          console.info(`[AutoUpdate] Extension is up to date (${status}).`);
        }
      });
    }
  }
});

// Listen for update events and apply seamless reload
chrome.runtime.onUpdateAvailable.addListener((details) => {
  console.info(`[AutoUpdate] New version ${details.version} downloaded. Reloading runtime...`);
  chrome.runtime.reload();
});
