#!/bin/bash
set -e
cd "$(dirname "$0")/.."
echo "========================================================"
echo "   AuraMedia - Android Media3 AI Audio Player (Linux)   "
echo "========================================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "[!] Node.js is required. Install with: sudo apt install nodejs npm"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    npm install
fi

echo "[*] Starting local audio server..."
(sleep 2 && xdg-open "http://localhost:3000" || true) &
npm run dev
