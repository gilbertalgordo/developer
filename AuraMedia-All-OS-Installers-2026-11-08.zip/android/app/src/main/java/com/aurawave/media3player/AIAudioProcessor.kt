package com.aurawave.media3player

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * Stage 2: AIAudioProcessor
 * Jetpack Media3 custom AudioProcessor with:
 * - 16-bit PCM buffer queue
 * - Adaptive spectral noise gate
 * - Soft-clipping polynomial saturation limiter
 */
@UnstableApi
class AIAudioProcessor : BaseAudioProcessor() {

    @Volatile var isAuraActive: Boolean = true
    @Volatile var boostMultiplier: Float = 1.5f
    @Volatile var noiseSuppressionLevel: Float = 0.2f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val outputBuffer = replaceOutputBuffer(remaining)

        while (inputBuffer.hasRemaining()) {
            val sample16 = inputBuffer.short
            val normalized = sample16 / 32768.0f

            val processed = if (isAuraActive) {
                processSample(normalized)
            } else {
                normalized
            }

            val clamped16 = (processed * 32767.0f)
                .coerceIn(-32768.0f, 32767.0f)
                .toInt()
                .toShort()

            outputBuffer.putShort(clamped16)
        }
    }

    private fun processSample(sample: Float): Float {
        // Noise Gate: |sample| < 0.02 * level -> 0.0
        val gateThreshold = 0.02f * noiseSuppressionLevel
        if (abs(sample) < gateThreshold) {
            return 0.0f
        }

        // AI Dynamic Boost
        val boosted = sample * boostMultiplier

        // Soft-Clipping Polynomial Saturator
        return if (boosted > 1.0f) {
            1.0f - (1.0f / (1.0f + (boosted - 1.0f)))
        } else if (boosted < -1.0f) {
            -1.0f + (1.0f / (1.0f + (-boosted - 1.0f)))
        } else {
            boosted
        }
    }
}
