package com.aurawave.media3player

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.DefaultAudioSink

@UnstableApi
class MainActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private var audioProcessor: AIAudioProcessor? = null
    private var audioEnhancer: AIAudioEnhancer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initPlayer()
    }

    private fun initPlayer() {
        audioProcessor = AIAudioProcessor()

        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(this).apply {
            // Supply custom audio processor to the ExoPlayer audio sink
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .build()
            .apply {
                val mediaItem = MediaItem.fromUri("asset:///demo_track.mp3")
                setMediaItem(mediaItem)
                prepare()

                audioEnhancer = AIAudioEnhancer(audioSessionId)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        audioEnhancer?.release()
    }
}
