package com.aurawave.media3player

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.LoudnessEnhancer
import android.os.Build

enum class AudioGenre {
    PODCAST_SPEECH,
    BASS_BOOSTED_MUSIC,
    BALANCED
}

/**
 * Stage 3: AIAudioEnhancer
 * Hardware LoudnessEnhancer (0-1000 mB) + DynamicsProcessing Multi-Band Compressor
 */
class AIAudioEnhancer(private val audioSessionId: Int) {

    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var dynamicsProcessing: DynamicsProcessing? = null

    init {
        try {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(600) // Default +6.0 dB
                enabled = true
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val config = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.CONFIG_VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2, // 2 channels (stereo)
                    true, 4, // 4-band pre-EQ
                    true, 4, // 4-band MBC
                    true, 4, // 4-band post-EQ
                    true     // Limiter enabled
                ).build()

                dynamicsProcessing = DynamicsProcessing(audioSessionId, config).apply {
                    enabled = true
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun applyPreset(genre: AudioGenre) {
        when (genre) {
            AudioGenre.BASS_BOOSTED_MUSIC -> {
                loudnessEnhancer?.setTargetGain(800) // +8.0 dB
            }
            AudioGenre.PODCAST_SPEECH -> {
                loudnessEnhancer?.setTargetGain(450) // +4.5 dB
            }
            AudioGenre.BALANCED -> {
                loudnessEnhancer?.setTargetGain(500) // +5.0 dB
            }
        }
    }

    fun setTargetGainMb(gainMb: Int) {
        loudnessEnhancer?.setTargetGain(gainMb.coerceIn(0, 1000))
    }

    fun release() {
        loudnessEnhancer?.release()
        loudnessEnhancer = null
        dynamicsProcessing?.release()
        dynamicsProcessing = null
    }
}
