#!/bin/bash
echo "[*] Generating macOS App bundle wrapper..."
APP_DIR="$HOME/Applications/AuraMedia.app"
mkdir -p "$APP_DIR/Contents/MacOS"
mkdir -p "$APP_DIR/Contents/Resources"

cat << 'EOF' > "$APP_DIR/Contents/MacOS/AuraMedia"
#!/bin/bash
open "http://localhost:3000"
EOF

chmod +x "$APP_DIR/Contents/MacOS/AuraMedia"
echo "[SUCCESS] Created AuraMedia.app in ~/Applications"
