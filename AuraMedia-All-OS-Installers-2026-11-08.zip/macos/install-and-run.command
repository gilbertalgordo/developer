#!/bin/bash
cd "$(dirname "$0")/.."
echo "========================================================"
echo "   AuraMedia - Android Media3 AI Audio Player (macOS)   "
echo "========================================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "[!] Node.js not detected. Please install Node.js: brew install node"
    open "https://nodejs.org"
    exit 1
fi

echo "[*] Checking dependencies..."
if [ ! -d "node_modules" ]; then
    npm install
fi

echo "[*] Launching AuraMedia in your default browser..."
(sleep 2 && open "http://localhost:3000") &
npm run dev
