# AuraMedia - Android Jetpack Media3 ExoPlayer & Cross-Platform Audio Engine

Welcome to the all-in-one distribution bundle for AuraMedia.
This bundle contains native mobile and desktop installers, ready-to-run scripts, and complete Android source code.

## Package Contents
1. **/android/**
   - Complete Android Studio project (Kotlin + Gradle)
   - Jetpack Media3 ExoPlayer 1.3.1 implementation
   - Custom AIAudioProcessor & AIAudioEnhancer (LoudnessEnhancer + DynamicsProcessing)
   - AndroidManifest.xml configured with FOREGROUND_SERVICE_MEDIA_PLAYBACK and WAKE_LOCK
   - One-click build script: `gradlew assembleDebug` to produce `app-debug.apk`

2. **/windows/**
   - `install-and-run.bat`: Quick launcher script for Windows 10/11
   - `start-auramedia.vbs`: Silent background desktop runner

3. **/macos/**
   - `install-and-run.command`: Double-clickable macOS application runner
   - Sets up native audio and launches in standalone mode

4. **/linux/**
   - `install-and-run.sh`: Linux desktop runner with PulseAudio / PipeWire integration

5. **/offline-web-app/**
   - Self-contained offline Progressive Web App distribution
   - Pre-configured service worker (`sw.js`), Web App Manifest, and high-resolution icons

## Quick Start
- **Android Users**: Open the `/android` folder in Android Studio, click **Run**, or run `./gradlew assembleRelease`.
- **Windows Users**: Double-click `windows/install-and-run.bat`.
- **Mac Users**: Double-click `macos/install-and-run.command`.
- **Linux Users**: Run `bash linux/install-and-run.sh`.
- **Direct PWA**: Open `offline-web-app/index.html` in any modern browser.
