@echo off
title AuraMedia - AI Audio Engine Launcher
color 0e
echo ========================================================
echo    AuraMedia - Android Media3 AI Audio Player
echo    High-Performance DSP Sound Engine for Windows
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found. Please install Node.js from https://nodejs.org
    echo Opening official installer website...
    start https://nodejs.org
    pause
    exit /b 1
)

echo [OK] Node.js environment detected.
echo [*] Installing dependencies if needed...
if not exist "..\node_modules" (
    cd ..
    call npm install
    cd windows
)

echo [*] Starting AuraMedia Desktop Audio Engine...
start "" http://localhost:3000
cd ..
npm run dev
pause
