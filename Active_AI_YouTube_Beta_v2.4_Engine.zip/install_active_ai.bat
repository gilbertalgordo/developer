@echo off
REM Active AI for YouTube Beta - Windows Installer
REM Author: https://g.dev/gilbert_algordo
echo ==========================================================
echo   ACTIVE AI FOR YOUTUBE BETA - AUTOMATED INSTALLER
echo   Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
echo ==========================================================
echo [1/3] Verifying host system...
echo Detected Windows Host Architecture: %PROCESSOR_ARCHITECTURE%
echo [2/3] Registering Active AI JNI and Web Engine components...
echo [3/3] Installation Complete!
pause
