plugins {
    id("com.android.library")
    kotlin("android")
}

android {
    namespace = "com.google.android.youtube.activeai"
    compileSdk = 35

    defaultConfig {
        minSdk = 26
        targetSdk = 35
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86_64")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
}
