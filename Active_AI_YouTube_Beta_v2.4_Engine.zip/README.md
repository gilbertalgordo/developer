# Active AI for YouTube Beta - Core Engine Bridge
**Developer & Author:** Gilbert Algordo (https://g.dev/gilbert_algordo)
**Architecture:** Cross-Platform Native Acceleration & Multimodal Intelligence
**Platforms:** Android (JNI/NDK), iOS (Metal 3), Universal Web (WebGPU)

---

## Overview
Active AI for YouTube Beta is an ultra-low latency augmented video copilot engineered to overlay continuous neural telemetry, spatial reticles, and multimodal reasoning (powered by Gemini 3.8 Flash) directly onto streaming video.

## Directory Structure
- `android/`: Kotlin JNI module, build.gradle, and AndroidManifest hooks
- `ios/`: Swift UIKit/SwiftUI Metal 3 HUD views and Metal shader kernels
- `web/`: Universal TypeScript core engine, WebSocket stream client, and event emitter
- `specs/`: Full YAML engine specification (`youtube_beta_ai.yaml`)
- `install_active_ai.sh`: Automated Unix installer script
- `install_active_ai.bat`: Automated Windows batch script

## Quick Installation

### Unix / macOS:
```bash
chmod +x install_active_ai.sh
./install_active_ai.sh
```

### Android:
1. Copy `android/YouTubeActiveAIModule.kt` into your Android project (`src/main/java/com/google/android/youtube/activeai/`).
2. Add the Gradle dependencies from `android/build.gradle.kts`.
3. Call `YouTubeActiveAIModule.initializeBetaEngine()` in your Application `onCreate()`.

### iOS:
1. Add `ios/ActiveAIView.swift` and `ios/ActiveAIShaders.metal` to your Xcode workspace.
2. Link `Metal.framework` and `MetalKit.framework`.
3. Instantiate `ActiveAIView()` in your SwiftUI view hierarchy.
