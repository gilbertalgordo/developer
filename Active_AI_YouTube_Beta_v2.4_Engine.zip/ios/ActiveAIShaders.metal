#include <metal_stdlib>
using namespace metal;

/**
 * Active AI Metal 3 Shaders
 * Author: Gilbert Algordo
 */
kernel void active_ai_scan_rasterizer(
    texture2d<float, access::write> outTexture [[texture(0)]],
    uint2 gid [[thread_position_in_grid]],
    constant float &scanlineY [[buffer(0)]]
) {
    if (gid.x >= outTexture.get_width() || gid.y >= outTexture.get_height()) {
        return;
    }

    float4 color = float4(0.0, 0.0, 0.0, 0.0);
    float dist = abs(float(gid.y) - scanlineY);
    if (dist < 2.0) {
        color = float4(0.0, 1.0, 0.8, 0.95);
    }

    outTexture.write(color, gid);
}
