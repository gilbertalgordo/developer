import SwiftUI
import MetalKit

/**
 * Active AI for YouTube Beta - iOS Metal 3 HUD View
 * Author: https://g.dev/gilbert_algordo
 */
public struct ActiveAIView: View {
    @State private var isAnalyzing: Bool = true
    @State private var telemetryFPS: Double = 60.0
    public var videoId: String

    public init(videoId: String = "default") {
        self.videoId = videoId
    }

    public var body: some View {
        ZStack {
            // High-Performance Metal Rasterizer Overlay
            ActiveAIMetalCanvas()
                .edgesIgnoringSafeArea(.all)
                .allowsHitTesting(false)

            VStack {
                HStack {
                    Circle()
                        .fill(Color(red: 0, green: 1, blue: 0.8))
                        .frame(width: 8, height: 8)
                    Text("ACTIVE AI HUD [METAL 3]")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundColor(Color(red: 0, green: 1, blue: 0.8))
                    Spacer()
                    Text(String(format: "%.1f FPS", telemetryFPS))
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundColor(.white)
                }
                .padding(8)
                .background(Color.black.opacity(0.75))
                .cornerRadius(8)
                Spacer()
            }
            .padding()
        }
    }
}

struct ActiveAIMetalCanvas: UIViewRepresentable {
    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device = MTLCreateSystemDefaultDevice()
        view.backgroundColor = .clear
        view.isOpaque = false
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}
}
