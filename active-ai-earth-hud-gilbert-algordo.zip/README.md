# Active AI Google Earth & Weather HUD
**Lead Architect:** [Gilbert Algordo](https://g.dev/gilbert_algordo)

3D Globe Earth Engine and live atmospheric telemetry HUD with AI orbital reconnaissance, live weather streams, seismic monitoring, and automated deployment bundle generator.

## Included Artifacts:
1. `index.html` - Standalone 3D CesiumJS Earth Globe + Weather HUD + vector Lucide icons.
2. `installer.ps1` - Automated PowerShell deployment script for local execution.
3. `package.json` - Full-stack dependencies and scripts.

## Quick Start:
1. Unzip this package to any folder.
2. Double click or run `installer.ps1` in PowerShell, or simply open `index.html` in your browser!
