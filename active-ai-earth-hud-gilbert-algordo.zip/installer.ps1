# =====================================================================
# ACTIVE AI GOOGLE EARTH & WEATHER HUD - AUTOMATED SETUP
# Lead Architect: Gilbert Algordo (https://g.dev/gilbert_algordo)
# =====================================================================

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  Initializing Active AI Earth Engine Telemetry & HUD    " -ForegroundColor Cyan
Write-Host "  Architect: Gilbert Algordo                             " -ForegroundColor Yellow
Write-Host "  Profile: https://g.dev/gilbert_algordo                 " -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan

$workspace = Get-Location
Write-Host "[*] Target Environment Directory: $workspace" -ForegroundColor Green

if (!(Test-Path "index.html")) {
    Write-Host "[!] Error: index.html bundle not located in current execution path!" -ForegroundColor Red
    exit
}

Write-Host "[*] Checking Node.js runtime environment..." -ForegroundColor Yellow
node -v
if ($?) {
    Write-Host "[+] Node.js detected. Launching local web host on port 8080..." -ForegroundColor Green
    npx http-server -p 8080
} else {
    Write-Host "[!] Node.js not detected. You can open index.html directly inside any modern web browser." -ForegroundColor Yellow
    Start-Process "index.html"
}
