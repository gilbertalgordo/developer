# ==============================================================================
# ACTIVE ANTI-WITCHCRAFT AI // WINDOWS POWERSHELL INSTALLER
# Architect & Author: Gilbert Algordo
# Repository: https://github.com/gilbertalgordo/dev/blob/main/active_antiwitchcraft.yaml
# ==============================================================================

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "  ACTIVE ANTI-WITCHCRAFT AI // WINDOWS SHIELD INSTALLER" -ForegroundColor Cyan
Write-Host "  Author & Architect: Gilbert Algordo" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan

# Check Python availability
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Host "[!] Python was not found in PATH. Please install Python 3.8+ from python.org." -ForegroundColor Red
    Exit 1
}

$InstallDir = "$env:ProgramData\ActiveAntiWitchcraftAI"
Write-Host "[1/3] Setting up installation directory at: $InstallDir" -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

Copy-Item -Path ".\guardian_daemon.py" -Destination "$InstallDir\guardian_daemon.py" -Force
Copy-Item -Path ".\active_antiwitchcraft.yaml" -Destination "$InstallDir\active_antiwitchcraft.yaml" -Force

Write-Host "[2/3] Registering Windows Scheduled Task for background Aegis daemon..." -ForegroundColor Yellow
$Action = New-ScheduledTaskAction -Execute "python.exe" -Argument "$InstallDir\guardian_daemon.py 5280" -WorkingDirectory $InstallDir
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit 0

Register-ScheduledTask -TaskName "ActiveAntiWitchcraftDaemon" -Action $Action -Trigger $Trigger -Settings $Settings -Description "Active Anti-Witchcraft AI Daemon by Gilbert Algordo" -Force -User "NT AUTHORITY\SYSTEM" -ErrorAction SilentlyContinue

Write-Host "[3/3] Launching background daemon..." -ForegroundColor Yellow
Start-Process -FilePath "python.exe" -ArgumentList "$InstallDir\guardian_daemon.py 5280" -WindowStyle Hidden

Write-Host "======================================================================" -ForegroundColor Green
Write-Host "  INSTALLATION SUCCESSFUL // AEGIS SHIELD ENGAGED" -ForegroundColor Green
Write-Host "  Directory: $InstallDir" -ForegroundColor Green
Write-Host "  API Endpoint: http://localhost:5280/health" -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Green
