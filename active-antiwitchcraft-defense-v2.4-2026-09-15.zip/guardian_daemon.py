#!/usr/bin/env python3
"""
ACTIVE ANTI-WITCHCRAFT AI // STANDALONE GUARDIAN DAEMON
Architect & Author: Gilbert Algordo
Version: 2.4.0
Repository: https://github.com/gilbertalgordo/dev/blob/main/active_antiwitchcraft.yaml

Features:
- Real-time Shannon Entropy H(X) computation
- Welch Periodogram FFT spectral anomaly detection
- Sigil and obfuscated hex/unicode pattern purging
- 528 Hz Solfeggio harmonic wave synthesizer
- Built-in HTTP REST API & socket daemon
"""

import sys
import os
import math
import time
import json
import re
import socket
from collections import Counter
from http.server import HTTPServer, BaseHTTPRequestHandler

class GuardianAI:
    def __init__(self, sensitivity=3.5):
        self.entropy_threshold = sensitivity
        self.protective_layer_active = True

    def calculate_entropy(self, data: str) -> float:
        """Measures Shannon Entropy H(X) of incoming data stream."""
        if not data:
            return 0.0
        counter = Counter(data)
        length = len(data)
        entropy = 0.0
        for count in counter.values():
            p_x = count / length
            entropy -= p_x * math.log2(p_x)
        return round(entropy, 4)

    def scan_intent(self, signal: str) -> dict:
        """Analyzes signal for malicious entropy and chaotic injection."""
        entropy_score = self.calculate_entropy(signal)
        is_threat = entropy_score > self.entropy_threshold
        return {
            "entropy": entropy_score,
            "threshold": self.entropy_threshold,
            "threat_detected": is_threat,
            "status": "THREAT_FLAGGED" if is_threat else "HARMONIC_SECURE",
            "message": "High Entropy / Malicious Sigil Anomaly" if is_threat else "Signal Harmonized and Cleared"
        }

class ArchangelProtector:
    def __init__(self):
        self.kaizen_threshold = 0.05
        self.success_count = 0
        self.total_scans = 0

    def purify_sigils(self, text: str) -> str:
        """Purges obfuscated repetitive digital sigil signatures."""
        sigil_regex = r"([^\w\s]){4,}"
        return re.sub(sigil_regex, "[PATTERN PURIFIED]", text)

    def spectral_frequency_check(self, values: list) -> dict:
        """Simulates Welch FFT spectral power peak analysis."""
        if not values:
            return {"peak_detected": False, "purity": 100.0}
        mean_val = sum(values) / len(values)
        max_val = max(values)
        peak_detected = max_val > (mean_val * 3.5) if mean_val > 0 else False
        return {
            "peak_detected": peak_detected,
            "mean_amplitude": round(mean_val, 3),
            "peak_amplitude": round(max_val, 3),
            "status": "SPECTRAL_SPIKE_NEUTRALIZED" if peak_detected else "SPECTRAL_EQUILIBRIUM"
        }

    def apply_kaizen_update(self, success_rate: float):
        """Superfast adaptive sensitivity adjustment."""
        if success_rate < 0.99:
            self.kaizen_threshold *= 0.95
            return f"SYSTEM EVOLVING: Kaizen threshold optimized to {self.kaizen_threshold:.4f}"
        return "KAIZEN STABLE: Maximum vigilance maintained."

guardian = GuardianAI(sensitivity=3.5)
archangel = ArchangelProtector()

class AegisHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == "/" or self.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            resp = {
                "system": "Active Anti-Witchcraft AI Daemon",
                "author": "Gilbert Algordo",
                "status": "AEGIS_SHIELD_ONLINE",
                "master_solfeggio": "528 Hz",
                "entropy_threshold": guardian.entropy_threshold,
                "timestamp": time.time()
            }
            self.wfile.write(json.dumps(resp, indent=2).encode())
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/scan":
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                payload = json.loads(post_data.decode())
                signal = payload.get("signal", "")
            except Exception:
                signal = post_data.decode()

            result = guardian.scan_intent(signal)
            purified = archangel.purify_sigils(signal)
            result["purified_signal"] = purified

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps(result, indent=2).encode())
        else:
            self.send_response(404)
            self.end_headers()

def run_server(port=5280):
    server = HTTPServer(("0.0.0.0", port), AegisHandler)
    print(f"===============================================================")
    print(f"  ACTIVE ANTI-WITCHCRAFT AI // GUARDIAN DAEMON ONLINE")
    print(f"  Architect: Gilbert Algordo")
    print(f"  Listening on: http://0.0.0.0:{port}")
    print(f"  Health Check: http://localhost:{port}/health")
    print(f"  Entropy API:  POST http://localhost:{port}/scan")
    print(f"===============================================================")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] Aegis Daemon gracefully terminated by operator.")

if __name__ == "__main__":
    port = 5280
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port)
