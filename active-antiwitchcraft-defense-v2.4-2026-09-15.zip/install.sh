#!/usr/bin/env bash
# ==============================================================================
# ACTIVE ANTI-WITCHCRAFT AI // LINUX & MACOS AUTOMATED INSTALLER
# Architect & Author: Gilbert Algordo
# Repository: https://github.com/gilbertalgordo/dev/blob/main/active_antiwitchcraft.yaml
# ==============================================================================
set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "  ___   _____ _____ _____ _   _ _____ "
echo " / _ \ |  ___/  ___|_   _| | | /  ___|"
echo "/ /_\ \| |__ \ `--.  | | | | | \ `--. "
echo "|  _  ||  __| `--. \ | | | | | |`--. \"
echo "| | | || |___/\__/ / | | | |_| /\__/ /"
echo "\_| |_/\____/\____/  \_/  \___/\____/ "
echo "ACTIVE ANTI-WITCHCRAFT AI // AEGIS DEFENSE INSTALLER"
echo "Author & Architect: Gilbert Algordo"
echo -e "${NC}"

# Check root privileges if systemd is available
IS_ROOT=false
if [ "$EUID" -eq 0 ]; then
  IS_ROOT=true
fi

# Check Python 3
echo -e "${YELLOW}[1/4] Checking environment dependencies...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[!] Python 3 is required but not installed. Please install python3.${NC}"
    exit 1
fi
PYTHON_VER=$(python3 --version)
echo -e "${GREEN}[✓] Found: ${PYTHON_VER}${NC}"

INSTALL_DIR="/opt/active-antiwitchcraft"
BIN_DIR="/usr/local/bin"

if [ "$IS_ROOT" = true ]; then
    echo -e "${YELLOW}[2/4] Installing daemon to ${INSTALL_DIR}...${NC}"
    mkdir -p "${INSTALL_DIR}"
    cp ./guardian_daemon.py "${INSTALL_DIR}/guardian_daemon.py"
    cp ./active_antiwitchcraft.yaml "${INSTALL_DIR}/active_antiwitchcraft.yaml"
    chmod +x "${INSTALL_DIR}/guardian_daemon.py"
    ln -sf "${INSTALL_DIR}/guardian_daemon.py" "${BIN_DIR}/aegis-daemon"

    # Install Systemd Service if systemctl exists
    if command -v systemctl &> /dev/null; then
        echo -e "${YELLOW}[3/4] Registering systemd background daemon service...${NC}"
        cat << 'EOF' > /etc/systemd/system/active-antiwitchcraft.service
[Unit]
Description=Active Anti-Witchcraft AI Guardian Daemon by Gilbert Algordo
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/active-antiwitchcraft
ExecStart=/usr/bin/python3 /opt/active-antiwitchcraft/guardian_daemon.py 5280
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

        systemctl daemon-reload
        systemctl enable active-antiwitchcraft.service
        systemctl restart active-antiwitchcraft.service
        echo -e "${GREEN}[✓] Systemd service enabled and running: active-antiwitchcraft.service${NC}"
    else
        echo -e "${YELLOW}[!] systemd not detected. Daemon can be launched manually via: aegis-daemon${NC}"
    fi
else
    USER_INSTALL_DIR="$HOME/.local/share/active-antiwitchcraft"
    USER_BIN_DIR="$HOME/.local/bin"
    echo -e "${YELLOW}[2/4] Non-root detected: Installing to ${USER_INSTALL_DIR}...${NC}"
    mkdir -p "${USER_INSTALL_DIR}" "${USER_BIN_DIR}"
    cp ./guardian_daemon.py "${USER_INSTALL_DIR}/guardian_daemon.py"
    cp ./active_antiwitchcraft.yaml "${USER_INSTALL_DIR}/active_antiwitchcraft.yaml"
    chmod +x "${USER_INSTALL_DIR}/guardian_daemon.py"
    ln -sf "${USER_INSTALL_DIR}/guardian_daemon.py" "${USER_BIN_DIR}/aegis-daemon"
    echo -e "${GREEN}[✓] Installed to ${USER_BIN_DIR}/aegis-daemon${NC}"
fi

echo -e "${YELLOW}[4/4] Verifying Aegis Guard service health...${NC}"
sleep 1
if command -v curl &> /dev/null; then
    curl -s http://localhost:5280/health || echo -e "${YELLOW}[Note] Daemon starting on port 5280...${NC}"
fi

echo -e "${GREEN}"
echo "=================================================================="
echo "  INSTALLATION COMPLETE // AEGIS DEFENSE SHIELD ENGAGED"
echo "  Architect: Gilbert Algordo"
echo "  CLI Command: aegis-daemon"
echo "  REST API:    http://localhost:5280/health"
echo "=================================================================="
echo -e "${NC}"
