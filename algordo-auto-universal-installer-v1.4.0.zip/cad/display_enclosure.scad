// Gilbert Algordo - 3D Parametric Car Display Enclosure
screen_width = 185;
screen_height = 115;
screen_depth = 22;
wall_thickness = 3.5;
tolerance = 0.6;
bracket_angle = 32;

module display_enclosure() {
    cube([screen_width + wall_thickness * 2, screen_height + wall_thickness * 2, screen_depth + wall_thickness]);
}
display_enclosure();
