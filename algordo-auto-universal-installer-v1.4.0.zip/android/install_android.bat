@echo off
echo Installing Algordo Auto OS on Android device...
adb install -r -g algordo-auto-v1.4.0-universal.apk
pause
