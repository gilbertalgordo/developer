#!/usr/bin/env bash
# ==============================================================================
# Gilbert Algordo Automotive OS - Android & AAOS Automatic Sideload Script
# https://github.com/gilbertalgordo/developer/blob/main/full_android_auto.yaml
# Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
# ==============================================================================
set -euo pipefail

PACKAGE_NAME="com.gilbertalgordo.auto.universal"
APK_FILE="algordo-auto-v1.4.0-universal.apk"

echo "======================================================================"
echo " Starting Algordo Automotive OS Android / AAOS Deployment"
echo "======================================================================"

if ! command -v adb >/dev/null 2>&1; then
    echo "[ERROR] 'adb' command not found. Please install Android Platform Tools."
    exit 1
fi

echo "Checking connected devices..."
adb devices -l

echo "Installing $APK_FILE with full automotive permissions..."
adb install -r -d -g "$APK_FILE"

echo "Granting Automotive CAN, Bluetooth 5.2, and Wi-Fi Direct permissions..."
adb shell pm grant "$PACKAGE_NAME" android.permission.BLUETOOTH_CONNECT || true
adb shell pm grant "$PACKAGE_NAME" android.permission.BLUETOOTH_SCAN || true
adb shell pm grant "$PACKAGE_NAME" android.permission.NEARBY_WIFI_DEVICES || true
adb shell pm grant "$PACKAGE_NAME" android.permission.ACCESS_FINE_LOCATION || true

echo "Launching Algordo Auto OS Main Service..."
adb shell am start -n "$PACKAGE_NAME/.MainActivity"

echo "======================================================================"
echo " [SUCCESS] Algordo Auto OS successfully installed and launched!"
echo " Developer Profile: https://g.dev/gilbert_algordo"
echo "======================================================================"
