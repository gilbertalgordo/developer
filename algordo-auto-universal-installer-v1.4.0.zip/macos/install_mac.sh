#!/usr/bin/env bash
echo "Installing Algordo Auto OS Simulator on macOS..."
cp -R AlgordoAutoOS.app /Applications/
echo "Done! Launch AlgordoAutoOS from /Applications."
