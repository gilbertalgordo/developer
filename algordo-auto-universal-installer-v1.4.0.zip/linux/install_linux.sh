#!/usr/bin/env bash
# ==============================================================================
# Gilbert Algordo Automotive OS - Linux SocketCAN & Systemd Installer
# https://github.com/gilbertalgordo/developer/blob/main/full_android_auto.yaml
# Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
# ==============================================================================
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "[ERROR] Please run this installer as root: sudo bash install_linux.sh"
    exit 1
fi

echo "======================================================================"
echo " Installing Algordo Automotive OS Daemon for Linux / Raspberry Pi"
echo "======================================================================"

# 1. Setup SocketCAN interface
echo "[1/4] Configuring SocketCAN kernel modules..."
modprobe can || true
modprobe can_raw || true
modprobe vcan || true

if ! ip link show vcan0 >/dev/null 2>&1; then
    echo "Creating virtual CAN interface vcan0 (500 kbps)..."
    ip link add dev vcan0 type vcan
    ip link set up vcan0
fi

# 2. Deploy binary files
INSTALL_DIR="/opt/algordo-auto"
mkdir -p "$INSTALL_DIR"
cp -f algordo-auto-daemon "$INSTALL_DIR/" || true
chmod +x "$INSTALL_DIR/algordo-auto-daemon" || true

# 3. Create systemd service
echo "[2/4] Registering systemd daemon service..."
cat << 'EOF' > /etc/systemd/system/algordo-auto.service
[Unit]
Description=Gilbert Algordo Automotive Core Daemon
After=network.target sys-subsystem-net-devices-vcan0.device
Documentation=https://g.dev/gilbert_algordo

[Service]
Type=simple
User=root
WorkingDirectory=/opt/algordo-auto
ExecStart=/opt/algordo-auto/algordo-auto-daemon --can-bus=vcan0 --bitrate=500000 --region=EU_ISO_15765
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

# 4. Enable and start service
echo "[3/4] Starting service..."
systemctl daemon-reload
systemctl enable algordo-auto.service
systemctl restart algordo-auto.service || true

echo "======================================================================"
echo " [SUCCESS] Linux Automotive Daemon Active! Status: systemctl status algordo-auto"
echo "======================================================================"
