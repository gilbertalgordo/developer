#!/usr/bin/env bash
modprobe can can_raw vcan
ip link add dev vcan0 type vcan || true
ip link set up vcan0
echo "vcan0 ready at 500000 bps."
