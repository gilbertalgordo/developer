# ==============================================================================
# Gilbert Algordo Automotive OS - Windows Automotive Studio Installer
# https://github.com/gilbertalgordo/developer/blob/main/full_android_auto.yaml
# Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
# ==============================================================================

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " Installing Algordo Automotive OS Studio for Windows 10/11" -ForegroundColor Cyan
Write-Host " Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)" -ForegroundColor DarkCyan
Write-Host "======================================================================" -ForegroundColor Cyan

$InstallPath = "$env:ProgramFiles\AlgordoAutoOS"
if (!(Test-Path -Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
}

Write-Host "[1/3] Copying runtime packages to $InstallPath..." -ForegroundColor Green
Copy-Item -Path "*.*" -Destination $InstallPath -Recurse -Force

Write-Host "[2/3] Configuring virtual CAN bus loopback & serial bridge..." -ForegroundColor Green
Set-ItemProperty -Path "HKLM:\SOFTWARE\AlgordoAutoOS" -Name "CAN_Standard" -Value "ISO_15765" -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path "HKLM:\SOFTWARE\AlgordoAutoOS" -Name "TelemetrySync" -Value "https://telemetry.algordo.dev" -Force -ErrorAction SilentlyContinue

Write-Host "[3/3] Creating Desktop Shortcut..." -ForegroundColor Green
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Algordo Automotive OS.lnk")
$Shortcut.TargetPath = "$InstallPath\AlgordoAutoOS.exe"
$Shortcut.IconLocation = "$InstallPath\icon.ico"
$Shortcut.Description = "Gilbert Algordo Automotive Core & Diagnostic Studio"
$Shortcut.Save()

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " [SUCCESS] Installation complete! Launch from your Desktop shortcut." -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Cyan
