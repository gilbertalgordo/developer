# Gilbert Algordo Automotive Core - Universal Cross-Platform Installer
Version: 1.4.0
Repository: https://github.com/gilbertalgordo/developer/blob/main/full_android_auto.yaml
Developer Profile: https://g.dev/gilbert_algordo
Architecture: Universal Automotive OS (AAOS, CarPlay, Linux SocketCAN, Windows, macOS)

================================================================================
TABLE OF CONTENTS
================================================================================
1. Overview & Certified Standards
2. Android & Android Automotive OS (AAOS) Setup
3. Apple iOS & CarPlay Setup
4. Linux / Raspberry Pi / Yocto Automotive Setup
5. Windows 10/11 Diagnostic Studio Setup
6. macOS Head Unit Simulator Setup
7. Istio mTLS Certificates & Encryption
8. OpenSCAD 3D Display Enclosure Specs

================================================================================
1. OVERVIEW & CERTIFIED STANDARDS
================================================================================
This archive contains the official distribution binaries and deployment scripts
for Gilbert Algordo's Universal Automotive Operating System. It implements:
- ISO 15765-4 / ISO 14229 (UDS Diagnostics & 500 kbps 11/29-bit CAN)
- SAE J1939 (250 kbps Heavy Duty Commercial Powertrain Protocol)
- GB/T 27930 (China High-Voltage EV DC Fast Charging & BMS Protocol)
- UNECE R156 (Cryptographic Software Update Management Systems)
- BLE 5.2 & 5.8 GHz 802.11ac Wi-Fi Direct Projection Handshake

================================================================================
2. ANDROID / AAOS SETUP
================================================================================
Execute:
    chmod +x install_android.sh
    ./install_android.sh
Or run:
    adb install -r -g algordo-auto-universal-v1.4.0.apk

================================================================================
3. APPLE CARPLAY SETUP
================================================================================
1. Connect iPhone via USB-C or Lightning.
2. Sign 'AlgordoAuto-CarPlay-v1.4.0.ipa' with your Apple Developer
   profile containing the 'com.apple.developer.carplay-navigation' entitlement.
3. Install via Xcode Devices window or Sideloadly / AltStore.

================================================================================
4. LINUX & RASPBERRY PI SETUP
================================================================================
Run as root:
    sudo bash install_linux.sh

This automatically creates 'vcan0' and enables the 'algordo-auto.service' daemon.

================================================================================
5. WINDOWS SETUP
================================================================================
Open PowerShell as Administrator:
    Set-ExecutionPolicy RemoteSigned -Scope Process
    .\install_windows.ps1

================================================================================
6. MACOS SETUP
================================================================================
Mount the DMG or execute:
    chmod +x install_mac.sh
    ./install_mac.sh

================================================================================
Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
Licensed under Apache License 2.0
