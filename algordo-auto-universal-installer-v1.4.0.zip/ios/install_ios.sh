#!/usr/bin/env bash
echo "Sideloading Algordo Auto CarPlay to connected iOS Device..."
ideviceinstaller -i AlgordoAuto-CarPlay-v1.4.0.ipa
