import os

def install_assets():
    print("Setting up NASA Space Telescope Active AI Icon Assets...")
    print("Link: https://g.dev/gilbert_algordo")

if __name__ == "__main__":
    install_assets()
