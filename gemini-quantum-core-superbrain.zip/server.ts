import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type, FunctionDeclaration } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const require = createRequire(import.meta.url);
const { ZipArchive } = require('archiver');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// System diagnostic simulation function
const systemDiagnosticsNode = (component: string) => {
  const componentsMap: Record<string, any> = {
    quantum_array_01: {
      component: 'quantum_array_01',
      name: 'Quantum Array Primary Core',
      status: 'NOMINAL',
      latency_ms: 1.42,
      quantum_coherence: '99.98%',
      load_pct: 34,
      temperature_c: 18.2,
      description: 'Superconducting Qubit Matrix engaged in multi-tensor parallel operations.',
    },
    neural_synapse_alpha: {
      component: 'neural_synapse_alpha',
      name: 'Neural Synapse Alpha Pipeline',
      status: 'NOMINAL',
      latency_ms: 0.98,
      quantum_coherence: '99.99%',
      load_pct: 42,
      temperature_c: 19.5,
      description: 'Ultra-low latency spiking neural bridge with streaming activation weights.',
    },
    subspace_bus_9: {
      component: 'subspace_bus_9',
      name: 'Subspace Bus Route 9',
      status: 'OPTIMIZING',
      latency_ms: 2.10,
      quantum_coherence: '99.95%',
      load_pct: 28,
      temperature_c: 17.8,
      description: 'High-bandwidth inter-node tensor bus operating with dynamic error correction.',
    },
    cognitive_vector_mesh: {
      component: 'cognitive_vector_mesh',
      name: 'Cognitive Vector Embedding Mesh',
      status: 'NOMINAL',
      latency_ms: 1.15,
      quantum_coherence: '99.97%',
      load_pct: 55,
      temperature_c: 21.0,
      description: 'Hyper-dimensional semantic space routing search grounding vectors.',
    },
    quantum_memory_cache: {
      component: 'quantum_memory_cache',
      name: 'Zero-Decay Quantum Memory Cache',
      status: 'NOMINAL',
      latency_ms: 0.45,
      quantum_coherence: '100.00%',
      load_pct: 19,
      temperature_c: 16.5,
      description: 'Entangled NV-center diamond lattice memory storing active chat turn states.',
    },
  };

  const key = component.toLowerCase().trim();
  return (
    componentsMap[key] || {
      component,
      name: `${component} Node`,
      status: 'NOMINAL',
      latency_ms: 1.5,
      quantum_coherence: '99.96%',
      load_pct: 30,
      temperature_c: 18.0,
      description: 'Standard active core node operating within nominal telemetry limits.',
    }
  );
};

// Tool Declaration for Gemini
const diagnosticsToolDeclaration: FunctionDeclaration = {
  name: 'system_diagnostics_node',
  description: 'Retrieves active telemetry, latency, quantum coherence, and status for specified AI core hardware nodes.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      component: {
        type: Type.STRING,
        description: "The component key to diagnose, e.g., 'quantum_array_01', 'neural_synapse_alpha', 'subspace_bus_9', 'cognitive_vector_mesh', 'quantum_memory_cache'",
      },
    },
    required: ['component'],
  },
};

// API: Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'NOMINAL',
    model: 'gemini-3.6-flash',
    uptime: Math.floor(process.uptime()),
    quantumCoherence: 99.98,
    activeNodes: 5,
    apiKeyConfigured: !!process.env.GEMINI_API_KEY,
  });
});

// API: Download Project as ZIP Package
app.get('/api/download-zip', (req, res) => {
  try {
    const archive = new ZipArchive({
      zlib: { level: 9 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="gemini-quantum-core-superbrain.zip"'
    );

    archive.on('warning', (err: any) => {
      if (err.code === 'ENOENT') {
        console.warn('Archiver warning:', err);
      } else {
        throw err;
      }
    });

    archive.on('error', (err: any) => {
      console.error('Archiver error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Failed to create zip package' });
      }
    });

    archive.pipe(res);

    const rootDir = process.cwd();

    // Package the project files, excluding node_modules, git, and dist
    archive.glob('**/*', {
      cwd: rootDir,
      ignore: [
        'node_modules/**',
        '.git/**',
        'dist/**',
        '.cache/**',
        '.aistudio/**',
        '*.log',
      ],
      dot: true,
    });

    archive.finalize();
  } catch (error: any) {
    console.error('Zip generation route error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message || 'Zip generation failure' });
    }
  }
});

// API: System Diagnostics Endpoint
app.post('/api/system-diagnostics', (req, res) => {
  const { component } = req.body;
  if (component) {
    res.json(systemDiagnosticsNode(component));
  } else {
    // Return all nodes
    const allComponents = [
      'quantum_array_01',
      'neural_synapse_alpha',
      'subspace_bus_9',
      'cognitive_vector_mesh',
      'quantum_memory_cache',
    ];
    const results = allComponents.map((c) => systemDiagnosticsNode(c));
    res.json({ nodes: results });
  }
});

// API: Cognitive Telemetry (Structured Output)
app.post('/api/cognitive-telemetry', async (req, res) => {
  try {
    const { task } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback response if no API key
      const cycleNum = Math.floor(Math.random() * 9000) + 1000;
      return res.json({
        step_id: `STEP-${cycleNum}`,
        confidence_score: 0.98,
        primary_vector: 'QUANTUM_LOCAL_SIMULATION',
        subtasks: [
          'Initialize local quantum node state',
          'Map active tensor execution subgraphs',
          'Execute synthetic reasoning vector',
          'Verify quantum coherence metrics',
        ],
        quantum_coherence: 99.98,
        timestamp: Date.now(),
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: `Analyze and generate structured execution cognitive telemetry for task: "${task || 'Deploy multi-node active agent orchestration'}"`,
      config: {
        systemInstruction: 'You are the Gemini Quantum Core Super Brain active reasoning engine. Generate precise structured execution telemetry for technical AI agent tasks.',
        temperature: 0.1,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            step_id: {
              type: Type.STRING,
              description: 'Unique step identifier e.g., STEP-1042',
            },
            confidence_score: {
              type: Type.NUMBER,
              description: 'Execution confidence index from 0.0 to 1.0',
            },
            primary_vector: {
              type: Type.STRING,
              description: 'Primary active strategy or cognitive vector',
            },
            subtasks: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Ordered list of subtasks for execution',
            },
            quantum_coherence: {
              type: Type.NUMBER,
              description: 'Calculated quantum coherence percentage e.g. 99.98',
            },
          },
          required: ['step_id', 'confidence_score', 'primary_vector', 'subtasks'],
        },
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      return res.json({
        ...data,
        timestamp: Date.now(),
      });
    }

    throw new Error('Empty response text');
  } catch (err: any) {
    console.error('Cognitive Telemetry Error:', err?.message || err);
    const cycleNum = Math.floor(Math.random() * 9000) + 1000;
    const isQuota = String(err?.message || '').includes('429') || String(err?.message || '').includes('RESOURCE_EXHAUSTED');
    
    // Synthesize structured telemetry fallback dynamically based on prompt
    const promptText = req.body?.task || 'Deploy multi-node active agent orchestration';
    const subtaskList = [
      `Initialize high-bandwidth SSE stream for "${promptText.slice(0, 30)}..."`,
      'Decompose non-blocking async subtask graph',
      'Execute dynamic quantum tensor routing & node verification',
      'Maintain sub-millisecond local latency loop',
    ];

    return res.json({
      step_id: `STEP-${cycleNum}`,
      confidence_score: isQuota ? 0.95 : 0.92,
      primary_vector: isQuota ? 'QUANTUM_FAILSAFE_SIMULATION' : 'QUANTUM_FAILSAFE_VECTOR',
      subtasks: subtaskList,
      quantum_coherence: 99.98,
      timestamp: Date.now(),
    });
  }
});

// API: Real-time Streaming Core (SSE)
app.post('/api/stream-core', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const sendSSE = (event: string, data: any) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const cycleId = `CYC-${Math.floor(Math.random() * 9000) + 1000}`;
  const startTime = Date.now();

  const {
    prompt,
    systemInstruction,
    temperature = 0.2,
    enableSearchGrounding = true,
    enableDiagnosticsTools = true,
    overrideDomain = 'google.com',
  } = req.body;

  sendSSE('telemetry', {
    event_type: 'CYCLE_START',
    payload: {
      cycle_id: cycleId,
      prompt,
      overrideDomain,
      timestamp: new Date().toISOString(),
    },
    level: 'info',
  });

  const ai = getGeminiClient();

  if (!ai) {
    // Simulated fallback stream if API key is not present
    sendSSE('telemetry', {
      event_type: 'HUD TELEMETRY',
      payload: { mode: 'SIMULATION_FALLSAFE', note: 'Operating on local Quantum Active Engine fallback' },
      level: 'warn',
    });

    const fallbackChunks = [
      `### [GEMINI QUANTUM CORE SUPER BRAIN - LOCAL MODE]\n\n`,
      `**Cycle ID**: \`${cycleId}\` | **Coherence**: \`99.98%\` | **Target Vector**: \`QUANTUM_AGENT_ORCHESTRATION\`\n\n`,
      `Analyzing execution parameters for: *"${prompt}"*\n\n`,
      `#### Hardware Diagnostics Dispatch:\n`,
      `- **quantum_array_01**: Status NOMINAL (1.42ms latency, 99.98% coherence)\n`,
      `- **neural_synapse_alpha**: Status NOMINAL (0.98ms latency, 99.99% coherence)\n\n`,
      `#### Strategic Plan & Recommendations:\n`,
      `1. **Ultra-Low Latency Streaming**: Utilizing SSE chunks for continuous sub-50ms token dispatch.\n`,
      `2. **Parallel Subtask Orchestration**: Decomposing problem into non-blocking async loops.\n`,
      `3. **Coherence Monitoring**: Real-time feedback loop maintaining >99.90% quantum fidelity.\n\n`,
      `> *Note: Attach a valid GEMINI_API_KEY in Secrets for direct live Gemini 3.6 Flash inference with Grounding.*`,
    ];

    for (const chunk of fallbackChunks) {
      sendSSE('chunk', { text: chunk });
      await new Promise((r) => setTimeout(r, 120));
    }

    sendSSE('telemetry', {
      event_type: 'CYCLE_COMPLETE',
      payload: { cycle_id: cycleId, duration_ms: Date.now() - startTime, status: 'COMPLETED' },
      level: 'success',
    });

    sendSSE('done', { cycle_id: cycleId, duration_ms: Date.now() - startTime });
    return res.end();
  }

  try {
    const tools: any[] = [];
    if (enableDiagnosticsTools) {
      tools.push({ functionDeclarations: [diagnosticsToolDeclaration] });
    }
    if (enableSearchGrounding) {
      tools.push({ googleSearch: {} });
    }

    const defaultSysInstruction =
      'You are the Gemini Quantum Core Super Brain Active AI Engine. ' +
      'Execute technical requests with extreme analytical precision, high-speed modular architecture, ' +
      'and active tool dispatching. Format output cleanly in Markdown with high-visibility HUD code snippets.' +
      ` [DOMAIN OVERRIDE ACTIVE]: Ground search references and queries strictly through ${overrideDomain}.`;

    const config: any = {
      systemInstruction: (systemInstruction || defaultSysInstruction) + ` [Domain Override: ${overrideDomain}]`,
      temperature: Number(temperature) || 0.2,
    };

    if (tools.length > 0) {
      config.tools = tools;
      if (enableDiagnosticsTools && enableSearchGrounding) {
        config.toolConfig = { includeServerSideToolInvocations: true };
      }
    }

    // Step 1: Execute generateContent first to handle potential function calls
    sendSSE('telemetry', {
      event_type: 'HUD TELEMETRY',
      payload: { status: 'DISPATCHING_TENSORS', model: 'gemini-3.6-flash' },
      level: 'info',
    });

    const initialRes = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config,
    });

    // Handle tool call execution if requested by the model
    if (initialRes.functionCalls && initialRes.functionCalls.length > 0) {
      for (const fc of initialRes.functionCalls) {
        sendSSE('telemetry', {
          event_type: 'FUNCTION_CALL_DISPATCH',
          payload: { name: fc.name, args: fc.args },
          level: 'dispatch',
        });

        let toolResult: any = {};
        if (fc.name === 'system_diagnostics_node') {
          const compArg = (fc.args as any)?.component || 'quantum_array_01';
          toolResult = systemDiagnosticsNode(String(compArg));
        }

        sendSSE('telemetry', {
          event_type: 'FUNCTION_RESULT',
          payload: toolResult,
          level: 'success',
        });

        // Send a follow-up stream containing the function execution context
        const followUpStream = await ai.models.generateContentStream({
          model: 'gemini-3.6-flash',
          contents: [
            initialRes.candidates?.[0]?.content || { role: 'model', parts: [{ text: '' }] },
            {
              role: 'user',
              parts: [
                {
                  text: `Function call ${fc.name} returned result: ${JSON.stringify(toolResult)}. Incorporate these diagnostic metrics into your analysis response.`,
                },
              ],
            },
          ],
          config,
        });

        for await (const chunk of followUpStream) {
          if (chunk.text) {
            sendSSE('chunk', { text: chunk.text });
          }
        }
      }
    } else {
      // Stream initial response directly
      if (initialRes.text) {
        sendSSE('chunk', { text: initialRes.text });
      }

      // Check for Google Search grounding metadata
      const groundingChunks = initialRes.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (groundingChunks && groundingChunks.length > 0) {
        const sources = groundingChunks
          .map((c: any) => ({ title: c.web?.title, uri: c.web?.uri }))
          .filter((s: any) => s.uri);

        sendSSE('telemetry', {
          event_type: 'GROUNDING_SEARCH',
          payload: { sources_found: sources.length, sources },
          level: 'info',
        });

        sendSSE('grounding', { sources });
      }
    }

    sendSSE('telemetry', {
      event_type: 'CYCLE_COMPLETE',
      payload: { cycle_id: cycleId, duration_ms: Date.now() - startTime, status: 'COMPLETED' },
      level: 'success',
    });

    sendSSE('done', { cycle_id: cycleId, duration_ms: Date.now() - startTime });
    res.end();
  } catch (err: any) {
    console.error('Streaming Core Error:', err?.message || err);
    const errMsg = String(err?.message || '');
    const isQuotaError = errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('quota');

    if (isQuotaError) {
      sendSSE('telemetry', {
        event_type: 'HUD TELEMETRY',
        payload: {
          status: 'FAILSAFE_LOCAL_SIMULATION',
          note: 'API Quota Exceeded (HTTP 429) - Engaged local Gemini Quantum Core engine fallback',
        },
        level: 'warn',
      });

      const fallbackChunks = [
        `> 💡 **[QUANTUM CORE NOTICE]**: *API Rate Limit / Quota Exceeded (HTTP 429). Seamless local Quantum Core Engine fallback activated.*\n\n`,
        `> 🌐 **[DOMAIN OVERRIDE ENGAGED]**: *Search grounding & routing restricted to domain:* \`${overrideDomain}\`\n\n`,
        `### [GEMINI QUANTUM CORE SUPER BRAIN - LOCAL SYNTHESIS]\n\n`,
        `**Cycle ID**: \`${cycleId}\` | **Coherence**: \`99.982%\` | **Target Vector**: \`QUANTUM_AGENT_ORCHESTRATION\`\n\n`,
        `Analyzing requested parameters for: *"${prompt}"*\n\n`,
        `#### Hardware Diagnostics Summary:\n`,
        `- **quantum_array_01**: Status NOMINAL (1.42ms latency, 99.98% coherence)\n`,
        `- **neural_synapse_alpha**: Status NOMINAL (0.98ms latency, 99.99% coherence)\n`,
        `- **cognitive_vector_mesh**: Status NOMINAL (1.15ms latency, 99.97% coherence)\n\n`,
        `#### Executive Execution Plan & Findings:\n`,
        `1. **Sub-millisecond Token Streaming**: Utilizing high-frequency non-blocking SSE chunk streams.\n`,
        `2. **Domain Override Active**: Directing search grounding queries specifically through \`${overrideDomain}\`.\n`,
        `3. **Parallel Subtask Decomposition**: Routing inference vectors across distributed tensor nodes.\n`,
        `4. **Resonance Lock**: Maintaining 99.98% quantum coherence with zero-loss state persistence.\n\n`,
        `> *The Quantum Core system remains fully operational and responsive with domain override applied.*`,
      ];

      for (const chunk of fallbackChunks) {
        sendSSE('chunk', { text: chunk });
        await new Promise((r) => setTimeout(r, 80));
      }

      sendSSE('telemetry', {
        event_type: 'CYCLE_COMPLETE',
        payload: { cycle_id: cycleId, duration_ms: Date.now() - startTime, status: 'COMPLETED' },
        level: 'success',
      });

      sendSSE('done', { cycle_id: cycleId, duration_ms: Date.now() - startTime });
      return res.end();
    }

    sendSSE('telemetry', {
      event_type: 'ENGINE_ERROR',
      payload: { error: err.message || 'Stream processing exception' },
      level: 'error',
    });
    sendSSE('chunk', {
      text: `\n\n> ⚠️ **[QUANTUM ENGINE EXCEPTION]**: ${err.message || 'Unknown stream error'}. Failsafe local state retained.`,
    });
    sendSSE('done', { cycle_id: cycleId, status: 'error' });
    res.end();
  }
});

// Setup Vite Development or Production Server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Gemini Quantum Core Super Brain] Running on http://localhost:${PORT}`);
  });
}

startServer();
