import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

// Minimal PNG encoder for pure Node without native dependencies
function createPNG(width, height, getPixel) {
  const bytesPerPixel = 4; // RGBA
  const rowSize = width * bytesPerPixel;
  const rawData = Buffer.alloc(height * (rowSize + 1));

  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter type: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y, width, height);
      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function crc32(buf) {
    let c = 0xffffffff;
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let v = n;
      for (let k = 0; k < 8; k++) {
        v = (v & 1) ? (0xedb88320 ^ (v >>> 1)) : (v >>> 1);
      }
      table[n] = v;
    }
    for (let i = 0; i < buf.length; i++) {
      c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const combined = Buffer.concat([typeBuf, data]);
    crcBuf.writeUInt32BE(crc32(combined), 0);
    return Buffer.concat([len, combined, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 72, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth
  ihdr.writeUInt8(6, 9); // color type RGBA
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function drawQuantumIcon(x, y, w, h, isMaskable = false) {
  const cx = w / 2;
  const cy = h / 2;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const radius = w * 0.46;

  // Background gradient: Dark deep obsidian & navy
  const normDist = dist / (w * 0.7);
  let bgR = Math.floor(10 * (1 - normDist) + 3);
  let bgG = Math.floor(22 * (1 - normDist) + 7);
  let bgB = Math.floor(40 * (1 - normDist) + 18);

  // Border ring
  if (!isMaskable && dist > radius - 2 && dist < radius + 2) {
    return [34, 211, 238, 255]; // Cyan border
  }

  // Quantum core rings
  const ring1 = Math.abs(dist - w * 0.35);
  if (ring1 < 2) return [56, 189, 248, 180];

  const ring2 = Math.abs(dist - w * 0.25);
  if (ring2 < 2.5) return [129, 140, 248, 220];

  // Center glowing core
  if (dist < w * 0.08) {
    return [34, 211, 238, 255]; // Cyan Core
  } else if (dist < w * 0.12) {
    const alpha = Math.floor(255 * (1 - (dist - w * 0.08) / (w * 0.04)));
    return [103, 232, 249, alpha];
  }

  // Neural nodes (Left & Right hemispheres)
  const nodeLeft = Math.hypot(x - (cx - w * 0.2), y - (cy - h * 0.1));
  const nodeRight = Math.hypot(x - (cx + w * 0.2), y - (cy - h * 0.1));
  const nodeBotL = Math.hypot(x - (cx - w * 0.15), y - (cy + h * 0.18));
  const nodeBotR = Math.hypot(x - (cx + w * 0.15), y - (cy + h * 0.18));

  if (nodeLeft < w * 0.035 || nodeRight < w * 0.035) return [34, 211, 238, 255];
  if (nodeBotL < w * 0.03 || nodeBotR < w * 0.03) return [129, 140, 248, 255];

  // Neural connector rays
  const angle = Math.atan2(dy, dx);
  const sinPattern = Math.sin(angle * 6);
  if (Math.abs(sinPattern) > 0.95 && dist > w * 0.1 && dist < w * 0.35) {
    return [56, 189, 248, 120];
  }

  return [bgR, bgG, bgB, 255];
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Generate 192x192
const icon192 = createPNG(192, 192, (x, y, w, h) => drawQuantumIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), icon192);

// 2. Generate 512x512
const icon512 = createPNG(512, 512, (x, y, w, h) => drawQuantumIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), icon512);

// 3. Generate 512x512 maskable (safe padded zone)
const iconMaskable = createPNG(512, 512, (x, y, w, h) => drawQuantumIcon(x, y, w, h, true));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), iconMaskable);

// 4. Generate Apple Touch Icon 180x180
const iconApple = createPNG(180, 180, (x, y, w, h) => drawQuantumIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), iconApple);

// 5. Generate Favicon
const favicon = createPNG(64, 64, (x, y, w, h) => drawQuantumIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), favicon);

console.log('Successfully generated PWA and Apple Touch PNG icons in /public');
