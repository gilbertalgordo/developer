import React, { useState } from 'react';
import { SystemNodeStatus } from '../types';
import { soundEngine } from '../utils/sound';
import { Cpu, RefreshCw, Eye, Sparkles, Flame, ShieldAlert, Layers } from 'lucide-react';

interface QuantumBrainVisualizerProps {
  nodes: SystemNodeStatus[];
  selectedNode: SystemNodeStatus | null;
  onSelectNode: (node: SystemNodeStatus) => void;
  onTriggerScan: () => void;
  isScanning: boolean;
}

export const QuantumBrainVisualizer: React.FC<QuantumBrainVisualizerProps> = ({
  nodes,
  selectedNode,
  onSelectNode,
  onTriggerScan,
  isScanning,
}) => {
  const [viewMode, setViewMode] = useState<'3d_mesh' | 'blueprint' | 'heatmap'>('3d_mesh');

  const getNodeData = (id: string) => {
    return (
      nodes.find((n) => n.component.toLowerCase() === id.toLowerCase()) || {
        component: id,
        name: id,
        status: 'NOMINAL',
        latency_ms: 1.42,
        quantum_coherence: '99.98%',
        load_pct: 35,
        temperature_c: 18.2,
        description: 'Active quantum node operating within nominal parameters.',
      }
    );
  };

  const handleNodeClick = (nodeId: string) => {
    soundEngine.playScanSound();
    const node = getNodeData(nodeId);
    onSelectNode(node);
  };

  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 backdrop-blur-sm shadow-2xl relative overflow-hidden flex flex-col h-full">
      {/* HUD Background Grid Lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#22d3ee_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 z-10">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <h2 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest font-mono">
            Neural Pathways & Brain Core
          </h2>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-lg p-1 text-[10px] font-mono">
          <button
            onClick={() => {
              setViewMode('3d_mesh');
              soundEngine.playBeep(700, 0.04);
            }}
            className={`px-2.5 py-1 rounded transition-all flex items-center gap-1.5 ${
              viewMode === '3d_mesh'
                ? 'bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 font-bold shadow-[0_0_8px_#22d3ee]'
                : 'text-zinc-500 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            3D MESH
          </button>
          <button
            onClick={() => {
              setViewMode('blueprint');
              soundEngine.playBeep(700, 0.04);
            }}
            className={`px-2.5 py-1 rounded transition-all flex items-center gap-1.5 ${
              viewMode === 'blueprint'
                ? 'bg-purple-500/20 border border-purple-400/40 text-purple-300 font-bold shadow-[0_0_8px_#a855f7]'
                : 'text-zinc-500 hover:text-zinc-200'
            }`}
          >
            <Layers className="w-3 h-3" />
            BLUEPRINT
          </button>
          <button
            onClick={() => {
              setViewMode('heatmap');
              soundEngine.playBeep(700, 0.04);
            }}
            className={`px-2.5 py-1 rounded transition-all flex items-center gap-1.5 ${
              viewMode === 'heatmap'
                ? 'bg-amber-500/20 border border-amber-400/40 text-amber-300 font-bold shadow-[0_0_8px_#f59e0b]'
                : 'text-zinc-500 hover:text-zinc-200'
            }`}
          >
            <Flame className="w-3 h-3" />
            HEATMAP
          </button>
        </div>
      </div>

      {/* SVG Canvas Container */}
      <div className="relative flex-1 min-h-[340px] flex items-center justify-center bg-black/40 rounded-xl border border-white/5 overflow-hidden group">
        <svg
          viewBox="0 0 512 512"
          className="w-full h-full max-h-[420px] select-none transition-transform duration-700 hover:scale-105"
        >
          <defs>
            {/* Glowing Radial Gradients */}
            <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.95" />
              <stop offset="50%" stopColor="#a855f7" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#020205" stopOpacity="0" />
            </radialGradient>

            <linearGradient id="cyanPurple" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#a855f7" />
            </linearGradient>

            <linearGradient id="amberGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#f59e0b" />
            </linearGradient>

            {/* Neon Glow Filter */}
            <filter id="neonFilter" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background HUD Matrix Grid */}
          <g stroke={viewMode === 'heatmap' ? '#f59e0b' : '#22d3ee'} strokeWidth="1" opacity={viewMode === 'blueprint' ? 0.35 : 0.15} fill="none">
            <circle cx="256" cy="256" r="220" strokeDasharray="8 8" />
            <circle cx="256" cy="256" r="180" />
            <circle cx="256" cy="256" r="140" strokeDasharray="4 4" />
            <line x1="36" y1="256" x2="476" y2="256" />
            <line x1="256" y1="36" x2="256" y2="476" />
          </g>

          {/* Ambient Core Glow */}
          <circle cx="256" cy="256" r="120" fill="url(#coreGlow)" opacity={viewMode === 'heatmap' ? 0.9 : 0.75} />

          {/* Orbiting Quantum Rings */}
          <circle
            cx="256"
            cy="256"
            r="150"
            fill="none"
            stroke={viewMode === 'heatmap' ? 'url(#amberGold)' : 'url(#cyanPurple)'}
            strokeWidth="3"
            strokeDasharray="180 40"
            filter="url(#neonFilter)"
          >
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="0 256 256"
              to="360 256 256"
              dur="12s"
              repeatCount="indefinite"
            />
          </circle>

          <circle
            cx="256"
            cy="256"
            r="190"
            fill="none"
            stroke="#22d3ee"
            strokeWidth="1.5"
            strokeDasharray="90 30"
            opacity="0.4"
          >
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="360 256 256"
              to="0 256 256"
              dur="20s"
              repeatCount="indefinite"
            />
          </circle>

          {/* Brain Circuit Neural Mesh */}
          <g
            fill="none"
            stroke={viewMode === 'heatmap' ? '#f59e0b' : '#22d3ee'}
            strokeWidth="2.5"
            strokeLinecap="round"
            filter="url(#neonFilter)"
          >
            <path d="M 256 160 C 210 160 170 190 170 240 C 170 280 200 310 230 330 C 245 340 256 352 256 352" />
            <path d="M 256 160 C 302 160 342 190 342 240 C 342 280 312 310 282 330 C 267 340 256 352 256 352" />
            <path d="M 210 200 C 240 220 272 220 302 200" strokeDasharray="3 3" />
            <path d="M 190 256 C 230 270 282 270 322 256" />
            <path d="M 220 300 C 240 310 272 310 292 300" />
          </g>

          {/* Pulsing Inter-Node Connection Lines */}
          <g stroke="#22d3ee" strokeWidth="1.5" opacity="0.6">
            <line x1="256" y1="160" x2="170" y2="240" />
            <line x1="256" y1="160" x2="342" y2="240" />
            <line x1="170" y1="240" x2="230" y2="330" />
            <line x1="342" y1="240" x2="282" y2="330" />
            <line x1="230" y1="330" x2="282" y2="330" />
            <line x1="256" y1="256" x2="256" y2="160" />
            <line x1="256" y1="256" x2="170" y2="240" />
            <line x1="256" y1="256" x2="342" y2="240" />
            <line x1="256" y1="256" x2="230" y2="330" />
            <line x1="256" y1="256" x2="282" y2="330" />
          </g>

          {/* Interactive Quantum Hardware Nodes */}
          {/* Node 1: Top - quantum_array_01 */}
          <g
            className="cursor-pointer transition-transform duration-300 hover:scale-125"
            onClick={() => handleNodeClick('quantum_array_01')}
          >
            <circle
              cx="256"
              cy="160"
              r={selectedNode?.component === 'quantum_array_01' ? '12' : '8'}
              fill={selectedNode?.component === 'quantum_array_01' ? '#fbbf24' : '#ffffff'}
              stroke="#22d3ee"
              strokeWidth="3"
              filter="url(#neonFilter)"
            />
            <text x="256" y="140" textAnchor="middle" fill="#22d3ee" fontSize="10" fontFamily="monospace" fontWeight="bold">
              quantum_array_01
            </text>
          </g>

          {/* Node 2: Left - neural_synapse_alpha */}
          <g
            className="cursor-pointer transition-transform duration-300 hover:scale-125"
            onClick={() => handleNodeClick('neural_synapse_alpha')}
          >
            <circle
              cx="170"
              cy="240"
              r={selectedNode?.component === 'neural_synapse_alpha' ? '12' : '8'}
              fill={selectedNode?.component === 'neural_synapse_alpha' ? '#fbbf24' : '#ffffff'}
              stroke="#22d3ee"
              strokeWidth="3"
              filter="url(#neonFilter)"
            />
            <text x="130" y="244" textAnchor="end" fill="#22d3ee" fontSize="10" fontFamily="monospace" fontWeight="bold">
              neural_synapse_alpha
            </text>
          </g>

          {/* Node 3: Right - subspace_bus_9 */}
          <g
            className="cursor-pointer transition-transform duration-300 hover:scale-125"
            onClick={() => handleNodeClick('subspace_bus_9')}
          >
            <circle
              cx="342"
              cy="240"
              r={selectedNode?.component === 'subspace_bus_9' ? '12' : '8'}
              fill={selectedNode?.component === 'subspace_bus_9' ? '#fbbf24' : '#ffffff'}
              stroke="#22d3ee"
              strokeWidth="3"
              filter="url(#neonFilter)"
            />
            <text x="358" y="244" textAnchor="start" fill="#22d3ee" fontSize="10" fontFamily="monospace" fontWeight="bold">
              subspace_bus_9
            </text>
          </g>

          {/* Node 4: Bottom Left - cognitive_vector_mesh */}
          <g
            className="cursor-pointer transition-transform duration-300 hover:scale-125"
            onClick={() => handleNodeClick('cognitive_vector_mesh')}
          >
            <circle
              cx="230"
              cy="330"
              r={selectedNode?.component === 'cognitive_vector_mesh' ? '12' : '8'}
              fill={selectedNode?.component === 'cognitive_vector_mesh' ? '#fbbf24' : '#ffffff'}
              stroke="#22d3ee"
              strokeWidth="3"
              filter="url(#neonFilter)"
            />
            <text x="210" y="352" textAnchor="end" fill="#22d3ee" fontSize="10" fontFamily="monospace" fontWeight="bold">
              cognitive_vector_mesh
            </text>
          </g>

          {/* Node 5: Bottom Right - quantum_memory_cache */}
          <g
            className="cursor-pointer transition-transform duration-300 hover:scale-125"
            onClick={() => handleNodeClick('quantum_memory_cache')}
          >
            <circle
              cx="282"
              cy="330"
              r={selectedNode?.component === 'quantum_memory_cache' ? '12' : '8'}
              fill={selectedNode?.component === 'quantum_memory_cache' ? '#fbbf24' : '#ffffff'}
              stroke="#22d3ee"
              strokeWidth="3"
              filter="url(#neonFilter)"
            />
            <text x="302" y="352" textAnchor="start" fill="#22d3ee" fontSize="10" fontFamily="monospace" fontWeight="bold">
              quantum_memory_cache
            </text>
          </g>

          {/* Central Active Core Nucleus */}
          <g className="cursor-pointer" onClick={() => handleNodeClick('quantum_array_01')}>
            <circle cx="256" cy="256" r="22" fill="#ffffff" filter="url(#neonFilter)">
              <animate attributeName="r" values="18;26;18" dur="2.5s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.8;1;0.8" dur="2.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="256" cy="256" r="32" fill="none" stroke="#22d3ee" strokeWidth="2.5">
              <animate attributeName="r" values="28;38;28" dur="2.5s" repeatCount="indefinite" />
            </circle>
            <text x="256" y="260" textAnchor="middle" fill="#020205" fontSize="9" fontFamily="monospace" fontWeight="black">
              CORE
            </text>
          </g>
        </svg>

        {/* Floating Scan Button */}
        <button
          onClick={() => {
            soundEngine.playScanSound();
            onTriggerScan();
          }}
          disabled={isScanning}
          className="absolute bottom-3 right-3 px-3.5 py-1.5 rounded-lg bg-black/60 hover:bg-black/80 border border-white/10 text-cyan-300 text-[10px] font-mono transition-all flex items-center gap-2 shadow-lg backdrop-blur-md"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isScanning ? 'animate-spin' : ''}`} />
          {isScanning ? 'SCANNING CORE...' : 'RE-SCAN HARDWARE'}
        </button>
      </div>

      {/* Selected Node Detailed Inspector Callout */}
      {selectedNode && (
        <div className="mt-4 p-3 rounded-lg bg-black/40 border border-white/10 text-[11px] font-mono flex flex-wrap items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping shadow-[0_0_8px_#22d3ee]" />
            <div>
              <span className="text-zinc-500 uppercase">NODE:</span>{' '}
              <strong className="text-cyan-300">{selectedNode.name}</strong>
              <span className="ml-1 text-zinc-600">({selectedNode.component})</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-zinc-300">
            <div>
              LATENCY: <strong className="text-emerald-400">{selectedNode.latency_ms}ms</strong>
            </div>
            <div>
              COHERENCE: <strong className="text-cyan-400">{selectedNode.quantum_coherence}</strong>
            </div>
            <div>
              LOAD: <strong className="text-purple-400">{selectedNode.load_pct}%</strong>
            </div>
            <div>
              TEMP: <strong className="text-zinc-300">{selectedNode.temperature_c}°C</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
