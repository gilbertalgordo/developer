import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-xl bg-amber-500/90 backdrop-blur-md px-3.5 py-2 text-xs font-mono font-medium text-black shadow-[0_0_20px_rgba(245,158,11,0.5)] border border-amber-300">
      <WifiOff className="w-4 h-4 animate-bounce" />
      <span>OFFLINE MODE — Active Quantum Cache Engaged</span>
    </div>
  );
};
