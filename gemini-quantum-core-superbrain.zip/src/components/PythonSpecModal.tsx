import React, { useState } from 'react';
import { X, Copy, Check, Code, FileText, Download } from 'lucide-react';
import { soundEngine } from '../utils/sound';

interface PythonSpecModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonSpecModal: React.FC<PythonSpecModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'python_core' | 'pydantic_schema' | 'yaml_spec'>('python_core');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const pythonCoreCode = `import os
import time
from typing import AsyncGenerator
from google import genai
from google.genai import types

class ActiveAICore:
    """
    Active AI Core engine leveraging Gemini for real-time, high-speed 
    multimodal understanding and agentic task orchestration.
    """
    def __init__(self, api_key: str = None, model: str = "gemini-3.6-flash"):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY must be provided or set in environment variables.")
        
        # Initialize official GenAI client
        self.client = genai.Client(api_key=self.api_key)
        self.model = model
        self.active_session = None

    def initialize_active_session(self, system_instruction: str = None):
        """Initializes a persistent interactive chat session."""
        default_instruction = (
            "You are an Active Core AI agent. Provide precise, highly analytical, "
            "and structured real-time reasoning for complex technical tasks."
        )
        config = types.GenerateContentConfig(
            system_instruction=system_instruction or default_instruction,
            temperature=0.2,
        )
        self.active_session = self.client.chats.create(
            model=self.model,
            config=config
        )
        print(f"[{time.strftime('%H:%M:%S')}] Active AI Core session initialized with model: {self.model}")

    def execute_reasoning(self, prompt: str) -> str:
        """Executes a single reasoning step and returns structured output."""
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt
        )
        return response.text

    async def stream_active_core(self, prompt: str) -> AsyncGenerator[str, None]:
        """Streams response tokens in real-time for continuous processing."""
        response = self.client.models.generate_content_stream(
            model=self.model,
            contents=prompt
        )
        for chunk in response:
            if chunk.text:
                yield chunk.text`;

  const pydanticCode = `import asyncio
import json
import os
import time
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

class CognitiveTelemetry(BaseModel):
    """Schema for structured reasoning telemetry and state logging."""
    step_id: str = Field(description="Unique identifier for the processing cycle")
    confidence_score: float = Field(description="Execution confidence index from 0.0 to 1.0")
    primary_vector: str = Field(description="Dominant action or reasoning vector")
    subtasks: List[str] = Field(default_factory=list, description="Decomposed tasks")

class AdvancedQuantumCore:
    """
    Advanced Gemini-powered Active AI Core Engine featuring:
    - Parallel tool dispatch
    - Continuous response streaming
    - Real-time search grounding integration
    - Structured JSON execution schemas
    """
    def __init__(self, api_key: Optional[str] = None, model_name: str = "gemini-3.6-flash"):
        self.client = genai.Client(api_key=api_key or os.environ.get("GEMINI_API_KEY"))
        self.model = model_name

    async def generate_structured_telemetry(self, task_description: str) -> CognitiveTelemetry:
        config = types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=CognitiveTelemetry,
            temperature=0.1,
        )
        prompt = f"Analyze and structure execution plan for task: {task_description}"
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=config
        )
        return CognitiveTelemetry.model_validate_json(response.text)`;

  const yamlSpec = `version: "2.5"
name: "gemini_quantum_core_brain"
architecture:
  primary_engine: "google-genai-sdk"
  model: "gemini-3.6-flash"
  streaming: "SSE / chunked token dispatch"
  structured_telemetry: "CognitiveTelemetry Pydantic / JSON Schema"
hardware_nodes:
  - id: "quantum_array_01"
    latency: "1.42ms"
    coherence: "99.98%"
  - id: "neural_synapse_alpha"
    latency: "0.98ms"
    coherence: "99.99%"
  - id: "subspace_bus_9"
    latency: "2.10ms"
    coherence: "99.95%"
  - id: "cognitive_vector_mesh"
    latency: "1.15ms"
    coherence: "99.97%"
  - id: "quantum_memory_cache"
    latency: "0.45ms"
    coherence: "100.00%"`;

  const getCurrentCode = () => {
    if (activeTab === 'python_core') return pythonCoreCode;
    if (activeTab === 'pydantic_schema') return pydanticCode;
    return yamlSpec;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCurrentCode());
    setCopied(true);
    soundEngine.playBeep(900, 0.05);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-mono">
      <div className="bg-black/90 border border-white/10 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-black/40">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-zinc-200 text-xs tracking-wider uppercase">
              Python Specification & SDK Code
            </h3>
          </div>
          <button
            onClick={() => {
              soundEngine.playBeep(500, 0.04);
              onClose();
            }}
            className="p-1 hover:bg-white/[0.06] rounded text-zinc-400 hover:text-zinc-200 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 px-4 py-2 bg-white/[0.02] border-b border-white/10 text-xs">
          <button
            onClick={() => setActiveTab('python_core')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'python_core' ? 'bg-cyan-500/10 text-cyan-300 font-bold border border-cyan-400/30' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            ActiveAICore.py
          </button>
          <button
            onClick={() => setActiveTab('pydantic_schema')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'pydantic_schema' ? 'bg-purple-500/10 text-purple-300 font-bold border border-purple-400/30' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            AdvancedQuantumCore.py
          </button>
          <button
            onClick={() => setActiveTab('yaml_spec')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'yaml_spec' ? 'bg-amber-500/10 text-amber-300 font-bold border border-amber-400/30' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            gemini_quantum_core_brain.yaml
          </button>
        </div>

        {/* Code View */}
        <div className="flex-1 p-4 overflow-y-auto bg-black/60 text-xs text-zinc-300 leading-relaxed font-mono">
          <pre className="whitespace-pre-wrap">{getCurrentCode()}</pre>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 bg-black/40 flex items-center justify-between">
          <span className="text-[11px] text-zinc-500">
            Uses Google GenAI SDK (@google/genai)
          </span>
          <button
            onClick={handleCopy}
            className="px-4 py-2 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-black font-bold text-xs transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(34,211,238,0.3)]"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'COPIED TO CLIPBOARD' : 'COPY CODE'}
          </button>
        </div>
      </div>
    </div>
  );
};
