import React, { useState } from 'react';
import { Send, Terminal, Settings, Globe, Wrench, Sparkles, Copy, Check, Square, ExternalLink, Play, Download } from 'lucide-react';
import { CoreConfig, GroundingSource } from '../types';
import { soundEngine } from '../utils/sound';

interface CommandCenterProps {
  prompt: string;
  setPrompt: (p: string) => void;
  onExecutePrompt: () => void;
  isStreaming: boolean;
  onStopStreaming: () => void;
  streamedText: string;
  groundingSources: GroundingSource[];
  activeToolCalls: { name: string; args: any; result?: any }[];
  config: CoreConfig;
  setConfig: React.Dispatch<React.SetStateAction<CoreConfig>>;
  onOpenInstallerModal?: () => void;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  prompt,
  setPrompt,
  onExecutePrompt,
  isStreaming,
  onStopStreaming,
  streamedText,
  groundingSources,
  activeToolCalls,
  config,
  setConfig,
  onOpenInstallerModal,
}) => {
  const [showConfig, setShowConfig] = useState(false);
  const [copied, setCopied] = useState(false);

  const presets = [
    {
      label: '🌐 Domain Override: google.com',
      text: 'override google.com',
    },
    {
      label: '⚡ Agent Orchestration',
      text: 'Analyze the key parameters for low-latency active agent orchestration and continuous token dispatching.',
    },
    {
      label: '🔍 Diagnostics: quantum_array_01',
      text: "Check status for component 'quantum_array_01' and provide an architectural summary for active agent loop.",
    },
    {
      label: '📊 Pipeline Deployment Plan',
      text: 'Generate structured execution cognitive telemetry for: "Deploy automated multi-node streaming pipeline".',
    },
    {
      label: '🌐 Search Grounding: Quantum AI',
      text: 'What are the latest 2026 breakthroughs in quantum AI neural processing and low-latency agent architectures?',
    },
  ];

  const handleCopy = () => {
    if (!streamedText) return;
    navigator.clipboard.writeText(streamedText);
    setCopied(true);
    soundEngine.playBeep(900, 0.05);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      if (!isStreaming && prompt.trim()) {
        onExecutePrompt();
      }
    }
  };

  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 backdrop-blur-sm shadow-2xl flex flex-col h-full">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <h2 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest font-mono">
            Active Reasoning Command Center
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {onOpenInstallerModal && (
            <button
              onClick={() => {
                soundEngine.playBeep(650, 0.04);
                onOpenInstallerModal();
              }}
              className="px-2.5 py-1.5 rounded-lg border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 text-[10px] font-mono flex items-center gap-1.5 transition-all shadow-[0_0_10px_rgba(34,211,238,0.15)]"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>INSTALL & ZIP</span>
            </button>
          )}

          <button
            onClick={() => {
              setShowConfig(!showConfig);
              soundEngine.playBeep(600, 0.04);
            }}
            className={`px-3 py-1.5 rounded-lg border text-[10px] font-mono transition-all flex items-center gap-1.5 ${
              showConfig
                ? 'bg-cyan-500/10 border-cyan-400/40 text-cyan-300'
                : 'bg-black/40 border-white/10 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            CORE PARAMETERS
          </button>
        </div>
      </div>

      {/* Config Drawer */}
      {showConfig && (
        <div className="mb-4 p-4 rounded-xl bg-black/40 border border-white/10 text-xs font-mono space-y-3 animate-fade-in">
          <div>
            <label className="block text-zinc-400 font-semibold mb-1">SYSTEM INSTRUCTION</label>
            <input
              type="text"
              value={config.system_instruction}
              onChange={(e) => setConfig({ ...config, system_instruction: e.target.value })}
              className="w-full bg-black/60 border border-white/10 rounded-lg px-3 py-1.5 text-zinc-200 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-zinc-400 font-semibold mb-1">
                TEMPERATURE: <span className="text-cyan-300">{config.temperature}</span>
              </label>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={config.temperature}
                onChange={(e) => setConfig({ ...config, temperature: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-zinc-400 font-semibold mb-1 uppercase tracking-wider text-[10px]">
                DOMAIN OVERRIDE
              </label>
              <input
                type="text"
                placeholder="google.com"
                value={config.overrideDomain || 'google.com'}
                onChange={(e) => setConfig({ ...config, overrideDomain: e.target.value })}
                className="w-full bg-black/60 border border-white/10 rounded-lg px-2.5 py-1.5 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="flex items-center justify-between bg-black/60 border border-white/10 rounded-lg p-2.5">
              <span className="text-zinc-300 flex items-center gap-1.5 font-semibold">
                <Globe className="w-3.5 h-3.5 text-cyan-400" /> SEARCH GROUNDING
              </span>
              <input
                type="checkbox"
                checked={config.enableSearchGrounding}
                onChange={(e) => setConfig({ ...config, enableSearchGrounding: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between bg-black/60 border border-white/10 rounded-lg p-2.5">
              <span className="text-zinc-300 flex items-center gap-1.5 font-semibold">
                <Wrench className="w-3.5 h-3.5 text-amber-400" /> DIAGNOSTIC TOOLS
              </span>
              <input
                type="checkbox"
                checked={config.enableDiagnosticsTools}
                onChange={(e) => setConfig({ ...config, enableDiagnosticsTools: e.target.checked })}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Preset Pills */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        {presets.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => {
              setPrompt(preset.text);
              soundEngine.playBeep(800, 0.03);
            }}
            className="px-2.5 py-1 rounded-lg bg-black/40 hover:bg-white/[0.06] border border-white/10 hover:border-cyan-400/40 text-zinc-300 hover:text-cyan-300 text-xs font-mono transition-all flex items-center gap-1"
          >
            <span>{preset.label}</span>
          </button>
        ))}
      </div>

      {/* Prompt Input Area */}
      <div className="relative mb-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter prompt or command for Gemini Quantum Core... (Ctrl+Enter to execute)"
          rows={3}
          className="w-full bg-black/60 border border-white/10 focus:border-cyan-400 rounded-xl p-3.5 text-zinc-100 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all resize-none shadow-inner"
        />

        <div className="absolute bottom-3 right-3 flex items-center gap-2">
          {isStreaming ? (
            <button
              onClick={onStopStreaming}
              className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-mono font-bold transition-all flex items-center gap-1.5"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              STOP
            </button>
          ) : (
            <button
              onClick={() => {
                if (prompt.trim()) {
                  soundEngine.playBeep(850, 0.05);
                  onExecutePrompt();
                }
              }}
              disabled={!prompt.trim()}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-black font-bold text-xs font-mono transition-all shadow-[0_0_15px_rgba(34,211,238,0.4)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              EXECUTE
            </button>
          )}
        </div>
      </div>

      {/* Tool Dispatch Badges & Grounding Sources */}
      {(activeToolCalls.length > 0 || groundingSources.length > 0) && (
        <div className="mb-3 space-y-2">
          {activeToolCalls.length > 0 && (
            <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-300 flex flex-wrap items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-400" />
              <span>DISPATCHED TOOL:</span>
              {activeToolCalls.map((tc, idx) => (
                <span key={idx} className="bg-black/60 px-2 py-0.5 rounded font-bold border border-amber-500/40">
                  {tc.name}({JSON.stringify(tc.args)})
                </span>
              ))}
            </div>
          )}

          {groundingSources.length > 0 && (
            <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-400/30 text-xs font-mono text-cyan-300">
              <div className="flex items-center gap-1.5 font-bold mb-1">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span>GOOGLE SEARCH GROUNDING SOURCES ({groundingSources.length}):</span>
              </div>
              <div className="flex flex-wrap gap-2 mt-1">
                {groundingSources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-black/40 hover:bg-black/60 border border-cyan-400/30 px-2.5 py-1 rounded text-[11px] text-cyan-200 hover:text-cyan-100 transition-all flex items-center gap-1"
                  >
                    <span className="truncate max-w-[200px]">{source.title || source.uri}</span>
                    <ExternalLink className="w-3 h-3 text-cyan-400" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Output Stream Terminal */}
      <div className="flex-1 min-h-[220px] max-h-[360px] bg-black/50 border border-white/10 rounded-xl p-4 overflow-y-auto font-mono text-xs text-zinc-200 relative group">
        <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-3 text-zinc-500">
          <span className="flex items-center gap-1.5 text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> LIVE REASONING OUTPUT STREAM
          </span>
          <button
            onClick={handleCopy}
            className="p-1 hover:bg-white/[0.06] rounded text-zinc-400 hover:text-zinc-200 transition-all flex items-center gap-1 text-[11px]"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'COPIED' : 'COPY'}
          </button>
        </div>

        {streamedText ? (
          <div className="whitespace-pre-wrap leading-relaxed text-zinc-100 font-sans text-xs sm:text-sm">
            {streamedText}
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-center py-8">
            <Terminal className="w-8 h-8 mb-2 opacity-40 text-cyan-400" />
            <p>Ready to receive active AI Core reasoning prompt.</p>
            <p className="text-[11px] text-zinc-600 mt-1">Select a preset or enter a custom prompt above.</p>
          </div>
        )}
      </div>
    </div>
  );
};
