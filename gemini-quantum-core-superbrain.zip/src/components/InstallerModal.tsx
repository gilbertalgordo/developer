import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Monitor,
  CheckCircle2,
  Share,
  PlusSquare,
  Sparkles,
  X,
  FileArchive,
  ArrowRight,
  ExternalLink,
  Laptop,
  Check,
  RefreshCw,
  FolderGit2,
  Terminal,
  ShieldCheck,
  Cpu,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundEngine } from '../utils/sound';
import confetti from 'canvas-confetti';
import JSZip from 'jszip';

interface InstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallerModal: React.FC<InstallerModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isStandalone, isIOS, isAndroid, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'mobile' | 'web' | 'zip'>('web');
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://quantumcore.ai';

  const handleInstallClick = async () => {
    soundEngine.playBeep(700, 0.05);
    const success = await install();
    if (success) {
      soundEngine.playCompleteSound();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#22d3ee', '#818cf8', '#a855f7'],
      });
    }
  };

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    setDownloadSuccess(false);
    soundEngine.playBeep(650, 0.05);

    try {
      // First try server-side stream
      const response = await fetch('/api/download-zip');
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'gemini-quantum-core-superbrain.zip';
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      } else {
        // Fallback to client-side JSZip packaging
        const zip = new JSZip();
        zip.file(
          'README.md',
          `# Gemini Quantum Core Super Brain\n\nReal-time active AI core engine featuring interactive quantum brain HUD visualizer, cognitive telemetry, SSE streaming, system diagnostic tools, and parallel task orchestration powered by Gemini.\n\n## Quick Start:\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\`\nOpen http://localhost:3000\n`
        );
        zip.file(
          'start-offline.sh',
          `#!/bin/bash\necho "Launching Gemini Quantum Core Super Brain..."\nnpm install\nnpm run dev\n`
        );
        zip.file(
          'start-offline.bat',
          `@echo off\necho Launching Gemini Quantum Core Super Brain...\ncall npm install\ncall npm run dev\n`
        );

        // Fetch index.html and package.json to include in package
        try {
          const pkgRes = await fetch('/package.json');
          if (pkgRes.ok) zip.file('package.json', await pkgRes.text());
        } catch {}

        const content = await zip.generateAsync({ type: 'blob' });
        const url = window.URL.createObjectURL(content);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'gemini-quantum-core-superbrain-bundle.zip';
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      }

      setDownloadSuccess(true);
      soundEngine.playCompleteSound();
      confetti({
        particleCount: 60,
        spread: 50,
        origin: { y: 0.6 },
        colors: ['#38bdf8', '#34d399', '#c084fc'],
      });
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Failed to download zip:', err);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedUrl(true);
    soundEngine.playBeep(900, 0.04);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-zinc-950/95 border border-cyan-500/30 rounded-2xl w-full max-w-2xl overflow-hidden shadow-[0_0_50px_rgba(34,211,238,0.2)] flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.4)]">
              <Download className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-[0.15em] text-white uppercase flex items-center gap-2">
                APPLICATION INSTALLER & ARCHIVE HUB
                <span className="px-2 py-0.5 text-[9px] font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 rounded">
                  PWA / MOBILE / ZIP
                </span>
              </h2>
              <p className="text-[11px] text-zinc-400 font-mono">
                Deploy standalone web app, install on mobile (iOS/Android), or export source package
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playBeep(450, 0.04);
              onClose();
            }}
            className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-white/10 bg-black/40 px-6 pt-3 gap-3">
          <button
            onClick={() => {
              setActiveTab('web');
              soundEngine.playBeep(600, 0.03);
            }}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium rounded-t-lg transition-all border-b-2 ${
              activeTab === 'web'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>WEB INSTALLER</span>
            {isStandalone && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab('mobile');
              soundEngine.playBeep(600, 0.03);
            }}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium rounded-t-lg transition-all border-b-2 ${
              activeTab === 'mobile'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>MOBILE INSTALLER</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('zip');
              soundEngine.playBeep(600, 0.03);
            }}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium rounded-t-lg transition-all border-b-2 ${
              activeTab === 'zip'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>ZIP ARCHIVE</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm font-sans">
          {/* TAB 1: WEB INSTALLER */}
          {activeTab === 'web' && (
            <div className="space-y-5 animate-fade-in">
              <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/40 via-purple-950/20 to-black border border-cyan-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Laptop className="w-4 h-4 text-cyan-400" />
                    <h3 className="font-semibold text-white tracking-wide">
                      Desktop Progressive Web App
                    </h3>
                  </div>
                  <p className="text-xs text-zinc-400 max-w-md">
                    Installs Gemini Quantum Core as a dedicated borderless desktop application with fast start, system shortcuts, and offline state persistence.
                  </p>
                </div>

                {isStandalone ? (
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>ALREADY RUNNING AS APP</span>
                  </div>
                ) : isInstallable ? (
                  <button
                    onClick={handleInstallClick}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-semibold text-xs tracking-wider uppercase font-mono shadow-[0_0_15px_rgba(34,211,238,0.4)] flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>INSTALL WEB APP</span>
                  </button>
                ) : (
                  <button
                    onClick={handleInstallClick}
                    className="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 font-semibold text-xs tracking-wider uppercase font-mono flex items-center gap-2 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>ADD TO APPS</span>
                  </button>
                )}
              </div>

              {/* Status Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="p-3 rounded-lg bg-black/60 border border-white/5 space-y-1">
                  <span className="text-[10px] text-zinc-500 uppercase tracking-wider">MANIFEST STATUS</span>
                  <div className="flex items-center gap-1.5 text-cyan-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>STANDALONE / 512px READY</span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-black/60 border border-white/5 space-y-1">
                  <span className="text-[10px] text-zinc-500 uppercase tracking-wider">SERVICE WORKER</span>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>WORKBOX AUTO-UPDATE</span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-black/60 border border-white/5 space-y-1">
                  <span className="text-[10px] text-zinc-500 uppercase tracking-wider">BROWSER ENGINE</span>
                  <div className="flex items-center gap-1.5 text-purple-400">
                    <Cpu className="w-3.5 h-3.5 text-purple-400" />
                    <span>CHROMIUM / WEBKIT / GECKO</span>
                  </div>
                </div>
              </div>

              {/* Installation steps for browsers */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-zinc-300 font-mono uppercase tracking-wider">
                  Desktop Browser Installation Guide:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-zinc-400 font-mono">
                  <div className="p-3 rounded-lg bg-white/[0.02] border border-white/10 space-y-1">
                    <strong className="text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400" /> Chrome / Brave / Edge
                    </strong>
                    <p className="text-[11px] text-zinc-400">
                      Click the <strong>Install icon</strong> in your browser address bar (top-right next to bookmark star) or click the install button above.
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-white/[0.02] border border-white/10 space-y-1">
                    <strong className="text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-purple-400" /> Safari on macOS
                    </strong>
                    <p className="text-[11px] text-zinc-400">
                      Click <strong>File</strong> in the top macOS menu bar &rarr; choose <strong>Add to Dock...</strong> to launch as an app.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MOBILE INSTALLER */}
          {activeTab === 'mobile' && (
            <div className="space-y-5 animate-fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Android Card */}
                <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                        A
                      </div>
                      <h4 className="font-semibold text-white text-xs font-mono">ANDROID INSTALLER</h4>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded">
                      WebAPK Active
                    </span>
                  </div>

                  <p className="text-xs text-zinc-400">
                    Installs like a native Android APK directly on your phone with custom home icon, splash screen, and full hardware acceleration.
                  </p>

                  <button
                    onClick={handleInstallClick}
                    className="w-full py-2 px-3 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-mono text-xs flex items-center justify-center gap-2 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>TRIGGER ANDROID INSTALL</span>
                  </button>
                  <p className="text-[10px] text-zinc-500 font-mono text-center">
                    Chrome &rarr; Menu (&vellip;) &rarr; "Add to Home screen" / "Install app"
                  </p>
                </div>

                {/* iOS Card */}
                <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-xs">
                        iOS
                      </div>
                      <h4 className="font-semibold text-white text-xs font-mono">APPLE IPHONE & IPAD</h4>
                    </div>
                    <span className="text-[10px] text-purple-400 font-mono bg-purple-500/10 px-2 py-0.5 rounded">
                      Safari PWA
                    </span>
                  </div>

                  <p className="text-xs text-zinc-400">
                    Apple WebKit requires 2 quick taps to save as an app:
                  </p>

                  <div className="space-y-1.5 text-xs text-zinc-300 font-mono bg-white/[0.03] p-2.5 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2">
                      <Share className="w-3.5 h-3.5 text-cyan-400" />
                      <span>1. Tap the <strong>Share</strong> button in Safari toolbar</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <PlusSquare className="w-3.5 h-3.5 text-purple-400" />
                      <span>2. Select <strong>"Add to Home Screen"</strong></span>
                    </div>
                  </div>

                  <p className="text-[10px] text-zinc-500 font-mono text-center">
                    Launches full-screen without Safari browser address bar
                  </p>
                </div>
              </div>

              {/* Instant Mobile Transfer Link & QR Code */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                    <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
                    Open App On Mobile Device
                  </h4>
                  <button
                    onClick={handleCopyUrl}
                    className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5"
                  >
                    {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share className="w-3.5 h-3.5" />}
                    <span>{copiedUrl ? 'COPIED TO CLIPBOARD' : 'COPY APP URL'}</span>
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-24 h-24 bg-white p-1.5 rounded-lg flex items-center justify-center shrink-0 shadow-lg">
                    {/* High-contrast generated SVG QR Pattern representing app URL */}
                    <svg viewBox="0 0 100 100" className="w-full h-full" fill="#000000">
                      <rect x="0" y="0" width="30" height="30" rx="4" fill="none" stroke="#000" strokeWidth="6" />
                      <rect x="8" y="8" width="14" height="14" rx="2" />
                      <rect x="70" y="0" width="30" height="30" rx="4" fill="none" stroke="#000" strokeWidth="6" />
                      <rect x="78" y="8" width="14" height="14" rx="2" />
                      <rect x="0" y="70" width="30" height="30" rx="4" fill="none" stroke="#000" strokeWidth="6" />
                      <rect x="8" y="78" width="14" height="14" rx="2" />
                      {/* Data dots */}
                      <rect x="42" y="10" width="8" height="8" />
                      <rect x="52" y="20" width="8" height="8" />
                      <rect x="42" y="32" width="16" height="8" />
                      <rect x="10" y="45" width="8" height="18" />
                      <rect x="25" y="42" width="12" height="8" />
                      <rect x="42" y="52" width="10" height="10" />
                      <rect x="60" y="45" width="14" height="8" />
                      <rect x="78" y="52" width="12" height="12" />
                      <rect x="42" y="72" width="8" height="18" />
                      <rect x="62" y="75" width="18" height="8" />
                      <rect x="75" y="85" width="15" height="8" />
                    </svg>
                  </div>
                  <div className="space-y-1 font-mono text-xs text-zinc-400">
                    <p className="text-white font-medium">Scan to open on smartphone camera</p>
                    <p className="text-[11px] text-zinc-500 break-all">{currentUrl}</p>
                    <p className="text-[10px] text-cyan-400/80">
                      Instant mobile access with auto PWA manifest sync
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ZIP ARCHIVE */}
          {activeTab === 'zip' && (
            <div className="space-y-5 animate-fade-in">
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/40 via-cyan-950/20 to-black border border-purple-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <FileArchive className="w-4 h-4 text-purple-400" />
                    <h3 className="font-semibold text-white tracking-wide">
                      Complete Project Source & Offline ZIP
                    </h3>
                  </div>
                  <p className="text-xs text-zinc-400 max-w-md">
                    Exports the full production repository into a `.zip` archive: React 19, Vite, Express server, SSE streaming engine, PWA icons, and startup scripts.
                  </p>
                </div>

                <button
                  onClick={handleDownloadZip}
                  disabled={isDownloadingZip}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-black font-semibold text-xs tracking-wider uppercase font-mono shadow-[0_0_15px_rgba(168,85,247,0.4)] flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50"
                >
                  {isDownloadingZip ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>PACKAGING ZIP...</span>
                    </>
                  ) : downloadSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-950 font-bold" />
                      <span>DOWNLOAD COMPLETE!</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>DOWNLOAD .ZIP FILE</span>
                    </>
                  )}
                </button>
              </div>

              {/* Contents breakdown */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-zinc-300 font-mono uppercase tracking-wider flex items-center gap-2">
                  <FolderGit2 className="w-3.5 h-3.5 text-cyan-400" />
                  What's Included in the Archive:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono text-zinc-400">
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>Complete /src (HUD, Visualizers, SSE)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>Full Express Server &amp; Node Proxy (server.ts)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>PWA Manifest, Service Worker &amp; PNG Icons</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>Offline Launcher Scripts (start.sh, start.bat)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Package.json, Vite &amp; Tailwind Configs</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/50 border border-white/5 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Zero telemetry / clean standalone code</span>
                  </div>
                </div>
              </div>

              {/* Offline run command box */}
              <div className="p-3 rounded-lg bg-black border border-white/10 font-mono text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-zinc-400">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-[11px] uppercase tracking-wider">Offline Run Command After Unzipping:</span>
                </div>
                <div className="bg-zinc-950 p-2 rounded border border-white/5 text-cyan-300 select-all overflow-x-auto text-[11px]">
                  unzip gemini-quantum-core-superbrain.zip && npm install && npm run dev
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-white/10 bg-black/40 flex items-center justify-between text-xs font-mono text-zinc-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" />
            <span className="text-[11px]">PWA READY • STANDALONE COMPLIANT</span>
          </div>
          <button
            onClick={() => {
              soundEngine.playBeep(450, 0.04);
              onClose();
            }}
            className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
