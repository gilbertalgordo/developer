import React, { useState } from 'react';
import { CognitiveTelemetry } from '../types';
import { Network, CheckCircle2, Circle, ShieldCheck, Zap, Layers, RefreshCw } from 'lucide-react';
import { soundEngine } from '../utils/sound';

interface StructuredAnalysisPanelProps {
  telemetry: CognitiveTelemetry | null;
  onRefreshTelemetry: () => void;
  isLoading: boolean;
}

export const StructuredAnalysisPanel: React.FC<StructuredAnalysisPanelProps> = ({
  telemetry,
  onRefreshTelemetry,
  isLoading,
}) => {
  const [completedTasks, setCompletedTasks] = useState<Record<number, boolean>>({});

  const toggleTask = (index: number) => {
    soundEngine.playBeep(900, 0.03);
    setCompletedTasks((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const confidencePct = telemetry ? Math.round(telemetry.confidence_score * 100) : 98;

  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 backdrop-blur-sm shadow-2xl flex flex-col h-full font-mono text-xs">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-cyan-400" />
          <h3 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
            Structured Cognitive Telemetry
          </h3>
        </div>

        <button
          onClick={() => {
            soundEngine.playScanSound();
            onRefreshTelemetry();
          }}
          disabled={isLoading}
          className="p-1.5 rounded-lg bg-black/40 hover:bg-white/[0.06] border border-white/10 text-zinc-300 hover:text-cyan-300 transition-all flex items-center gap-1.5 text-[10px]"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isLoading ? 'animate-spin' : ''}`} />
          RE-ANALYZE
        </button>
      </div>

      {telemetry ? (
        <div className="space-y-4">
          {/* Top Metric Cards */}
          <div className="grid grid-cols-2 gap-3">
            {/* Step ID */}
            <div className="bg-black/40 border border-white/10 rounded-xl p-3">
              <span className="text-zinc-500 text-[10px] uppercase font-semibold">STEP IDENTIFIER</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-cyan-300 font-bold text-sm">{telemetry.step_id}</span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              </div>
            </div>

            {/* Confidence Metric */}
            <div className="bg-black/40 border border-white/10 rounded-xl p-3">
              <span className="text-zinc-500 text-[10px] uppercase font-semibold">CONFIDENCE INDEX</span>
              <div className="flex items-center justify-between mt-1">
                <span
                  className={`font-bold text-sm ${
                    confidencePct >= 90 ? 'text-emerald-400' : confidencePct >= 75 ? 'text-amber-400' : 'text-rose-400'
                  }`}
                >
                  {confidencePct}%
                </span>
                <span className="text-zinc-500 text-[10px]">({telemetry.confidence_score.toFixed(2)})</span>
              </div>
              <div className="w-full bg-black/60 h-1.5 rounded-full overflow-hidden mt-2 border border-white/5">
                <div
                  className={`h-full transition-all duration-500 ${
                    confidencePct >= 90 ? 'bg-emerald-400' : confidencePct >= 75 ? 'bg-amber-400' : 'bg-rose-400'
                  }`}
                  style={{ width: `${confidencePct}%` }}
                />
              </div>
            </div>
          </div>

          {/* Primary Strategy Vector */}
          <div className="bg-black/40 border border-white/10 rounded-xl p-3">
            <span className="text-zinc-500 text-[10px] uppercase font-semibold block mb-1">
              PRIMARY REASONING VECTOR
            </span>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 font-bold text-xs shadow-inner">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>{telemetry.primary_vector}</span>
            </div>
          </div>

          {/* Subtasks Checklist */}
          <div className="bg-black/40 border border-white/10 rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-zinc-400 text-[10px] uppercase font-semibold flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-cyan-400" /> DECOMPOSED SUBTASKS ({telemetry.subtasks.length})
              </span>
              <span className="text-[10px] text-zinc-500">
                {Object.values(completedTasks).filter(Boolean).length} / {telemetry.subtasks.length} DONE
              </span>
            </div>

            <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
              {telemetry.subtasks.map((task, idx) => {
                const isDone = !!completedTasks[idx];
                return (
                  <div
                    key={idx}
                    onClick={() => toggleTask(idx)}
                    className={`p-2 rounded-lg border text-xs cursor-pointer transition-all flex items-start gap-2 ${
                      isDone
                        ? 'bg-emerald-500/10 border-emerald-400/30 text-emerald-300 line-through opacity-75'
                        : 'bg-black/60 hover:bg-white/[0.04] border-white/10 text-zinc-200'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Circle className="w-4 h-4 text-zinc-600 shrink-0 mt-0.5" />
                    )}
                    <span className="leading-tight">{task}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-zinc-600 text-center py-8">
          <ShieldCheck className="w-8 h-8 mb-2 opacity-30 text-cyan-400" />
          <p>No active cognitive telemetry payload.</p>
          <p className="text-[10px] text-zinc-700 mt-1">Execute a prompt or click Re-Analyze above.</p>
        </div>
      )}
    </div>
  );
};
