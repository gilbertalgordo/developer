import React, { useState } from 'react';
import { X, Download, Copy, Check, Sparkles, Image as ImageIcon } from 'lucide-react';
import { soundEngine } from '../utils/sound';
import confetti from 'canvas-confetti';

interface AssetExporterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AssetExporterModal: React.FC<AssetExporterModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const rawSVGString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512" style="background: #020712;">
  <defs>
    <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#00ffff" stop-opacity="0.9"/>
      <stop offset="50%" stop-color="#7000ff" stop-opacity="0.5"/>
      <stop offset="100%" stop-color="#020712" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="cyanPurple" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#00f3ff"/>
      <stop offset="100%" stop-color="#b000ff"/>
    </linearGradient>
    <filter id="neonFilter" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="6" result="blur" />
      <feMerge>
        <feMergeNode in="blur" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  </defs>
  <g stroke="#00f3ff" stroke-width="1" opacity="0.15" fill="none">
    <circle cx="256" cy="256" r="220" stroke-dasharray="8 8"/>
    <circle cx="256" cy="256" r="180"/>
    <circle cx="256" cy="256" r="140" stroke-dasharray="4 4"/>
    <line x1="36" y1="256" x2="476" y2="256"/>
    <line x1="256" y1="36" x2="256" y2="476"/>
  </g>
  <circle cx="256" cy="256" r="120" fill="url(#coreGlow)" />
  <circle cx="256" cy="256" r="150" fill="none" stroke="url(#cyanPurple)" stroke-width="3" stroke-dasharray="180 40" filter="url(#neonFilter)"/>
  <g fill="none" stroke="#00f3ff" stroke-width="2.5" stroke-linecap="round" filter="url(#neonFilter)">
    <path d="M 256 160 C 210 160 170 190 170 240 C 170 280 200 310 230 330 C 245 340 256 352 256 352" />
    <path d="M 256 160 C 302 160 342 190 342 240 C 342 280 312 310 282 330 C 267 340 256 352 256 352" />
    <path d="M 210 200 C 240 220 272 220 302 200" stroke-dasharray="3 3"/>
    <path d="M 190 256 C 230 270 282 270 322 256"/>
    <path d="M 220 300 C 240 310 272 310 292 300"/>
  </g>
  <g fill="#ffffff" filter="url(#neonFilter)">
    <circle cx="256" cy="160" r="5"/>
    <circle cx="170" cy="240" r="4"/>
    <circle cx="342" cy="240" r="4"/>
    <circle cx="230" cy="330" r="4"/>
    <circle cx="282" cy="330" r="4"/>
    <circle cx="256" cy="352" r="5"/>
  </g>
  <circle cx="256" cy="256" r="18" fill="#ffffff" filter="url(#neonFilter)"/>
</svg>`;

  const handleDownloadSVG = () => {
    soundEngine.playCompleteSound();
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    const blob = new Blob([rawSVGString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'quantum_ai_core_brain.svg';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadPNG = () => {
    soundEngine.playCompleteSound();
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
    const img = new Image();
    const svgBlob = new Blob([rawSVGString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, 512, 512);
        const pngUrl = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = pngUrl;
        a.download = 'quantum_ai_core_brain.png';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const handleCopySVG = () => {
    navigator.clipboard.writeText(rawSVGString);
    setCopied(true);
    soundEngine.playBeep(900, 0.05);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-mono">
      <div className="bg-black/90 border border-white/10 rounded-2xl w-full max-w-xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-black/40">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-zinc-200 text-xs tracking-wider uppercase">
              Export Quantum Core Vector Assets
            </h3>
          </div>
          <button
            onClick={() => {
              soundEngine.playBeep(500, 0.04);
              onClose();
            }}
            className="p-1 hover:bg-white/[0.06] rounded text-zinc-400 hover:text-zinc-200 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preview */}
        <div className="p-6 flex flex-col items-center justify-center bg-black/60 border-b border-white/10">
          <div className="w-48 h-48 rounded-2xl bg-black/80 border border-white/10 p-2 shadow-2xl flex items-center justify-center relative group">
            <div dangerouslySetInnerHTML={{ __html: rawSVGString }} className="w-full h-full" />
          </div>
          <p className="text-xs text-zinc-400 mt-3 font-medium">
            512 x 512 Quantum Core Neural Brain Vector Icon
          </p>
        </div>

        {/* Export Buttons */}
        <div className="p-4 bg-black/40 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handleCopySVG}
            className="px-3.5 py-2 rounded-lg bg-black/60 hover:bg-white/[0.06] border border-white/10 text-zinc-200 text-xs font-bold transition-all flex items-center gap-1.5"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
            {copied ? 'COPIED SVG' : 'COPY SVG CODE'}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadSVG}
              className="px-3.5 py-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-400/30 text-purple-300 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              SVG FILE
            </button>

            <button
              onClick={handleDownloadPNG}
              className="px-4 py-2 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-black font-bold text-xs transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(34,211,238,0.3)]"
            >
              <ImageIcon className="w-4 h-4 fill-current" />
              PNG ICON
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
