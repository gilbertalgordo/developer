import React from 'react';
import { SystemNodeStatus } from '../types';
import { Cpu, Activity, Thermometer, Zap, ShieldCheck, RefreshCw } from 'lucide-react';
import { soundEngine } from '../utils/sound';

interface DiagnosticsMatrixProps {
  nodes: SystemNodeStatus[];
  onSelectNode: (node: SystemNodeStatus) => void;
  onRefreshNode: (component: string) => void;
  selectedNode: SystemNodeStatus | null;
}

export const DiagnosticsMatrix: React.FC<DiagnosticsMatrixProps> = ({
  nodes,
  onSelectNode,
  onRefreshNode,
  selectedNode,
}) => {
  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 backdrop-blur-sm shadow-2xl font-mono text-xs">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <h3 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
            Quantum Active Core Hardware Matrix
          </h3>
        </div>
        <span className="text-[10px] text-zinc-500">
          5 ACTIVE TENSOR NODES
        </span>
      </div>

      {/* Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {nodes.map((node) => {
          const isSelected = selectedNode?.component === node.component;
          return (
            <div
              key={node.component}
              onClick={() => {
                soundEngine.playBeep(750, 0.04);
                onSelectNode(node);
              }}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer relative overflow-hidden group ${
                isSelected
                  ? 'bg-cyan-500/10 border-cyan-400/80 shadow-[0_0_15px_rgba(34,211,238,0.25)]'
                  : 'bg-black/40 hover:bg-white/[0.04] border-white/10'
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-zinc-200 text-xs truncate max-w-[160px]">
                  {node.name}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    node.status === 'NOMINAL'
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-400/30'
                      : node.status === 'OPTIMIZING'
                      ? 'bg-amber-500/10 text-amber-300 border-amber-400/30'
                      : 'bg-rose-500/10 text-rose-300 border-rose-400/30'
                  }`}
                >
                  {node.status}
                </span>
              </div>

              <div className="text-[11px] text-zinc-400 mb-3 line-clamp-2">
                {node.description}
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-2 text-[10px] bg-black/60 p-2 rounded-lg border border-white/5">
                <div>
                  <span className="text-zinc-500 block">LATENCY:</span>
                  <strong className="text-emerald-400 text-xs">{node.latency_ms} ms</strong>
                </div>
                <div>
                  <span className="text-zinc-500 block">COHERENCE:</span>
                  <strong className="text-cyan-300 text-xs">{node.quantum_coherence}</strong>
                </div>
                <div>
                  <span className="text-zinc-500 block">LOAD:</span>
                  <strong className="text-amber-300 text-xs">{node.load_pct}%</strong>
                </div>
                <div>
                  <span className="text-zinc-500 block">TEMP:</span>
                  <strong className="text-zinc-300 text-xs">{node.temperature_c}°C</strong>
                </div>
              </div>

              {/* Scan Action */}
              <div className="mt-3 flex items-center justify-between pt-2 border-t border-white/5">
                <span className="text-[10px] text-zinc-500 font-mono">{node.component}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    soundEngine.playScanSound();
                    onRefreshNode(node.component);
                  }}
                  className="px-2 py-1 rounded bg-black/60 hover:bg-cyan-500/10 border border-white/10 hover:border-cyan-400/40 text-zinc-300 hover:text-cyan-300 transition-all text-[10px] flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3 text-cyan-400" /> SCAN NODE
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
