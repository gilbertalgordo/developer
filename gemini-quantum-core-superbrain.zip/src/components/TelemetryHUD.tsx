import React, { useState, useEffect, useRef } from 'react';
import { TelemetryLogEntry } from '../types';
import { Terminal, Filter, Trash2, ArrowDownCircle, ShieldCheck, AlertTriangle } from 'lucide-react';
import { soundEngine } from '../utils/sound';

interface TelemetryHUDProps {
  logs: TelemetryLogEntry[];
  onClearLogs: () => void;
}

export const TelemetryHUD: React.FC<TelemetryHUDProps> = ({ logs, onClearLogs }) => {
  const [filter, setFilter] = useState<string>('ALL');
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const filteredLogs = logs.filter((log) => {
    if (filter === 'ALL') return true;
    if (filter === 'CYCLES') return log.event_type === 'CYCLE_START' || log.event_type === 'CYCLE_COMPLETE';
    if (filter === 'DISPATCH') return log.event_type === 'FUNCTION_CALL_DISPATCH' || log.event_type === 'FUNCTION_RESULT';
    if (filter === 'ERRORS') return log.event_type === 'ENGINE_ERROR' || log.level === 'error';
    return true;
  });

  const getEventBadge = (type: string, level: string) => {
    switch (type) {
      case 'CYCLE_START':
        return 'text-cyan-300 bg-cyan-500/10 border-cyan-400/30';
      case 'CYCLE_COMPLETE':
        return 'text-emerald-300 bg-emerald-500/10 border-emerald-400/30';
      case 'FUNCTION_CALL_DISPATCH':
        return 'text-amber-300 bg-amber-500/10 border-amber-400/30';
      case 'FUNCTION_RESULT':
        return 'text-teal-300 bg-teal-500/10 border-teal-400/30';
      case 'ENGINE_ERROR':
        return 'text-rose-300 bg-rose-500/10 border-rose-400/30';
      case 'GROUNDING_SEARCH':
        return 'text-purple-300 bg-purple-500/10 border-purple-400/30';
      default:
        return 'text-zinc-300 bg-black/40 border-white/10';
    }
  };

  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/10 p-5 backdrop-blur-sm shadow-2xl flex flex-col h-full font-mono">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <h3 className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest">
            Quantum Core HUD Telemetry Logs
          </h3>
          <span className="px-2 py-0.5 rounded text-[10px] bg-black/40 border border-white/10 text-cyan-300">
            {logs.length} EVENTS
          </span>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-black/40 border border-white/10 rounded-lg p-1 text-[10px]">
            <Filter className="w-3 h-3 text-zinc-500 ml-1.5 mr-1" />
            {['ALL', 'CYCLES', 'DISPATCH', 'ERRORS'].map((f) => (
              <button
                key={f}
                onClick={() => {
                  setFilter(f);
                  soundEngine.playBeep(700, 0.03);
                }}
                className={`px-2 py-0.5 rounded transition-all ${
                  filter === f ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-400/30' : 'text-zinc-500 hover:text-zinc-200'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <button
            onClick={() => setAutoScroll(!autoScroll)}
            title="Toggle Auto Scroll"
            className={`p-1.5 rounded-lg border text-xs transition-all ${
              autoScroll ? 'bg-cyan-500/10 border-cyan-400/30 text-cyan-300' : 'bg-black/40 border-white/10 text-zinc-500'
            }`}
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              onClearLogs();
              soundEngine.playBeep(500, 0.04);
            }}
            title="Clear Log Terminal"
            className="p-1.5 rounded-lg bg-black/40 border border-white/10 text-zinc-400 hover:text-rose-400 transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Log Terminal Window */}
      <div
        ref={logContainerRef}
        className="flex-1 min-h-[180px] max-h-[300px] bg-black/50 border border-white/10 rounded-xl p-3 overflow-y-auto text-[11px] leading-relaxed space-y-1.5 select-text"
      >
        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-2 hover:bg-white/[0.04] p-1 rounded transition-colors group">
              <span className="text-zinc-600 shrink-0 font-mono text-[10px]">{log.timestamp}</span>
              <span className="text-zinc-700 shrink-0">│</span>
              <span className="text-cyan-400 font-semibold shrink-0">[HUD]</span>
              <span className={`px-1.5 py-0.2 rounded border text-[10px] font-bold shrink-0 ${getEventBadge(log.event_type, log.level)}`}>
                {log.event_type}
              </span>
              <span className="text-zinc-600 shrink-0">-&gt;</span>
              <span className="text-zinc-300 break-all">
                {JSON.stringify(log.payload)}
              </span>
            </div>
          ))
        ) : (
          <div className="h-full flex items-center justify-center text-zinc-600 text-xs text-center py-6">
            No telemetry logs matching filter "{filter}".
          </div>
        )}
      </div>
    </div>
  );
};
