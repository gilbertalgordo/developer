import React from 'react';
import { Cpu, Activity, Volume2, VolumeX, Code, Download, ShieldCheck, Zap, Sparkles } from 'lucide-react';
import { soundEngine } from '../utils/sound';

interface HeaderHUDProps {
  quantumCoherence: number;
  activeCycleId: string;
  isStreaming: boolean;
  onOpenCodeModal: () => void;
  onOpenExportModal: () => void;
  onOpenInstallerModal: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  quantumCoherence,
  activeCycleId,
  isStreaming,
  onOpenCodeModal,
  onOpenExportModal,
  onOpenInstallerModal,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="h-16 flex items-center justify-between px-4 sm:px-8 border-b border-white/5 relative z-40 backdrop-blur-md bg-black/20 sticky top-0">
      <div className="max-w-7xl mx-auto w-full flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.4)] relative">
            <div className="w-4 h-4 border-2 border-white/90 rounded-full animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold tracking-[0.2em] uppercase text-white">
                GEMINI QUANTUM CORE
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[9px] font-mono uppercase tracking-widest text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 rounded-sm">
                QC-BRAIN-v4.0.2
              </span>
            </div>
            <p className="text-[10px] text-cyan-400/70 font-mono tracking-tighter flex items-center gap-2">
              <span>MODEL: <strong className="text-cyan-300">gemini-3.6-flash</strong></span>
              <span className="text-zinc-600">•</span>
              <span className="text-emerald-400 flex items-center gap-1 font-mono">
                <ShieldCheck className="w-3 h-3 inline" /> STABLE RESONANCE
              </span>
            </p>
          </div>
        </div>

        {/* HUD Telemetry Gauges */}
        <div className="hidden md:flex items-center gap-6 bg-white/[0.03] border border-white/10 backdrop-blur-sm rounded-lg px-4 py-1.5 font-mono text-xs">
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span className="text-zinc-500 text-[10px] uppercase tracking-wider">SYNAPSE COHERENCE</span>
            <span className="font-mono text-cyan-400 text-xs font-bold drop-shadow-[0_0_8px_#22d3ee]">
              {quantumCoherence.toFixed(3)}%
            </span>
          </div>

          <div className="h-4 w-px bg-white/10" />

          <div className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-purple-400" />
            <span className="text-zinc-500 text-[10px] uppercase tracking-wider">CYCLE</span>
            <span className="font-mono text-purple-400 text-xs font-bold">{activeCycleId || 'IDLE'}</span>
          </div>

          <div className="h-4 w-px bg-white/10" />

          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isStreaming ? 'bg-amber-400 animate-ping shadow-[0_0_8px_#f59e0b]' : 'bg-emerald-400 shadow-[0_0_8px_#34d399]'}`} />
            <span className="text-zinc-300 uppercase tracking-widest text-[10px] font-mono">
              {isStreaming ? 'STREAMING ACTIVE' : 'QUANTUM STABLE'}
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Audio SFX Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Disable HUD SFX' : 'Enable HUD SFX'}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition-all flex items-center gap-1.5 ${
              soundEnabled
                ? 'bg-cyan-500/10 border-cyan-400/40 text-cyan-300 shadow-[0_0_10px_rgba(34,211,238,0.2)]'
                : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline tracking-wider text-[10px]">{soundEnabled ? 'SFX ON' : 'SFX OFF'}</span>
          </button>

          {/* Python Spec Modal */}
          <button
            onClick={onOpenCodeModal}
            className="px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/10 hover:border-purple-500/50 hover:bg-white/[0.06] text-zinc-300 hover:text-purple-300 text-xs font-mono transition-all flex items-center gap-1.5"
          >
            <Code className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline text-[10px] tracking-wider">PYTHON SPEC</span>
          </button>

          {/* Vector Asset Exporter */}
          <button
            onClick={onOpenExportModal}
            className="px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/10 hover:border-cyan-500/40 text-zinc-300 hover:text-cyan-300 text-xs font-mono transition-all flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline text-[10px] tracking-wider">EXPORT ICON</span>
          </button>

          {/* Mobile, Web Installer & ZIP Archive */}
          <button
            onClick={onOpenInstallerModal}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(34,211,238,0.25)] hover:scale-[1.02]"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
            <span className="font-semibold tracking-wider text-[10px]">INSTALL & ZIP</span>
          </button>
        </div>
      </div>
    </header>
  );
};
