import React, { useState, useEffect, useRef } from 'react';
import { HeaderHUD } from './components/HeaderHUD';
import { QuantumBrainVisualizer } from './components/QuantumBrainVisualizer';
import { CommandCenter } from './components/CommandCenter';
import { TelemetryHUD } from './components/TelemetryHUD';
import { StructuredAnalysisPanel } from './components/StructuredAnalysisPanel';
import { DiagnosticsMatrix } from './components/DiagnosticsMatrix';
import { PythonSpecModal } from './components/PythonSpecModal';
import { AssetExporterModal } from './components/AssetExporterModal';
import { InstallerModal } from './components/InstallerModal';
import { OfflineIndicator } from './components/OfflineIndicator';

import {
  CognitiveTelemetry,
  TelemetryLogEntry,
  SystemNodeStatus,
  CoreConfig,
  GroundingSource,
} from './types';
import { soundEngine } from './utils/sound';

export default function App() {
  const [quantumCoherence, setQuantumCoherence] = useState<number>(99.98);
  const [activeCycleId, setActiveCycleId] = useState<string>('CYC-0001');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [prompt, setPrompt] = useState<string>(
    'Analyze the key parameters for low-latency active agent orchestration.'
  );
  const [streamedText, setStreamedText] = useState<string>('');
  const [groundingSources, setGroundingSources] = useState<GroundingSource[]>([]);
  const [activeToolCalls, setActiveToolCalls] = useState<
    { name: string; args: any; result?: any }[]
  >([]);

  const [logs, setLogs] = useState<TelemetryLogEntry[]>([
    {
      id: 'log-1',
      timestamp: new Date().toLocaleTimeString(),
      event_type: 'CYCLE_START',
      payload: { cycle_id: 'CYC-0001', note: 'System boot sequence completed' },
      level: 'info',
    },
    {
      id: 'log-2',
      timestamp: new Date().toLocaleTimeString(),
      event_type: 'HUD TELEMETRY',
      payload: { mode: 'NOMINAL', quantum_coherence: '99.98%' },
      level: 'info',
    },
  ]);

  const [telemetry, setTelemetry] = useState<CognitiveTelemetry | null>({
    step_id: 'STEP-1042',
    confidence_score: 0.98,
    primary_vector: 'QUANTUM_PARALLEL_AGENT_ORCHESTRATION',
    subtasks: [
      'Initialize high-bandwidth SSE token stream',
      'Decompose non-blocking async subtasks',
      'Dispatch parallel hardware node diagnostics',
      'Verify quantum coherence & thermal limits',
    ],
    quantum_coherence: 99.98,
    timestamp: Date.now(),
  });

  const [nodes, setNodes] = useState<SystemNodeStatus[]>([
    {
      component: 'quantum_array_01',
      name: 'Quantum Array Primary Core',
      status: 'NOMINAL',
      latency_ms: 1.42,
      quantum_coherence: '99.98%',
      load_pct: 34,
      temperature_c: 18.2,
      description: 'Superconducting Qubit Matrix engaged in multi-tensor parallel operations.',
    },
    {
      component: 'neural_synapse_alpha',
      name: 'Neural Synapse Alpha Pipeline',
      status: 'NOMINAL',
      latency_ms: 0.98,
      quantum_coherence: '99.99%',
      load_pct: 42,
      temperature_c: 19.5,
      description: 'Ultra-low latency spiking neural bridge with streaming activation weights.',
    },
    {
      component: 'subspace_bus_9',
      name: 'Subspace Bus Route 9',
      status: 'OPTIMIZING',
      latency_ms: 2.10,
      quantum_coherence: '99.95%',
      load_pct: 28,
      temperature_c: 17.8,
      description: 'High-bandwidth inter-node tensor bus operating with dynamic error correction.',
    },
    {
      component: 'cognitive_vector_mesh',
      name: 'Cognitive Vector Embedding Mesh',
      status: 'NOMINAL',
      latency_ms: 1.15,
      quantum_coherence: '99.97%',
      load_pct: 55,
      temperature_c: 21.0,
      description: 'Hyper-dimensional semantic space routing search grounding vectors.',
    },
    {
      component: 'quantum_memory_cache',
      name: 'Zero-Decay Quantum Memory Cache',
      status: 'NOMINAL',
      latency_ms: 0.45,
      quantum_coherence: '100.00%',
      load_pct: 19,
      temperature_c: 16.5,
      description: 'Entangled NV-center diamond lattice memory storing active chat turn states.',
    },
  ]);

  const [selectedNode, setSelectedNode] = useState<SystemNodeStatus | null>(nodes[0]);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isInstallerModalOpen, setIsInstallerModalOpen] = useState<boolean>(false);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isTelemetryLoading, setIsTelemetryLoading] = useState<boolean>(false);

  const [config, setConfig] = useState<CoreConfig>({
    model: 'gemini-3.6-flash',
    system_instruction:
      'You are the Gemini Quantum Core Super Brain Active AI Engine. Provide analytical, structured real-time reasoning with active tool execution.',
    temperature: 0.2,
    enableSearchGrounding: true,
    enableDiagnosticsTools: true,
    quantumCoherenceTarget: 99.98,
    overrideDomain: 'google.com',
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  // Fetch initial nodes status
  useEffect(() => {
    fetchNodes();
  }, []);

  const fetchNodes = async () => {
    try {
      const res = await fetch('/api/system-diagnostics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (data && data.nodes) {
        setNodes(data.nodes);
      }
    } catch (e) {
      console.warn('Using default node metrics');
    }
  };

  const handleToggleSound = () => {
    const newState = soundEngine.toggleSound();
    setSoundEnabled(newState);
  };

  const addLog = (
    event_type: TelemetryLogEntry['event_type'],
    payload: Record<string, any>,
    level: TelemetryLogEntry['level'] = 'info'
  ) => {
    const newEntry: TelemetryLogEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleTimeString(),
      event_type,
      payload,
      level,
    };
    setLogs((prev) => [...prev.slice(-100), newEntry]);
  };

  // Execute Prompt via SSE Stream
  const handleExecutePrompt = async () => {
    if (!prompt.trim() || isStreaming) return;

    soundEngine.playScanSound();
    setIsStreaming(true);
    setStreamedText('');
    setGroundingSources([]);
    setActiveToolCalls([]);

    const newCycleId = `CYC-${Math.floor(Math.random() * 9000) + 1000}`;
    setActiveCycleId(newCycleId);

    // Fetch cognitive telemetry in parallel
    fetchStructuredTelemetry(prompt);

    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch('/api/stream-core', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          systemInstruction: config.system_instruction,
          temperature: config.temperature,
          enableSearchGrounding: config.enableSearchGrounding,
          enableDiagnosticsTools: config.enableDiagnosticsTools,
          overrideDomain: config.overrideDomain || 'google.com',
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.body) {
        throw new Error('No response stream body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const block of lines) {
          if (!block.trim()) continue;

          let eventType = 'message';
          let dataStr = '';

          const blockLines = block.split('\n');
          for (const line of blockLines) {
            if (line.startsWith('event: ')) {
              eventType = line.replace('event: ', '').trim();
            } else if (line.startsWith('data: ')) {
              dataStr = line.replace('data: ', '').trim();
            }
          }

          if (dataStr) {
            try {
              const data = JSON.parse(dataStr);

              if (eventType === 'telemetry') {
                addLog(data.event_type, data.payload, data.level);

                if (data.event_type === 'FUNCTION_CALL_DISPATCH') {
                  setActiveToolCalls((prev) => [...prev, data.payload]);
                  soundEngine.playBeep(800, 0.04);
                }
              } else if (eventType === 'chunk') {
                setStreamedText((prev) => prev + data.text);
                soundEngine.playPulseSound();
              } else if (eventType === 'grounding') {
                if (data.sources) {
                  setGroundingSources(data.sources);
                }
              } else if (eventType === 'done') {
                soundEngine.playCompleteSound();
              }
            } catch (err) {
              console.error('SSE JSON parse error:', err);
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Streaming error:', err);
        addLog('ENGINE_ERROR', { error: err.message }, 'error');
      }
    } finally {
      setIsStreaming(false);
    }
  };

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsStreaming(false);
      soundEngine.playBeep(400, 0.05);
      addLog('HUD TELEMETRY', { note: 'User interrupted execution cycle' }, 'warn');
    }
  };

  const fetchStructuredTelemetry = async (taskDesc: string) => {
    setIsTelemetryLoading(true);
    try {
      const res = await fetch('/api/cognitive-telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task: taskDesc }),
      });
      const data = await res.json();
      if (data && data.step_id) {
        setTelemetry(data);
        if (data.quantum_coherence) {
          setQuantumCoherence(data.quantum_coherence);
        }
      }
    } catch (e) {
      console.warn('Telemetry fetch error');
    } finally {
      setIsTelemetryLoading(false);
    }
  };

  const handleTriggerScan = async () => {
    setIsScanning(true);
    await fetchNodes();
    setTimeout(() => {
      setIsScanning(false);
      soundEngine.playCompleteSound();
      addLog('HUD TELEMETRY', { event: 'Full Hardware Core Rescan Completed' }, 'info');
    }, 600);
  };

  const handleRefreshNode = async (comp: string) => {
    try {
      const res = await fetch('/api/system-diagnostics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ component: comp }),
      });
      const updated = await res.json();
      setNodes((prev) =>
        prev.map((n) => (n.component === comp ? { ...n, ...updated } : n))
      );
      if (selectedNode?.component === comp) {
        setSelectedNode((prev) => (prev ? { ...prev, ...updated } : null));
      }
      addLog('FUNCTION_RESULT', updated, 'dispatch');
    } catch (e) {
      console.warn('Node refresh failed');
    }
  };

  return (
    <div className="min-h-screen bg-[#020205] text-zinc-300 flex flex-col font-sans selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Immersive UI Ambient Background Glow Orbs */}
      <div className="fixed inset-0 opacity-25 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] rounded-full bg-cyan-500/20 blur-[140px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] rounded-full bg-purple-600/20 blur-[140px]" />
        <div className="absolute top-[40%] right-[30%] w-[30%] h-[30%] rounded-full bg-emerald-500/10 blur-[120px]" />
      </div>

      {/* HUD Header Bar */}
      <HeaderHUD
        quantumCoherence={quantumCoherence}
        activeCycleId={activeCycleId}
        isStreaming={isStreaming}
        onOpenCodeModal={() => setIsCodeModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenInstallerModal={() => setIsInstallerModalOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6 relative z-10">
        {/* Top Grid: Interactive Visualizer + Reasoning Command Center */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left: Quantum Brain Visualizer (5 cols) */}
          <div className="lg:col-span-5 h-full">
            <QuantumBrainVisualizer
              nodes={nodes}
              selectedNode={selectedNode}
              onSelectNode={setSelectedNode}
              onTriggerScan={handleTriggerScan}
              isScanning={isScanning}
            />
          </div>

          {/* Right: Active Reasoning Command Center (7 cols) */}
          <div className="lg:col-span-7 h-full">
            <CommandCenter
              prompt={prompt}
              setPrompt={setPrompt}
              onExecutePrompt={handleExecutePrompt}
              isStreaming={isStreaming}
              onStopStreaming={handleStopStreaming}
              streamedText={streamedText}
              groundingSources={groundingSources}
              activeToolCalls={activeToolCalls}
              config={config}
              setConfig={setConfig}
              onOpenInstallerModal={() => setIsInstallerModalOpen(true)}
            />
          </div>
        </div>

        {/* Middle Grid: Telemetry Logs + Structured Cognitive Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Telemetry Log Terminal (7 cols) */}
          <div className="lg:col-span-7">
            <TelemetryHUD
              logs={logs}
              onClearLogs={() => setLogs([])}
            />
          </div>

          {/* Right: Structured Cognitive Telemetry Schema (5 cols) */}
          <div className="lg:col-span-5">
            <StructuredAnalysisPanel
              telemetry={telemetry}
              onRefreshTelemetry={() => fetchStructuredTelemetry(prompt)}
              isLoading={isTelemetryLoading}
            />
          </div>
        </div>

        {/* Bottom Section: Hardware Diagnostic Nodes Matrix */}
        <div>
          <DiagnosticsMatrix
            nodes={nodes}
            onSelectNode={setSelectedNode}
            onRefreshNode={handleRefreshNode}
            selectedNode={selectedNode}
          />
        </div>
      </main>

      {/* Footer Status Bar */}
      <footer className="border-t border-white/5 bg-black/40 py-3 px-6 text-center text-[10px] font-mono tracking-wider text-zinc-500 uppercase flex flex-wrap items-center justify-between gap-2 max-w-7xl mx-auto w-full relative z-10">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_4px_#22d3ee]" />
          <span>Gemini Quantum Core Engine • Status: Active Resonance</span>
        </div>
        <div className="flex items-center gap-4 text-zinc-500">
          <span>LATENCY: 0.002ms</span>
          <span>•</span>
          <span>MODEL: gemini-3.6-flash</span>
          <span>•</span>
          <span className="text-zinc-400">© 2026 Gemini Quantum Labs</span>
        </div>
      </footer>

      {/* Modals & Overlays */}
      <PythonSpecModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />

      <AssetExporterModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

      <InstallerModal
        isOpen={isInstallerModalOpen}
        onClose={() => setIsInstallerModalOpen(false)}
      />

      {/* Connectivity Status Banner */}
      <OfflineIndicator />
    </div>
  );
}
