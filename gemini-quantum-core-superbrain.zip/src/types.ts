export interface CognitiveTelemetry {
  step_id: string;
  confidence_score: number;
  primary_vector: string;
  subtasks: string[];
  quantum_coherence?: number;
  timestamp?: number;
}

export interface TelemetryLogEntry {
  id: string;
  timestamp: string;
  event_type: 'CYCLE_START' | 'FUNCTION_CALL_DISPATCH' | 'FUNCTION_RESULT' | 'HUD TELEMETRY' | 'ENGINE_ERROR' | 'CYCLE_COMPLETE' | 'GROUNDING_SEARCH';
  payload: Record<string, any>;
  level: 'info' | 'warn' | 'success' | 'dispatch' | 'error';
}

export interface SystemNodeStatus {
  component: string;
  name: string;
  status: 'NOMINAL' | 'DEGRADED' | 'OPTIMIZING' | 'OFFLINE';
  latency_ms: number;
  quantum_coherence: string;
  load_pct: number;
  temperature_c: number;
  description: string;
}

export interface CoreConfig {
  model: string;
  system_instruction: string;
  temperature: number;
  enableSearchGrounding: boolean;
  enableDiagnosticsTools: boolean;
  quantumCoherenceTarget: number;
  overrideDomain?: string;
}

export interface GroundingSource {
  title?: string;
  uri?: string;
}

export interface ExecutionCycle {
  cycle_id: string;
  prompt: string;
  response_text: string;
  telemetry: CognitiveTelemetry | null;
  grounding_sources: GroundingSource[];
  tool_calls: { name: string; args: Record<string, any>; result: any }[];
  status: 'idle' | 'running' | 'completed' | 'error';
  duration_ms: number;
  timestamp: string;
}
