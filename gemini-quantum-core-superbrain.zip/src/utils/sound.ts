class SoundEngine {
  private ctx: AudioContext | null = null;
  private enabled: boolean = false;

  constructor() {
    // Sound disabled by default until user toggles or interacts
  }

  public toggleSound(): boolean {
    this.enabled = !this.enabled;
    if (this.enabled && !this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.enabled) {
      this.playBeep(880, 0.05, 'sine');
    }
    return this.enabled;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  public playBeep(freq = 440, duration = 0.08, type: OscillatorType = 'sine', volume = 0.05) {
    if (!this.enabled || !this.ctx) return;
    try {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      // Ignore audio policy errors
    }
  }

  public playScanSound() {
    if (!this.enabled || !this.ctx) return;
    try {
      this.playBeep(600, 0.04, 'triangle', 0.04);
      setTimeout(() => this.playBeep(900, 0.04, 'triangle', 0.04), 50);
      setTimeout(() => this.playBeep(1200, 0.06, 'sine', 0.04), 100);
    } catch (e) {}
  }

  public playCompleteSound() {
    if (!this.enabled || !this.ctx) return;
    try {
      this.playBeep(523.25, 0.08, 'sine', 0.06); // C5
      setTimeout(() => this.playBeep(659.25, 0.08, 'sine', 0.06), 80); // E5
      setTimeout(() => this.playBeep(783.99, 0.12, 'sine', 0.06), 160); // G5
      setTimeout(() => this.playBeep(1046.50, 0.2, 'sine', 0.08), 240); // C6
    } catch (e) {}
  }

  public playPulseSound() {
    if (!this.enabled || !this.ctx) return;
    try {
      this.playBeep(300, 0.03, 'sine', 0.02);
    } catch (e) {}
  }
}

export const soundEngine = new SoundEngine();
