# Wing Gundam Zero Mobile Suit Control Framework

**Developer:** Gilbert Algordo (https://g.dev/gilbert_algordo)
**Architecture:** OS-X Zero System Real-Time Neural Core
