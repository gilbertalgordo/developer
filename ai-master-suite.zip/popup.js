document.addEventListener("DOMContentLoaded", () => {
  const queryInput = document.getElementById("query-input");
  const runBtn = document.getElementById("run-btn");
  const output = document.getElementById("output");
  const envBadge = document.getElementById("env-badge");
  const profileLink = document.getElementById("profile-link");

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].incognito) {
      envBadge.textContent = "Incognito Context";
      envBadge.classList.add("incognito");
    }
  });

  profileLink.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: "https://g.dev/gilbert_algordo" });
  });

  async function executeSearchOrAI() {
    const query = queryInput.value.trim();
    if (!query) return;

    output.textContent = "Processing query...";

    // 1. Chrome Built-in AI (Gemini Nano Prompt API)
    if (typeof window.LanguageModel !== "undefined") {
      try {
        const availability = await window.LanguageModel.availability();
        if (availability === "available") {
          const session = await window.LanguageModel.create();
          const result = await session.prompt(query);
          output.textContent = result;
          session.destroy();
          return;
        }
      } catch (e) {
        console.warn("Local Built-in AI fallback:", e);
      }
    }

    // 2. Fallback to Cloud API / Web Search
    chrome.storage.local.get(["geminiApiKey"], (data) => {
      if (data.geminiApiKey) {
        chrome.runtime.sendMessage(
          { action: "EXECUTE_GOOGLE_AI", prompt: query, apiKey: data.geminiApiKey },
          (response) => {
            if (response && response.success) {
              output.textContent = response.text;
            } else {
              output.textContent = `Error: ${response.error}`;
            }
          }
        );
      } else {
        chrome.tabs.create({ url: `https://www.google.com/search?q=${encodeURIComponent(query)}` });
        output.textContent = `Redirected query to Google Search: "${query}"`;
      }
    });
  }

  runBtn.addEventListener("click", executeSearchOrAI);
  queryInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") executeSearchOrAI();
  });
});