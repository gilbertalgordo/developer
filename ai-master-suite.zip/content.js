(function () {
  if (window.hasAIMasterOverlay) return;
  window.hasAIMasterOverlay = true;

  const host = document.createElement("div");
  host.id = "ai-master-hud-host";
  document.body.appendChild(host);
  const shadow = host.attachShadow({ mode: "closed" });

  const style = document.createElement("style");
  style.textContent = `
    .hud-bar {
      position: fixed;
      top: 12px;
      right: 12px;
      z-index: 2147483647;
      background: rgba(15, 23, 42, 0.92);
      border: 1px solid #38bdf8;
      backdrop-filter: blur(8px);
      border-radius: 24px;
      padding: 6px 14px;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      font-family: system-ui, -apple-system, sans-serif;
    }
    .hud-input {
      background: transparent;
      border: none;
      color: #f8fafc;
      font-size: 12px;
      outline: none;
      width: 170px;
    }
    .hud-btn {
      background: #38bdf8;
      color: #0f172a;
      border: none;
      border-radius: 12px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
    }
  `;

  const container = document.createElement("div");
  container.className = "hud-bar";
  container.innerHTML = `
    <input type="text" class="hud-input" id="hud-in" placeholder="AI Master Search..." />
    <button class="hud-btn" id="hud-go">Search</button>
  `;

  shadow.appendChild(style);
  shadow.appendChild(container);

  shadow.getElementById("hud-go").addEventListener("click", () => {
    const val = shadow.getElementById("hud-in").value.trim();
    if (val) window.location.href = `https://www.google.com/search?q=${encodeURIComponent(val)}`;
  });
})();