/**
 * AI Master Extension Service Worker with Auto-Update Daemon
 * Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

chrome.runtime.onInstalled.addListener((details) => {
  chrome.storage.local.set({
    developerProfile: "https://g.dev/gilbert_algordo",
    version: "3.6.0",
    geminiApiKey: "",
    autoUpdateEnabled: true,
    lastUpdateCheck: Date.now()
  });

  // Setup periodic 60-minute background auto-update alarm
  chrome.alarms.create("AI_MASTER_AUTO_UPDATE_ALARM", {
    periodInMinutes: 60
  });

  console.log(`AI Master Extension v3.6.0 initialized [Reason: ${details.reason}]`);
});

// Periodic Auto-Update Alarm Handler
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "AI_MASTER_AUTO_UPDATE_ALARM") {
    console.log("[AI Master Auto-Update] Running scheduled background update check...");
    chrome.runtime.requestUpdateCheck((status, details) => {
      console.log(`[AI Master Auto-Update] Status: ${status}`, details);
      chrome.storage.local.set({
        lastUpdateCheck: Date.now(),
        lastUpdateStatus: status
      });
    });
  }
});

// Auto-reload when new version is staged & ready
chrome.runtime.onUpdateAvailable.addListener((details) => {
  console.log(`[AI Master Auto-Update] New version available (${details.version}). Applying update...`);
  chrome.runtime.reload();
});

// Omnibox Query Trigger (@aimaster <query>)
chrome.omnibox.onInputEntered.addListener((text) => {
  const targetUrl = `https://www.google.com/search?q=${encodeURIComponent(text)}`;
  chrome.tabs.create({ url: targetUrl });
});

// Async API Dispatcher
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "EXECUTE_GOOGLE_AI") {
    callGoogleAiApi(request.prompt, request.apiKey)
      .then((data) => sendResponse({ success: true, text: data }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; 
  }

  if (request.action === "MANUAL_UPDATE_CHECK") {
    chrome.runtime.requestUpdateCheck((status, details) => {
      sendResponse({ status, details, checkedAt: Date.now() });
    });
    return true;
  }
});

async function callGoogleAiApi(prompt, apiKey) {
  if (!apiKey) throw new Error("API Key missing. Please set your Google AI API key in options.");

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }]
    })
  });

  const json = await response.json();
  if (!response.ok) throw new Error(json.error?.message || "Google AI API Error");
  return json.candidates[0].content.parts[0].text;
}