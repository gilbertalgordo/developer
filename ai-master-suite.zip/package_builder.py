import os
import zipfile

def build_extension_package(output_zip="ai-master-suite.zip"):
    # List of files and folders to package
    package_manifest = [
        "manifest.json",
        "background.js",
        "content.js",
        "popup.html",
        "popup.js",
        "icons/icon16.svg",
        "icons/icon48.svg",
        "icons/icon128.svg",
        "icons/chrome.svg",
        "icons/incognito.svg",
        "icons/chromeos.svg",
        "icons/aimaster.svg",
        "icons/google_ai.svg",
        "icons/searchbar.svg"
    ]

    print(f"[*] Building AI Master installer zip: {output_zip}...")
    
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for item in package_manifest:
            if os.path.exists(item):
                zipf.write(item)
                print(f"  [+] Included: {item}")
            else:
                print(f"  [-] Warning: File missing: {item}")

    print(f"\n[✓] Package created successfully: '{output_zip}'")

if __name__ == "__main__":
    build_extension_package()