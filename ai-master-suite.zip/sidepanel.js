document.addEventListener("DOMContentLoaded", () => {
  const sideInput = document.getElementById("side-input");
  const sideSend = document.getElementById("side-send");
  const sideChat = document.getElementById("side-chat");
  const extractBtn = document.getElementById("extract-dom-btn");

  async function appendMessage(sender, text) {
    const p = document.createElement("p");
    p.innerHTML = "<strong>" + sender + ":</strong> " + text;
    sideChat.appendChild(p);
    sideChat.scrollTop = sideChat.scrollHeight;
  }

  extractBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        appendMessage("System", "Analyzing active tab DOM: " + tabs[0].url);
        chrome.tabs.sendMessage(tabs[0].id, { type: "GET_DOM_TEXT" }, (response) => {
          if (response && response.text) {
            appendMessage("AI", "Extracted " + response.text.length + " characters from page. Summarizing content with Gemini 2.5...");
          }
        });
      }
    });
  });

  sideSend.addEventListener("click", () => {
    const text = sideInput.value.trim();
    if (!text) return;
    appendMessage("You", text);
    sideInput.value = "";
    setTimeout(() => {
      appendMessage("AI Master", "Processing '" + text + "' with Gemini 2.5 Flash neural engine...");
    }, 400);
  });
});