/**
 * Content Script - In-Page AI Master HUD
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

(function () {
  if (window.hasAIMasterHUD) return;
  window.hasAIMasterHUD = true;

  // Create Encapsulated Shadow DOM Container
  const host = document.createElement("div");
  host.id = "ai-master-hud-root";
  document.body.appendChild(host);
  const shadow = host.attachShadow({ mode: "closed" });

  const style = document.createElement("style");
  style.textContent = `
    .hud-card {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 320px;
      max-width: 90vw;
      background: rgba(15, 23, 42, 0.95);
      color: #f8fafc;
      border: 1px solid #38bdf8;
      border-radius: 12px;
      padding: 14px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
      z-index: 999999;
      font-family: system-ui, -apple-system, sans-serif;
      backdrop-filter: blur(8px);
    }
    .hud-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
      font-weight: bold;
      color: #38bdf8;
      font-size: 13px;
    }
    .hud-body {
      font-size: 12px;
      line-height: 1.5;
      max-height: 150px;
      overflow-y: auto;
      color: #e2e8f0;
    }
    .hud-close {
      cursor: pointer;
      color: #94a3b8;
      font-size: 14px;
    }
    .hud-close:hover { color: #fff; }
  `;

  const hud = document.createElement("div");
  hud.className = "hud-card";
  hud.style.display = "none";
  hud.innerHTML = `
    <div class="hud-header">
      <span>AI Master HUD</span>
      <span class="hud-close" id="close-hud">✕</span>
    </div>
    <div class="hud-body" id="hud-text">Ready...</div>
  `;

  shadow.appendChild(style);
  shadow.appendChild(hud);

  shadow.getElementById("close-hud").addEventListener("click", () => {
    hud.style.display = "none";
  });

  // Listener for Background Commands
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "ANALYZE_SELECTION") {
      hud.style.display = "block";
      const hudText = shadow.getElementById("hud-text");
      hudText.textContent = `Analyzing (${msg.isIncognito ? "Incognito" : "Standard"}): "${msg.text}"...`;
      
      // Execute local analysis trigger
      window.dispatchEvent(new CustomEvent("AI_MASTER_INSPECT", { detail: msg.text }));
    }
  });
})();