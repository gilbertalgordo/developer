/**
 * AI Master Controller Script
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

document.addEventListener("DOMContentLoaded", async () => {
  const consoleEl = document.getElementById("console");
  const inputEl = document.getElementById("prompt-input");
  const execBtn = document.getElementById("exec-btn");
  const badgeEl = document.getElementById("env-badge");
  const profileBtn = document.getElementById("profile-btn");

  // Determine Active Context (Incognito / Platform)
  chrome.runtime.sendMessage({ action: "GET_ENVIRONMENT" }, (env) => {
    if (env && env.isIncognito) {
      badgeEl.textContent = "Incognito Context";
      badgeEl.classList.add("incognito");
    }
  });

  // Handle Safe Profile Navigation
  profileBtn.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: "https://g.dev/gilbert_algordo" });
  });

  // Core Prompt Execution Flow
  async function runPrompt() {
    const query = inputEl.value.trim();
    if (!query) return;

    log("user", `Query: ${query}`);
    inputEl.value = "";
    
    const aiLog = log("ai", "Initializing Built-in AI...");

    try {
      // 1. Native Chrome Built-in AI API (Gemini Nano)
      if (typeof window.ai !== "undefined" && window.ai.languageModel) {
        const capabilities = await window.ai.languageModel.capabilities();
        
        if (capabilities.available === "readily" || capabilities.available === "after-download") {
          const session = await window.ai.languageModel.create({
            systemPrompt: "You are AI Master, an expert developer assistant."
          });

          // Streaming Response Processing
          const stream = session.promptStreaming(query);
          let fullText = "";
          for await (const chunk of stream) {
            fullText = chunk;
            aiLog.textContent = fullText;
            consoleEl.scrollTop = consoleEl.scrollHeight;
          }
          return;
        }
      }

      // 2. Hybrid Fallback logic if Built-in AI is disabled or unsupported
      aiLog.textContent = `[Cloud/Hybrid Fallback] Query processed: "${query}". (Add API Key in settings for full remote LLM execution).`;

    } catch (err) {
      aiLog.textContent = `Execution Error: ${err.message}`;
    }
  }

  function log(type, text) {
    const entry = document.createElement("div");
    entry.className = `log-entry log-${type}`;
    entry.textContent = text;
    consoleEl.appendChild(entry);
    consoleEl.scrollTop = consoleEl.scrollHeight;
    return entry;
  }

  execBtn.addEventListener("click", runPrompt);
  inputEl.addEventListener("keypress", (e) => {
    if (e.key === "Enter") runPrompt();
  });
});