/**
 * Background Service Worker - AI Master Engine
 * Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
 */

chrome.runtime.onInstalled.addListener((details) => {
  // Initialize Persistent Configurations & Auto-Update Policy
  chrome.storage.local.set({
    devProfile: "https://g.dev/gilbert_algordo",
    devGithub: "https://github.com/gilbertalgordo",
    aiMode: "hybrid", // Options: 'built-in', 'cloud', 'hybrid'
    autoUpdatePolicy: "periodic-hourly",
    autoAnalyze: false,
    installedVersion: "2.1.0"
  });

  // Setup periodic auto-update check alarm (every 60 mins)
  chrome.alarms.create("ai-master-auto-update-check", { periodInMinutes: 60 });

  // Register Context Menu Actions
  chrome.contextMenus.create({
    id: "ai-master-analyze",
    title: "AI Master: Analyze Selected Text",
    contexts: ["selection"]
  });

  chrome.contextMenus.create({
    id: "ai-master-check-updates",
    title: "AI Master: Check for Auto-Updates",
    contexts: ["action"]
  });

  chrome.contextMenus.create({
    id: "ai-master-open-profile",
    title: "Developer Profile (g.dev/gilbert_algordo)",
    contexts: ["action"]
  });
});

// Periodic Auto-Update Alarm Handler
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "ai-master-auto-update-check") {
    console.log("[AI Master Auto-Updater] Checking for extension updates...");
    chrome.runtime.requestUpdateCheck((status, details) => {
      if (status === "update_available") {
        console.log(`[AI Master Auto-Updater] New version available: v${details.version}`);
      } else if (status === "no_update") {
        console.log("[AI Master Auto-Updater] Extension is up to date.");
      }
    });
  }
});

// Auto-Update Available Listener (triggers graceful hot-reload)
chrome.runtime.onUpdateAvailable.addListener((details) => {
  console.log(`[AI Master Auto-Updater] Installing release v${details.version}...`);
  chrome.storage.local.set({ pendingUpdateVersion: details.version });
  // Reload service worker and active extension views
  chrome.runtime.reload();
});

// Context Menu Event Dispatcher
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "ai-master-analyze") {
    chrome.tabs.sendMessage(tab.id, {
      action: "ANALYZE_SELECTION",
      text: info.selectionText,
      isIncognito: tab.incognito
    });
  } else if (info.menuItemId === "ai-master-check-updates") {
    chrome.runtime.requestUpdateCheck((status, details) => {
      chrome.tabs.sendMessage(tab.id, {
        action: "UPDATE_STATUS_REPORT",
        status: status,
        details: details
      });
    });
  } else if (info.menuItemId === "ai-master-open-profile") {
    chrome.tabs.create({ url: "https://g.dev/gilbert_algordo" });
  }
});

// Global Cross-Context Message Bus
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_ENVIRONMENT") {
    sendResponse({
      isIncognito: sender.tab ? sender.tab.incognito : false,
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      version: "2.1.0"
    });
  } else if (request.action === "TRIGGER_AUTO_UPDATE") {
    chrome.runtime.requestUpdateCheck((status, details) => {
      sendResponse({ status, details });
    });
    return true;
  }
  return true;
});