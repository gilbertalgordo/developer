# AI Master Extension - Gilbert Algordo
Cross-platform AI Master Assistant for Standard Chrome, Incognito, ChromeOS, and Mobile Browsers.
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
Repository: https://github.com/gilbertalgordo

## Installation Instructions (Load Unpacked):
1. Unzip this package to a local directory.
2. Open Google Chrome and navigate to: chrome://extensions/
3. Enable "Developer mode" in the top-right corner.
4. Click "Load unpacked" and select this folder.
5. Enable "Allow in Incognito" in extension details to activate spanning mode!
