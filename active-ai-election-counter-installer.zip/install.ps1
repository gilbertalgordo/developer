# ==============================================================================
# Active AI National Election Counter - Windows PowerShell Installer
# Architecture: Cryptographic SHA-256 Ledger & Automated Audit Node
# ==============================================================================

$ErrorActionPreference = "Stop"
$NodePort = if ($env:PORT) { $env:PORT } else { "3000" }
$ClusterId = if ($env:CLUSTER_ID) { $env:CLUSTER_ID } else { "NAT-ELECTORAL-CLUSTER-01" }

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "⚡ Active AI National Election Counter - Windows Node Deployment" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "▶ Target Node Cluster ID : $ClusterId" -ForegroundColor Green
Write-Host "▶ Binding TCP Port       : $NodePort" -ForegroundColor Green
Write-Host "----------------------------------------------------------------------"

# Verify Node.js
try {
    $nodeVersion = & node -v
    Write-Host "✅ Detected Node.js runtime: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js 18+ is required. Please download from https://nodejs.org/" -ForegroundColor Red
    Exit 1
}

# Run standalone node
$env:PORT = $NodePort
$env:NODE_ENV = "production"
$env:CLUSTER_ID = $ClusterId

Write-Host "🚀 Launching Active AI Standalone Election Ledger Node..." -ForegroundColor Cyan
Start-Process -FilePath "node" -ArgumentList "run-standalone.js" -NoNewWindow

Write-Host "----------------------------------------------------------------------"
Write-Host "🎉 Active AI Electoral Ledger Node is active!" -ForegroundColor Green
Write-Host "🌐 Web Dashboard: http://localhost:$NodePort" -ForegroundColor Cyan
Write-Host "📊 Health Check:  http://localhost:$NodePort/api/v2/system/health" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
