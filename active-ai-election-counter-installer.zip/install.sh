#!/usr/bin/env bash
# ==============================================================================
# Active AI National Election Counter Core - Autonomous Node Installer
# Architecture: Cryptographic SHA-256 Ledger & Automated Audit Node
# Version: 2.1.0-EXPANDED
# ==============================================================================

set -euo pipefail

NODE_PORT="${PORT:-3000}"
CLUSTER_ID="${CLUSTER_ID:-NAT-ELECTORAL-CLUSTER-01}"
INSTALL_DIR="${INSTALL_DIR:-/opt/active-ai-election-counter}"

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}======================================================================${NC}"
echo -e "${CYAN}⚡ Active AI National Election Counter - Node Deployment Installer${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "▶ Target Node Cluster ID : ${GREEN}${CLUSTER_ID}${NC}"
echo -e "▶ Binding TCP Port       : ${GREEN}${NODE_PORT}${NC}"
echo -e "▶ Target Directory       : ${GREEN}${INSTALL_DIR}${NC}"
echo -e "----------------------------------------------------------------------"

# 1. Check Node.js runtime
if ! command -v node >/dev/null 2>&1; then
  echo -e "${RED}❌ Error: Node.js (v18.0.0 or higher) is required but was not found.${NC}"
  echo "Please install Node.js using your package manager or Nodesource:"
  echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
  echo "  apt-get install -y nodejs"
  exit 1
fi

NODE_VER=$(node -v)
echo -e "✅ Found Node.js runtime: ${GREEN}${NODE_VER}${NC}"

# 2. Check OpenSSL for cryptographic verification
if command -v openssl >/dev/null 2>&1; then
  echo -e "✅ Found OpenSSL: ${GREEN}$(openssl version)${NC}"
else
  echo -e "${YELLOW}⚠️ OpenSSL binary not in PATH; falling back to Node.js crypto module.${NC}"
fi

# 3. Setup Installation Directory
echo -e "📁 Initializing deployment target: ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}"
cp -rf ./* "${INSTALL_DIR}/" 2>/dev/null || true
cd "${INSTALL_DIR}"

# 4. Verify Local Cryptographic Manifest
if [ -f "./verify-signatures.sh" ]; then
  echo -e "🔐 Verifying integrity of genesis election manifest..."
  chmod +x ./verify-signatures.sh
  bash ./verify-signatures.sh || echo -e "${YELLOW}⚠️ Genesis check warning - proceeding with node init.${NC}"
fi

# 5. Service Configuration
export PORT="${NODE_PORT}"
export NODE_ENV="production"
export CLUSTER_ID="${CLUSTER_ID}"

# Check for root privilege to install systemd unit
if [ "$(id -u)" -eq 0 ] && command -v systemctl >/dev/null 2>&1; then
  echo -e "⚙️ Registering systemd service: /etc/systemd/system/election-counter.service..."
  cat <<SERVICE_EOF > /etc/systemd/system/election-counter.service
[Unit]
Description=Active AI National Election Counter Node
Documentation=https://github.com/active-ai/election-counter
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=$(which node) ${INSTALL_DIR}/run-standalone.js
Restart=always
RestartSec=5
Environment=PORT=${NODE_PORT}
Environment=NODE_ENV=production
Environment=CLUSTER_ID=${CLUSTER_ID}
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
SERVICE_EOF

  systemctl daemon-reload
  systemctl enable election-counter.service
  systemctl restart election-counter.service
  echo -e "${GREEN}✅ systemd unit active and running!${NC}"
  echo -e "Check status: ${CYAN}systemctl status election-counter${NC}"
else
  echo -e "ℹ️ Non-root mode: Starting background worker node..."
  nohup node ./run-standalone.js > election-counter.log 2>&1 &
  WORKER_PID=$!
  echo -e "${GREEN}✅ Election node started in background (PID: ${WORKER_PID})${NC}"
  echo -e "Logs available at: ${INSTALL_DIR}/election-counter.log"
fi

echo -e "----------------------------------------------------------------------"
echo -e "${GREEN}🎉 ACTIVE AI ELECTION COUNTER DEPLOYED SUCCESSFULLY!${NC}"
echo -e "🌐 Access Web HUD & API at: ${CYAN}http://localhost:${NODE_PORT}${NC}"
echo -e "📊 Health Check:            ${CYAN}http://localhost:${NODE_PORT}/api/v2/system/health${NC}"
echo -e "${CYAN}======================================================================${NC}"
