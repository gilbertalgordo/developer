# Active AI National Election Counter - Node Deployment & Distribution Package
**Architecture: High-Integrity Autonomous Electoral Telemetry & Cryptographic Ledger Core**  
**Version: 2.1.0-EXPANDED**

---

## 📦 Package Contents

| File | Purpose |
| :--- | :--- |
| `install.sh` | One-click Bare-Metal / Linux / macOS automated deployment script with systemd service |
| `install.ps1` | Windows PowerShell automated service launcher |
| `Dockerfile` | Production-hardened multi-stage Alpine Node.js container |
| `docker-compose.yml` | Single-command Docker Compose orchestration with automated healthchecks |
| `electoral-core-deploy.yaml` | Kubernetes Deployment, ClusterIP, and Ingress manifests |
| `run-standalone.js` | Autonomous zero-dependency standalone Node.js server with embedded UI & REST API |
| `election-manifest.json` | Certified genesis election ledger state, candidate rosters, and cryptographic anchors |
| `verify-signatures.sh` | Standalone bash script for SHA-256 and ECDSA cryptographic receipt validation |
| `config.env.example` | Environment variables configuration template |

---

## 🚀 Quick Start Deployment Options

### Option 1: Linux / macOS Bare Metal (Recommended)
```bash
chmod +x install.sh
sudo ./install.sh
```
The installer automatically detects your Node.js runtime, installs system dependencies, registers `/etc/systemd/system/election-counter.service`, and activates the background ledger node on port **3000**.

### Option 2: Docker Compose
```bash
docker compose up -d --build
```
Access the dashboard at `http://localhost:3000`.

### Option 3: Kubernetes Deployment
```bash
kubectl apply -f electoral-core-deploy.yaml
```

### Option 4: Air-Gapped Offline Voting Station
Run the zero-dependency autonomous server directly:
```bash
node run-standalone.js
```

---

## 🔐 Cryptographic Verification
Verify the SHA-256 hashes and digital signatures of the ledger:
```bash
chmod +x verify-signatures.sh
./verify-signatures.sh
```

---

## 📡 Core API Endpoints
- **Health Check**: `GET /api/v2/system/health`
- **Election Summary**: `GET /api/v2/election-summary`
- **Ingest Precinct**: `POST /api/v2/ingest-precinct`
- **5-Vector Auto-Scan**: `POST /api/v2/auto-scan`
- **Automated Fix**: `POST /api/v2/auto-fix`

---
© 2026 Active AI National Election Counter Consortium • Cryptographically Verified
