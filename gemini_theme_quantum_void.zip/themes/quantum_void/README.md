# Quantum Void - Gemini OS Theme Package
**Author**: Gemini System Architect
**Primary Accent**: #00E5FF
**Surface Void**: #0B0F19
**Glow**: #3B82F6

## Installation on Android Gemini OS
This package is structured for extraction by `ThemeZipInstaller.kt`:
```kotlin
val themeFolder = ThemeZipInstaller.extractThemeZip(context, zipFile, "Quantum Void")
```
Generated via Gemini OS Theme Studio.
