// Gemini OS Live Wallpaper Shader - Quantum Void
precision highp float;
varying vec2 vUv;
uniform float uTime;
uniform vec3 uBaseColor; // #00E5FF
uniform vec3 uSecondaryColor; // #3B82F6

void main() {
    float wave = sin(vUv.x * 10.0 + uTime * 1.0) * 0.5 + 0.5;
    vec3 finalColor = mix(uBaseColor, uSecondaryColor, wave);
    gl_FragColor = vec4(finalColor, 0.85);
}
