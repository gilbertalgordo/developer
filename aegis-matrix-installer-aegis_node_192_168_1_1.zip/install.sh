#!/usr/bin/env bash
# ==============================================================================
# AEGIS IMMORTALITY ENGINE MATRIX - AUTOMATED NODE INSTALLER
# Entity ID: Gilbert_Algordo_Active_Matrix
# Target Gateway: 192.168.1.1:8443
# Target Node: aegis_node_192_168_1_1 (subnet-192.168.1.1)
# ==============================================================================

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}"
cat << "EOF"
    ___    ______ _____ _____ _____   _____ ____  ____  ______
   /   |  / ____// ___//_  _// ___/  / ___// __ \/ __ \/ ____/
  / /| | / __/  / / __  / /  \__ \  / /   / / / / /_/ / __/   
 / ___ |/ /___ / /_/ /_/ /  ___/ / / /___/ /_/ / _, _/ /___   
/_/  |_/_____/ \____//___/ /____/  \____/\____/_/ |_/_____/   
    IMMORTALITY ENGINE MATRIX - AUTONOMOUS NODE INSTALLER
EOF
echo -e "${NC}"

INSTALL_DIR="/opt/aegis-matrix"
CONFIG_DIR="/etc/aegis-matrix"
SERVICE_NAME="aegis-immortality.service"
USER="aegis"

echo -e "${YELLOW}[1/6] Verifying system privileges and dependencies...${NC}"
if [ "$EUID" -ne 0 ]; then
  echo -e "${YELLOW}[!] Warning: Running as non-root. Installing to local directory ~/aegis-matrix${NC}"
  INSTALL_DIR="$HOME/aegis-matrix"
  CONFIG_DIR="$HOME/.config/aegis-matrix"
  SYSTEMD_MODE=0
else
  SYSTEMD_MODE=1
fi

mkdir -p "$INSTALL_DIR" "$CONFIG_DIR"

echo -e "${YELLOW}[2/6] Detecting Python 3 and Cryptographic Libraries...${NC}"
if command -v python3 &>/dev/null; then
    PY_VER=$(python3 --version)
    echo -e "${GREEN}[✓] Found: $PY_VER${NC}"
else
    echo -e "${RED}[✗] Python 3 is required. Please install Python 3.9+ first.${NC}"
    exit 1
fi

echo -e "${YELLOW}[3/6] Setting up virtual environment in $INSTALL_DIR/venv...${NC}"
python3 -m venv "$INSTALL_DIR/venv"
source "$INSTALL_DIR/venv/bin/activate"
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo -e "${GREEN}[✓] Core cryptographic dependencies installed (AESGCM, Cryptography, Requests).${NC}"

echo -e "${YELLOW}[4/6] Writing local node configuration...${NC}"
cp config.json "$CONFIG_DIR/config.json"
cp immortality_core.py "$INSTALL_DIR/immortality_core.py"
cp node_daemon.py "$INSTALL_DIR/node_daemon.py"
chmod +x "$INSTALL_DIR/immortality_core.py" "$INSTALL_DIR/node_daemon.py"

echo -e "${YELLOW}[5/6] Testing handshake with Gateway 192.168.1.1:8443...${NC}"
if ping -c 1 -W 1 "192.168.1.1" &>/dev/null; then
    echo -e "${GREEN}[✓] Gateway 192.168.1.1 is reachable!${NC}"
else
    echo -e "${YELLOW}[!] Gateway 192.168.1.1 ICMP ping inactive (firewalled or simulated). Direct TCP mesh active.${NC}"
fi

if [ "$SYSTEMD_MODE" -eq 1 ]; then
    echo -e "${YELLOW}[6/6] Installing systemd background service...${NC}"
    cp aegis-matrix.service /etc/systemd/system/aegis-matrix.service
    systemctl daemon-reload
    systemctl enable aegis-matrix.service
    systemctl restart aegis-matrix.service
    echo -e "${GREEN}[✓] Service aegis-matrix.service enabled and running!${NC}"
else
    echo -e "${YELLOW}[6/6] Starting daemon in background...${NC}"
    nohup "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/node_daemon.py" > "$INSTALL_DIR/daemon.log" 2>&1 &
    echo -e "${GREEN}[✓] Node daemon active. PID: $!${NC}"
fi

echo ""
echo -e "${GREEN}===============================================================${NC}"
echo -e "${GREEN}  AEGIS IMMORTALITY NODE INSTALLED SUCCESSFULLY!${NC}"
echo -e "${GREEN}===============================================================${NC}"
echo -e "Node Name:     aegis_node_192_168_1_1"
echo -e "Entity ID:     Gilbert_Algordo_Active_Matrix"
echo -e "Gateway Relay: http://192.168.1.1:8443"
echo -e "Status API:    http://127.0.0.1:8443/health"
echo -e "Logs:          journalctl -u aegis-matrix -f (or $INSTALL_DIR/daemon.log)"
echo ""
