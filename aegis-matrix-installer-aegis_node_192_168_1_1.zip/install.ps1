# ==============================================================================
# AEGIS IMMORTALITY ENGINE MATRIX - POWERSHELL INSTALLER FOR WINDOWS
# Entity ID: Gilbert_Algordo_Active_Matrix
# Gateway: 192.168.1.1:8443
# ==============================================================================

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  AEGIS IMMORTALITY CORE - WINDOWS INSTALLER" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$InstallDir = "$env:USERPROFILE\AegisMatrix"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

Write-Host "[1/4] Checking Python runtime..." -ForegroundColor Yellow
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Python not found in PATH. Please install Python 3.9+." -ForegroundColor Red
    Exit 1
}

Write-Host "[2/4] Initializing virtual environment in $InstallDir\venv..." -ForegroundColor Yellow
python -m venv "$InstallDir\venv"
& "$InstallDir\venv\Scripts\pip.exe" install --upgrade pip --quiet
& "$InstallDir\venv\Scripts\pip.exe" install cryptography requests fastapi uvicorn --quiet

Write-Host "[3/4] Copying core engine scripts..." -ForegroundColor Yellow
Copy-Item "immortality_core.py" -Destination "$InstallDir\immortality_core.py"
Copy-Item "node_daemon.py" -Destination "$InstallDir\node_daemon.py"
Copy-Item "config.json" -Destination "$InstallDir\config.json"

Write-Host "[4/4] Starting node background daemon on port 8443..." -ForegroundColor Yellow
Start-Process -FilePath "$InstallDir\venv\Scripts\python.exe" -ArgumentList "$InstallDir\node_daemon.py" -WindowStyle Hidden

Write-Host ""
Write-Host "[SUCCESS] Aegis Node installed and active in background!" -ForegroundColor Green
Write-Host "Gateway: http://192.168.1.1:8443" -ForegroundColor White
Write-Host "Local Health: http://localhost:8443/health" -ForegroundColor White
