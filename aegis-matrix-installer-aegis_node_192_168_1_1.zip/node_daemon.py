#!/usr/bin/env python3
"""
AEGIS Mesh Node Daemon
Node Name: aegis_node_192_168_1_1
Region: subnet-192.168.1.1
Listens on: 0.0.0.0:8443
Relays to Master Gateway: 192.168.1.1:8443
"""

import sys
import json
import time
import socket
from http.server import HTTPServer, BaseHTTPRequestHandler

NODE_CONFIG = {
    "node_name": "aegis_node_192_168_1_1",
    "entity_id": "Gilbert_Algordo_Active_Matrix",
    "gateway_ip": "192.168.1.1",
    "gateway_port": 8443,
    "region": "subnet-192.168.1.1",
    "shard_capacity": 512,
    "status": "ACTIVE",
    "boot_time": time.time()
}

class AegisNodeHandler(BaseHTTPRequestHandler):
    def _set_headers(self, content_type="application/json"):
        self.send_response(200)
        self.send_header('Content-type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers()

    def do_GET(self):
        if self.path == '/health' or self.path == '/':
            self._set_headers()
            uptime_sec = int(time.time() - NODE_CONFIG["boot_time"])
            response = {
                "status": "ACTIVE",
                "node": NODE_CONFIG["node_name"],
                "region": NODE_CONFIG["region"],
                "uptime_seconds": uptime_sec,
                "active_shards": NODE_CONFIG["shard_capacity"],
                "gateway_sync": f"192.168.1.1:8443",
                "timestamp": time.time()
            }
            self.wfile.write(json.dumps(response, indent=2).encode('utf-8'))
        elif self.path == '/topology':
            self._set_headers()
            self.wfile.write(json.dumps(NODE_CONFIG, indent=2).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/shard/sync':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            self._set_headers()
            response = {
                "status": "ACCEPTED",
                "received_bytes": len(post_data),
                "replicated": True,
                "timestamp": time.time()
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

def run_daemon(port=8443):
    server_address = ('0.0.0.0', port)
    httpd = HTTPServer(server_address, AegisNodeHandler)
    print(f"[*] AEGIS Node Daemon online at http://0.0.0.0:{port}")
    print(f"[*] Linked Gateway: http://192.168.1.1:8443")
    print(f"[*] Shard capacity: 512 slots allocated.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] Halting node daemon cleanly...")
        httpd.server_close()

if __name__ == "__main__":
    port = 8443
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_daemon(port)
