# AEGIS Immortality Engine Matrix - Deployment Package
**Entity ID:** `Gilbert_Algordo_Active_Matrix`  
**Target Gateway:** `http://192.168.1.1:8443`  
**Node Name:** `aegis_node_192_168_1_1`  
**Security Lattice:** `AES-256-GCM`  

---

## 🚀 Quickstart Installation (Linux / macOS)

1. Extract the ZIP archive:
   ```bash
   unzip aegis-matrix-installer.zip
   cd aegis-matrix-installer
   ```

2. Execute the automated installer:
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

3. Verify node health & mesh pairing:
   ```bash
   curl http://localhost:8443/health
   ```

---

## 🐳 Docker Deployment

Run directly via Docker Compose:
```bash
docker compose up -d
```

View real-time logs:
```bash
docker compose logs -f
```

---

## 🪟 Windows Deployment (PowerShell)

Open PowerShell as Administrator in this directory:
```powershell
Set-ExecutionPolicy RemoteSigned -Scope Process
.\install.ps1
```

---

## 📦 Package Contents
- `install.sh` — One-click automated bash installer with dependency checks.
- `install.ps1` — Windows PowerShell automated installer.
- `immortality_core.py` — Master persistence engine (AES-256-GCM + state snapshots).
- `node_daemon.py` — Lightweight HTTP/REST mesh daemon.
- `config.json` — Node parameters, gateway pairing, and encryption credentials.
- `requirements.txt` — Cryptographic Python dependencies.
- `Dockerfile` & `docker-compose.yml` — Containerized orchestration.
- `aegis-matrix.service` — Systemd service unit for persistent boot.
