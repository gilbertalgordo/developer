import os
import time
import json
import hashlib
from ai_core import ActiveAICore

class VaultAutoUpdater:
    def __init__(self, watch_dir="./icloud_vault", poll_interval=10):
        self.watch_dir = watch_dir
        self.poll_interval = poll_interval
        self.core = ActiveAICore(storage_path=watch_dir)
        self.file_signatures = {}

    def scan_and_update(self):
        print(f"[AutoUpdate] Scanning vault directory: {self.watch_dir}...")
        updated_count = 0
        if not os.path.exists(self.watch_dir):
            os.makedirs(self.watch_dir, exist_ok=True)

        for filename in os.listdir(self.watch_dir):
            if filename == "ai_index.json" or filename.startswith("."):
                continue
            file_path = os.path.join(self.watch_dir, filename)
            if not os.path.isfile(file_path):
                continue

            mtime = os.path.getmtime(file_path)
            size = os.path.getsize(file_path)
            sig = f"{mtime}_{size}"

            if self.file_signatures.get(filename) != sig:
                print(f"[AutoUpdate] Change detected in {filename}. Synchronizing...")
                res = self.core.process_and_sync(file_path)
                self.file_signatures[filename] = sig
                updated_count += 1
                print(f"  -> Synced: {filename} (Tags: {res.get('tags')})")

        print(f"[AutoUpdate] Scan finished. Updated {updated_count} files.")
        return updated_count

    def run_daemon(self):
        print("=== iCloud Active AI Auto-Update Daemon Started ===")
        print(f"Watching: {self.watch_dir} | Polling every {self.poll_interval}s | Press Ctrl+C to stop")
        try:
            while True:
                self.scan_and_update()
                time.sleep(self.poll_interval)
        except KeyboardInterrupt:
            print("\n[AutoUpdate] Daemon terminated gracefully.")

if __name__ == "__main__":
    updater = VaultAutoUpdater()
    updater.run_daemon()
