import os
import json
import hashlib

class ActiveAICore:
    def __init__(self, storage_path="./icloud_vault"):
        self.storage_path = storage_path
        os.makedirs(self.storage_path, exist_ok=True)
        self.index_file = os.path.join(self.storage_path, "ai_index.json")
        self.load_index()

    def load_index(self):
        if os.path.exists(self.index_file):
            with open(self.index_file, "r") as f:
                self.index = json.load(f)
        else:
            self.index = {}

    def save_index(self):
        with open(self.index_file, "w") as f:
            json.dump(self.index, f, indent=4)

    def process_and_sync(self, file_path):
        if not os.path.exists(file_path):
            return {"status": "error", "message": "File not found"}
        
        file_name = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            file_bytes = f.read()
            file_hash = hashlib.sha256(file_bytes).hexdigest()

        # Active AI categorization & tagging simulation
        ai_tags = ["sync-ready", "auto-optimized", "secure-vault"]
        if file_name.endswith((".jpg", ".png", ".jpeg")):
            ai_tags.append("visual-media")
        elif file_name.endswith((".txt", ".md", ".pdf")):
            ai_tags.append("document")

        dest_path = os.path.join(self.storage_path, file_name)
        with open(dest_path, "wb") as f:
            f.write(file_bytes)

        self.index[file_name] = {
            "hash": file_hash,
            "tags": ai_tags,
            "status": "active-synced"
        }
        self.save_index()
        return {"status": "success", "file": file_name, "tags": ai_tags}
