import sys
from ai_core import ActiveAICore

def main():
    ai_cloud = ActiveAICore()
    print("=== iCloud Active AI Manager Initialized ===")
    
    if len(sys.argv) > 1:
        target_file = sys.argv[1]
        result = ai_cloud.process_and_sync(target_file)
        print(result)
    else:
        print("Usage: python main.py <path_to_file_to_sync>")

if __name__ == "__main__":
    main()
