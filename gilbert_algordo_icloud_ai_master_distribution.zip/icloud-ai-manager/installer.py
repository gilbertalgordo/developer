import os
import zipfile
import subprocess
import sys

def create_zip_package():
    zip_name = "icloud_ai_bundle.zip"
    files_to_pack = ["ai_core.py", "main.py", "requirements.txt"]
    
    print(f"Creating distribution package: {zip_name}...")
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in files_to_pack:
            if os.path.exists(file):
                zipf.write(file)
                print(f"Added -> {file}")
    print("Package creation complete.")

def install_dependencies():
    print("Installing active runtime requirements...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    print("Installation finished successfully.")

if __name__ == "__main__":
    install_dependencies()
    create_zip_package()
