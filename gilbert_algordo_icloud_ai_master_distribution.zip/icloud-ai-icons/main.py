from icon_generator import ActiveAIIconGenerator

def main():
    print("=== Initializing iCloud Active AI Icon Renderer ===")
    generator = ActiveAIIconGenerator()
    saved_path = generator.generate_icloud_ai_icon(size=(512, 512), filename="icloud_active_ai_hud.png")
    print(f"High-definition icon successfully rendered at: {saved_path}")

if __name__ == "__main__":
    main()
