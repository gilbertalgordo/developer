import os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

class ActiveAIIconGenerator:
    def __init__(self, output_dir="./generated_icons"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_icloud_ai_icon(self, size=(512, 512), filename="icloud_ai_icon.png"):
        img = Image.new("RGBA", size, (15, 23, 42, 255)) # Deep slate futuristic background
        draw = ImageDraw.Draw(img)

        # Draw glowing neural-cloud mesh background circles
        draw.ellipse([80, 80, 432, 432], outline=(56, 189, 248, 100), width=4)
        draw.ellipse([140, 140, 372, 372], outline=(129, 140, 248, 150), width=2)

        # Draw stylized cloud geometry
        cloud_color = (241, 245, 249, 240)
        draw.arc([130, 200, 290, 360], start=180, end=360, fill=cloud_color, width=16)
        draw.arc([220, 150, 410, 330], start=180, end=360, fill=cloud_color, width=20)
        draw.rectangle([160, 270, 360, 350], fill=cloud_color)
        draw.ellipse([130, 270, 210, 350], fill=cloud_color)
        draw.ellipse([300, 260, 380, 340], fill=cloud_color)

        # Draw AI Core Node Indicator
        node_color = (14, 165, 233, 255)
        draw.ellipse([236, 230, 276, 270], fill=node_color)
        draw.line([(256, 180), (256, 230)], fill=node_color, width=4)
        draw.line([(256, 270), (256, 320)], fill=node_color, width=4)
        draw.line([(206, 250), (236, 250)], fill=node_color, width=4)
        draw.line([(276, 250), (306, 250)], fill=node_color, width=4)

        output_path = self.output_dir / filename
        img.save(output_path, "PNG")
        return str(output_path)
