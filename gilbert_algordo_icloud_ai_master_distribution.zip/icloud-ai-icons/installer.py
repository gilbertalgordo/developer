import os
import sys
import zipfile
import subprocess
from pathlib import Path
from icon_generator import ActiveAIIconGenerator

PROJECT_FILES = [
    "icon_generator.py",
    "main.py",
    "requirements.txt"
]

def build_zip_package():
    zip_name = "gilbert_algordo_icloud_ai_icons.zip"
    print(f"Packaging icon generator and assets into {zip_name}...")
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in PROJECT_FILES:
            if Path(file).exists():
                zipf.write(file)
                print(f"Packed: {file}")
        
        # Include generated icon bundle in zip
        icon_gen = ActiveAIIconGenerator()
        icon_path = icon_gen.generate_icloud_ai_icon()
        if Path(icon_path).exists():
            zipf.write(icon_path, arcname=f"assets/{Path(icon_path).name}")
            print(f"Packed Asset: {icon_path}")

    print("Zip archive bundle successfully generated.")

def run_installer():
    print("Installing system imaging dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    build_zip_package()

if __name__ == "__main__":
    run_installer()
