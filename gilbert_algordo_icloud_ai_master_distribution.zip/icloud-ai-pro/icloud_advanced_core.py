import os
import json
import asyncio
import hashlib
from pathlib import Path
from datetime import datetime

class AdvancedICloudAICore:
    def __init__(self, vault_path="./icloud_ai_vault"):
        self.vault_path = Path(vault_path)
        self.vault_path.mkdir(parents=True, exist_ok=True)
        self.index_path = self.vault_path / "metadata_index.json"
        self._init_index()

    def _init_index(self):
        if not self.index_path.exists():
            self.index_path.write_text(json.dumps({}, indent=4))

    async def smart_sync(self, file_path: str):
        path = Path(file_path)
        if not path.exists():
            return {"status": "error", "message": "Source file not found."}
        
        content = path.read_bytes()
        file_hash = hashlib.sha256(content).hexdigest()
        
        metadata = {
            "filename": path.name,
            "size_bytes": len(content),
            "hash": file_hash,
            "timestamp": datetime.now().isoformat(),
            "ai_classification": self._classify_content(path.name),
            "priority": "high" if path.suffix in [".env", ".json", ".py", ".ts"] else "normal"
        }

        dest = self.vault_path / path.name
        dest.write_bytes(content)

        index_data = json.loads(self.index_path.read_text())
        index_data[path.name] = metadata
        self.index_path.write_text(json.dumps(index_data, indent=4))

        return {"status": "success", "metadata": metadata}

    def _classify_content(self, filename: str) -> str:
        if filename.endswith((".py", ".js", ".ts", ".cpp", ".rs")):
            return "developer-source-code"
        elif filename.endswith((".jpg", ".png", ".webp", ".mp4")):
            return "multimedia-asset"
        return "secure-document"
