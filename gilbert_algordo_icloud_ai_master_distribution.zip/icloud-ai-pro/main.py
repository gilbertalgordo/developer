import sys
import asyncio
from icloud_advanced_core import AdvancedICloudAICore

async def main():
    core = AdvancedICloudAICore()
    if len(sys.argv) > 1:
        target = sys.argv[1]
        res = await core.smart_sync(target)
        print(res)
    else:
        print("Usage: python main.py <file_path_to_sync>")

if __name__ == "__main__":
    asyncio.run(main())
