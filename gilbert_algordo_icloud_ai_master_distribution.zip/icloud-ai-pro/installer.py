import os
import sys
import zipfile
import subprocess
from pathlib import Path

PROJECT_FILES = [
    "icloud_advanced_core.py",
    "main.py",
    "requirements.txt"
]

def build_zip_package():
    zip_name = "gilbert_algordo_icloud_ai_pro.zip"
    print(f"Packaging advanced distribution into {zip_name}...")
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in PROJECT_FILES:
            if Path(file).exists():
                zipf.write(file)
                print(f"Packed: {file}")
    print("Zip bundle successfully generated.")

def run_installer():
    print("Initializing environment and dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    build_zip_package()

if __name__ == "__main__":
    run_installer()
