# setup_honeycomb.py
# Python SDK Installer & TorchScript Mobile Exporter for Mobile3DTransformer
from setuptools import setup, find_packages

setup(
    name="honeycomb-spatial-ai",
    version="3.0.0",
    description="Android 3.0 Honeycomb 3D Vision Transformer & Holographic HUD SDK",
    packages=find_packages(),
    install_requires=[
        "torch>=2.1.0",
        "pyyaml>=6.0",
    ],
    python_requires=">=3.9",
)
