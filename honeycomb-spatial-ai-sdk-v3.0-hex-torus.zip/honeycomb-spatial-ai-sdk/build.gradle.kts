// build.gradle.kts
// Kotlin Multiplatform + Jetpack Compose + iOS MetalKit Root Build Configuration
plugins {
    kotlin("multiplatform") version "2.0.20" apply false
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.compose") version "1.7.0" apply false
}

allprojects {
    group = "com.honeycomb.spatial.ai"
    version = "3.0.0-full-expansion"
}
