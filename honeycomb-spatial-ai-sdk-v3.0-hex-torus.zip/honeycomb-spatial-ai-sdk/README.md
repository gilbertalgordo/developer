# Honeycomb Spatial AI SDK (v3.0 Full Expansion)

Interactive 3D Vision Transformer (`Mobile3DTransformer`), Kotlin Multiplatform `PatchEmbedder`, Android Jetpack Compose + GLSL/Vulkan Holographic HUD, and iOS SwiftUI + MetalKit 3D Raymarcher package.

## Quick Install

```bash
chmod +x install_honeycomb_sdk.sh
./install_honeycomb_sdk.sh
pip install -e .
```

## Calibrated Architecture Parameters
- **3D Scene Preset**: Honeycomb Toroidal Core
- **Input 5D Voxel Tensor**: `[1, 3, 12, 32, 32]`
- **Post-Conv3d Sequence Tokens**: `1125` tokens (`d_model = 64`, `heads = 8`)
- **Stacked Encoder Layers**: `4` layers (`dim_feedforward = 256`)
- **Estimated Mobile NPU Latency**: `18.02 ms`
