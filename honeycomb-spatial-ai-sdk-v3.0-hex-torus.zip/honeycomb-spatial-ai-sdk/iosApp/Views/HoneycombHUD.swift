// Auto-Fixed iosApp/Views/HoneycombHUD.swift
import SwiftUI
import MetalKit

// AUTO-FIX: Provide concrete HexGridLayer Canvas for Metal-backed SwiftUI rendering
struct HexGridLayer: View {
    var body: some View {
        Canvas { context, size in
            let r: CGFloat = 48.0
            let dx = r * 0.8660254
            let dy = r * 0.5
            let cx = size.width * 0.5
            let cy = size.height * 0.5
            var path = Path()
            path.move(to: CGPoint(x: cx, y: cy - r))
            path.addLine(to: CGPoint(x: cx + dx, y: cy - dy))
            path.addLine(to: CGPoint(x: cx + dx, y: cy + dy))
            path.addLine(to: CGPoint(x: cx, y: cy + r))
            path.addLine(to: CGPoint(x: cx - dx, y: cy + dy))
            path.addLine(to: CGPoint(x: cx - dx, y: cy - dy))
            path.closeSubpath()
            context.stroke(
                path,
                with: .color(Color(red: 0.00, green: 0.60, blue: 0.80)),
                style: StrokeStyle(lineWidth: 2.0, dash: [10.0, 10.0])
            )
        }
    }
}

struct HoneycombHUD: View {
    var body: some View {
        ZStack {
            HexGridLayer()
                .opacity(0.4)
                .blendMode(.screen)
            
            VStack(spacing: 6) {
                Text("AI STATUS: ACTIVE")
                    .font(.custom("Roboto-Light", size: 14))
                    .foregroundColor(Color(red: 0.00, green: 0.60, blue: 0.80))
                Text("Tokens: 1125 · Latency: 18.0ms")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}