// Full-Expansion Apple Metal 3D Voxel Raymarcher & Hex-Grid Compute Shader
#include <metal_stdlib>
using namespace metal;

struct HoneycombUniforms {
    float time;
    float gridFreq;       // 50.0
    float scanlineSpeed;  // 5.0
    float3 baseColor;     // float3(0.00, 0.60, 0.80)
    uint flattenedTokens; // 1125
};

kernel void honeycomb3DVoxelRaymarchKernel(
    texture3d<half, access::read> voxelVolume [[texture(0)]],
    texture2d<half, access::write> outHudTexture [[texture(1)]],
    constant HoneycombUniforms &u [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint width = outHudTexture.get_width();
    uint height = outHudTexture.get_height();
    if (gid.x >= width || gid.y >= height) return;

    float2 uv = float2(gid) / float2(width, height);
    float rawGrid = sin(uv.x * u.gridFreq) * sin(uv.y * u.gridFreq);
    float grid = max(0.0f, rawGrid);
    float scanline = sin(uv.y * 100.0f + u.time * u.scanlineSpeed) * 0.1f + 0.1f;

    // 3D Raymarching across 12 depth slices
    float accumActivation = 0.0f;
    constexpr sampler volSampler(coord::normalized, address::clamp_to_edge, filter::linear);
    for (int d = 0; d < 12; d++) {
        float zSlice = float(d) / float(11);
        half4 sampleVoxel = voxelVolume.sample(volSampler, float3(uv, zSlice));
        accumActivation += float(sampleVoxel.a) / float(12);
    }

    float3 holoColor = clamp(u.baseColor * (grid + scanline + accumActivation * 0.45f), 0.0f, 1.0f);
    outHudTexture.write(half4(half3(holoColor), half(0.70)), gid);
}