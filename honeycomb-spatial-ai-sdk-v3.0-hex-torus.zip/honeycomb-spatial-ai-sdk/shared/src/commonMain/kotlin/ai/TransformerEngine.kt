// Auto-Fixed shared/src/commonMain/kotlin/ai/TransformerEngine.kt
package ai

data class PredictionResult(
    val label: String,
    val confidence: Float,
    val activeTokens: Int = 1125
)

interface TransformerAI {
    fun process3DScene(tensor: FloatArray): PredictionResult
}

// AUTO-FIX: Avoid boxing FloatArray via toList() and pad tail chunk to exact stride
class PatchEmbedder(val patchSize: Int = 16) {
    private val chunkFloats: Int = patchSize * patchSize * 3 // 768 floats

    fun embed(data: FloatArray): List<FloatArray> {
        if (data.isEmpty()) return emptyList()
        val totalChunks = (data.size + chunkFloats - 1) / chunkFloats
        return List(totalChunks) { idx ->
            val start = idx * chunkFloats
            val end = minOf(start + chunkFloats, data.size)
            val slice = data.copyOfRange(start, end)
            if (slice.size < chunkFloats) slice.copyOf(chunkFloats) else slice
        }
    }
}