# Auto-Fixed & Full-Expansion 3D Transformer Block (PyTorch/Mobile-ready)
import torch
import torch.nn as nn

class Mobile3DTransformer(nn.Module):
    def __init__(self, depth=12, spatial_res=32, heads=8, num_layers=4, dropout=0.1):
        super().__init__()
        self.patch_embed = nn.Conv3d(3, 64, kernel_size=(3, 3, 3), stride=2)
        # FULL EXPANSION: Parallel dilated 3D receptive field pyramid
        self.dilated_embed = nn.Conv3d(3, 64, kernel_size=(3, 3, 3), stride=2, padding=1, dilation=2)
        
        # AUTO-FIX 1: Align 3D Positional Encoding with post-Conv3d(k=3, s=2) sequence tokens
        out_d = (depth - 3) // 2 + 1          # 5
        out_s = (spatial_res - 3) // 2 + 1    # 15
        seq_len = out_d * (out_s ** 2)        # 1125 tokens
        self.pos_encoding = nn.Parameter(torch.zeros(1, seq_len, 64))
        
        # AUTO-FIX 2 & FULL EXPANSION: 4-layer TransformerEncoder stack (256 MLP width)
        self.encoder_layer = nn.TransformerEncoderLayer(
            d_model=64,
            nhead=heads,
            dim_feedforward=256,
            dropout=dropout,
            batch_first=True
        )
        self.encoder_stack = nn.TransformerEncoder(self.encoder_layer, num_layers=num_layers)

    def forward(self, x):
        # x shape: (Batch, Channels=3, Depth=12, Height=32, Width=32)
        x = self.patch_embed(x)                # -> (Batch, 64, 5, 15, 15)
        x = x.flatten(2).transpose(1, 2)       # -> (Batch, 1125, 64)
        x = x + self.pos_encoding              # Inject 3D spatial positional awareness
        return self.encoder_stack(x)