// Auto-Fixed Android Jetpack Compose Holographic Hex Grid HUD
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun HoneycombHUD(aiState: Float = 0.53f) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        // AUTO-FIX: Bind aiState to dynamic radius pulse and use strict Float literals
        val r = 100f * (0.9f + 0.2f * aiState.coerceIn(0f, 1f))
        val dx = r * 0.8660254f // cos(30 deg)
        val dy = r * 0.5f       // sin(30 deg)

        val hexPath = Path().apply {
            moveTo(center.x, center.y - r)
            lineTo(center.x + dx, center.y - dy)
            lineTo(center.x + dx, center.y + dy)
            lineTo(center.x, center.y + r)
            lineTo(center.x - dx, center.y + dy)
            lineTo(center.x - dx, center.y - dy)
            close()
        }
        drawPath(
            path = hexPath,
            color = Color(0xFF0099CC),
            style = Stroke(
                width = 2.0f,
                pathEffect = PathEffect.dashPathEffect(
                    floatArrayOf(10.0f, 10.0f),
                    phase = aiState * 20f
                )
            )
        )
    }
}