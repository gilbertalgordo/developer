// Auto-Fixed hud_hologram.frag
precision highp float;
varying vec2 vTexCoord;
uniform float uTime;

void main() {
    // Honeycomb Electric Blue: #0099CC
    vec3 baseColor = vec3(0.00, 0.60, 0.80);
    // AUTO-FIX: Clamp negative sin() half-cycles to prevent black-clipping under screen blend
    float rawGrid = sin(vTexCoord.x * 50.0) * sin(vTexCoord.y * 50.0);
    float grid = max(0.0, rawGrid);
    float scanline = sin(vTexCoord.y * 100.0 + uTime * 5.0) * 0.1 + 0.1;
    
    vec3 finalColor = clamp(baseColor * (grid + scanline), 0.0, 1.0);
    gl_FragColor = vec4(finalColor, 0.70);
}