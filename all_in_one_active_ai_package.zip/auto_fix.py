#!/usr/bin/env python3
"""
Active AI Bridge Auto-Fix & Diagnostics Utility (Python)
Automated repair for Cloudflare Access Gateway & Android Developer Bridge.
"""
import sys
import os
import urllib.request
import json

def check_subsystems():
    print("[*] Running Active AI Python Diagnostic Suite...")
    issues_repaired = 0

    # 1. Check cf_team.yaml
    if not os.path.exists("cf_team.yaml"):
        print("[!] cf_team.yaml missing. Restoring from upstream...")
        try:
            url = "https://raw.githubusercontent.com/gilbertalgordo/developer/main/cf_team.yaml"
            urllib.request.urlretrieve(url, "cf_team.yaml")
            print("[✓] Successfully restored cf_team.yaml")
            issues_repaired += 1
        except Exception as e:
            print(f"[x] Could not download cf_team.yaml: {e}")
    else:
        print("[✓] cf_team.yaml exists and is active")

    # 2. Check TLS Gateway
    try:
        req = urllib.request.Request("https://androiddev.cloudflareaccess.com/cdn-cgi/access/certs", headers={"User-Agent": "ActiveAI-AutoFix/2.1"})
        with urllib.request.urlopen(req, timeout=5) as res:
            print(f"[✓] Cloudflare Access certs endpoint reachable (HTTP {res.status})")
    except Exception as e:
        print(f"[!] Gateway check: {e}")

    # 3. Check GitHub upstream
    try:
        req = urllib.request.Request("https://api.github.com/repos/gilbertalgordo/developer/commits/main", headers={"User-Agent": "ActiveAI-AutoFix/2.1"})
        with urllib.request.urlopen(req, timeout=5) as res:
            data = json.loads(res.read().decode())
            print(f"[✓] Upstream Git commit verified: {data.get('sha')[:12]}")
    except Exception as e:
        print(f"[!] GitHub API rate limit or offline check: {e}")

    print(f"[*] Diagnostics finished. Repaired issues: {issues_repaired}. System operational.")

if __name__ == "__main__":
    check_subsystems()
