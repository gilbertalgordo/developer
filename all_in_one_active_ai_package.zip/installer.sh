#!/bin/bash
set -e

echo "[*] Setting up Active AI Environment for androiddev.cloudflareaccess.com..."

# Create workspace directories
mkdir -p active_ai_project/app/src/main/res/xml
mkdir -p active_ai_project/backend

# Move configuration files into place
mv active_ai_service.py active_ai_project/backend/ 2>/dev/null || cp backend/active_ai_service.py active_ai_project/backend/ 2>/dev/null || true
mv AndroidManifest.xml active_ai_project/app/src/main/ 2>/dev/null || cp AndroidManifest.xml active_ai_project/app/src/main/ 2>/dev/null || true

# Build archive bundle
echo "[*] Compressing project directory into zip distribution..."
zip -r active_ai_bundle.zip active_ai_project/

echo "[+] Installation complete! Package generated: active_ai_bundle.zip"
