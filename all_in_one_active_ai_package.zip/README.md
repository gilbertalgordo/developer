# Active AI Bundle for androiddev.cloudflareaccess.com

This package contains the active AI visual asset, Android bridge, and backend gateway setup for secure deployment behind Cloudflare Access.

## System Architecture
- **Gateway Domain**: `androiddev.cloudflareaccess.com`
- **Zero Trust JWT Assertion**: `Cf-Access-Jwt-Assertion`
- **JWKS Certs Endpoint**: `https://androiddev.cloudflareaccess.com/cdn-cgi/access/certs`
- **Android Package**: `com.androiddev.activeai`

## Setup Instructions
1. Extract this archive into your development workspace.
2. Ensure your Cloudflare Access JWT validation headers are configured for `androiddev.cloudflareaccess.com`.
3. In Android Studio, copy `app/src/main/res/` to replace your launcher mipmap icons.
4. Reference the gateway URL in your Android OkHttp or Retrofit client.
