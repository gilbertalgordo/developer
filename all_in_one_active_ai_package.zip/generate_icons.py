import os
import zipfile
import shutil
from PIL import Image, ImageDraw, ImageFont

# Define icon resolutions for Android mipmap directories
DPI_RESOLUTIONS = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192
}

def generate_icon(size):
    """Generates a futuristic, glowing HUD-style AI icon for Cloudflare Access."""
    img = Image.new("RGBA", (size, size), (10, 15, 25, 255))
    draw = ImageDraw.Draw(img)
    
    # Outer geometric HUD border
    margin = int(size * 0.1)
    draw.rectangle(
        [margin, margin, size - margin, size - margin],
        outline=(255, 102, 0, 255), # Cloudflare Orange accent
        width=max(2, size // 32)
    )
    
    # Central AI Core element
    center = size // 2
    radius = int(size * 0.22)
    draw.ellipse(
        [center - radius, center - radius, center + radius, center + radius],
        fill=(0, 204, 255, 200), # Cyber Blue active AI glow
        outline=(255, 255, 255, 255),
        width=max(1, size // 64)
    )
    
    # Inner tech nodes
    node_r = max(2, size // 25)
    draw.ellipse([center - node_r, center - node_r, center + node_r, center + node_r], fill=(255, 255, 255, 255))
    
    return img

def build_package():
    base_dir = "icon_distribution_project"
    res_dir = f"{base_dir}/app/src/main/res"
    
    print("[*] Generating Android Mipmap Icons for androiddev.cloudflareaccess.com...")
    for folder, size in DPI_RESOLUTIONS.items():
        folder_path = f"{res_dir}/{folder}"
        os.makedirs(folder_path, exist_ok=True)
        
        # Launcher icon
        icon = generate_icon(size)
        icon.save(f"{folder_path}/ic_launcher.png", "PNG")
        
        # Round launcher icon variant
        round_icon = generate_icon(size)
        round_icon.save(f"{folder_path}/ic_launcher_round.png", "PNG")

    # Generate Vector Drawable XML asset
    xml_dir = f"{res_dir}/drawable"
    os.makedirs(xml_dir, exist_ok=True)
    vector_xml = """<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#FF6600"
        android:pathData="M24,24h60v60h-60z"/>
    <path
        android:fillColor="#00CCFF"
        android:pathData="M54,34c11.046,0 20,8.954 20,20s-8.954,20 -20,20s-20,-8.954 -20,-20s8.954,-20 20,-20z"/>
</vector>
"""
    with open(f"{xml_dir}/ic_launcher_background.xml", "w") as f:
        f.write(vector_xml)

    # Compress into distribution zip
    zip_name = "active_ai_icons_bundle.zip"
    shutil.make_archive(zip_name.replace('.zip', ''), 'zip', base_dir)
    print(f"[+] Distribution package successfully compiled: {zip_name}")

if __name__ == "__main__":
    build_package()
