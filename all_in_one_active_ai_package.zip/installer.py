import os
import zipfile
import shutil

def build_distribution():
    project_dir = "advanced_active_ai_distribution"
    os.makedirs(f"{project_dir}/backend", exist_ok=True)
    os.makedirs(f"{project_dir}/android/app/src/main/res/xml", exist_ok=True)

    # Write backend engine
    with open(f"{project_dir}/backend/main.py", "w") as f:
        f.write("# Advanced Cloudflare Access AI Backend Service\n")

    # Write manifest placeholder
    with open(f"{project_dir}/android/app/src/main/AndroidManifest.xml", "w") as f:
        f.write("<manifest package='com.androiddev.activeai.advanced'/>\n")

    # Generate zip archive
    zip_filename = "advanced_active_ai_bundle.zip"
    shutil.make_archive(zip_filename.replace('.zip', ''), 'zip', project_dir)
    print(f"[+] Distribution archive compiled successfully: {zip_filename}")

if __name__ == "__main__":
    build_distribution()
