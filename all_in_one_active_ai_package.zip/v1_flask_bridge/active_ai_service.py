#!/usr/bin/env python3
"""
Active AI Bridge Service (v1)
Designed for Cloudflare Access Zero Trust: androiddev.cloudflareaccess.com
"""
import os
import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

CF_ACCESS_DOMAIN = os.getenv("CF_ACCESS_DOMAIN", "androiddev.cloudflareaccess.com")
AUD_TAG = os.getenv("CF_AUD_TAG", "your_app_audience_tag")

def verify_cloudflare_jwt(headers):
    """Validates Cloudflare Access token headers for secure tunnel routing."""
    jwt_assertion = headers.get("Cf-Access-Jwt-Assertion")
    if not jwt_assertion and os.getenv("ENVIRONMENT") == "production":
        return False
    # In production, integrate JWKS verification against https://<CF_ACCESS_DOMAIN>/cdn-cgi/access/certs
    return True

@app.route("/api/v1/active-ai", methods=["POST"])
def active_ai_endpoint():
    if not verify_cloudflare_jwt(request.headers):
        return jsonify({"error": "Unauthorized via Cloudflare Access"}), 403

    data = request.json or {}
    prompt = data.get("prompt", "")
    
    # Forward prompt logic to active AI processing node
    ai_response = {
        "status": "success",
        "gateway": CF_ACCESS_DOMAIN,
        "processed_prompt": prompt,
        "inference": f"Active AI processed output for Android Dev environment: {prompt[::-1]}"
    }
    return jsonify(ai_response)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
