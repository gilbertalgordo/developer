#!/usr/bin/env bash
# ==============================================================================
# Active AI Continuous Auto-Update Daemon
# Target Domain: androiddev.cloudflareaccess.com
# Repository: https://github.com/gilbertalgordo/developer
# ==============================================================================
set -euo pipefail

REPO="gilbertalgordo/developer"
BRANCH="main"
TARGET_FILE="cf_team.yaml"
POLL_INTERVAL=30
STATE_DIR=".active_ai_state"
CACHE_FILE="$STATE_DIR/last_commit.sha"
REMOTE_API="https://api.github.com/repos/$REPO/commits/$BRANCH"
RAW_URL="https://raw.githubusercontent.com/$REPO/$BRANCH/$TARGET_FILE"

mkdir -p "$STATE_DIR"
touch "$CACHE_FILE"

echo "========================================================================"
echo "[+] Active AI Bridge Auto-Updater initialized"
echo "[+] Target Gateway: androiddev.cloudflareaccess.com"
echo "[+] Tracking Upstream: $REPO ($BRANCH)"
echo "[+] Check Interval: ${POLL_INTERVAL}s"
echo "========================================================================"

while true; do
  TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  echo "[$TIMESTAMP] Checking for upstream updates..."

  # Query latest commit hash from GitHub
  LATEST_SHA=$(curl -sL -H "Accept: application/vnd.github.v3+json" "$REMOTE_API" 2>/dev/null | grep -m 1 '"sha":' | cut -d '"' -f 4 || true)

  if [ -z "$LATEST_SHA" ]; then
    echo "[-] Warning: Unable to resolve GitHub API. Falling back to HTTP ETag..."
    LATEST_SHA=$(curl -sI "$RAW_URL" | grep -i 'etag:' | tr -d '\r\n' || true)
  fi

  CURRENT_SHA=$(cat "$CACHE_FILE" 2>/dev/null || echo "")

  if [ "$LATEST_SHA" != "$CURRENT_SHA" ] && [ -n "$LATEST_SHA" ]; then
    echo "[!] New update detected: $CURRENT_SHA -> $LATEST_SHA"
    echo "[*] Downloading latest $TARGET_FILE..."
    curl -sL "$RAW_URL" -o "$TARGET_FILE"

    echo "[*] Regenerating local distribution packages and bundle zips..."
    if [ -f "installer.sh" ]; then
      bash installer.sh || true
    fi

    # Record updated commit SHA
    echo "$LATEST_SHA" > "$CACHE_FILE"
    echo "[+] Auto-update applied successfully at $(date)!"

    # Signal daemon reload if running under systemd or supervisor
    if systemctl is-active --quiet active-ai-bridge 2>/dev/null; then
      echo "[*] Reloading active-ai-bridge system service..."
      systemctl restart active-ai-bridge
    fi
  else
    echo "[$TIMESTAMP] System in sync. No new updates."
  fi

  sleep "$POLL_INTERVAL"
done
