#!/usr/bin/env bash
echo "Setting up mTLS certificate for Android Zero Trust client..."
