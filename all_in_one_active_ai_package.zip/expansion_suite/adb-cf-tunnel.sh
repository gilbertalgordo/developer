#!/usr/bin/env bash
cloudflared access tcp --hostname adb.androiddev.cloudflareaccess.com --url localhost:5555 &
adb connect localhost:5555
