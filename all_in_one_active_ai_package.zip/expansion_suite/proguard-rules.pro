# Active AI Expansion - Enterprise R8 / ProGuard Configuration
-keep class com.activeai.models.** { *; }
-keep class com.activeai.network.ZeroTrustAutoConnectInterceptor { *; }
-keep class com.google.ai.client.generativeai.** { *; }
-repackageclasses 'com.activeai.obf'
-optimizationpasses 5
