package com.androiddev.activeai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Active AI In-App Auto-Update Manager
 * Automatically checks and delivers OTA updates for com.androiddev.activeai
 * Gateway: androiddev.cloudflareaccess.com
 */
class ActiveAiUpdateManager(private val context: Context) {

    companion object {
        private const val TAG = "ActiveAiUpdate"
        private const val CURRENT_VERSION_CODE = 210
        private const val UPDATE_ENDPOINT = "https://androiddev.cloudflareaccess.com/api/v1/app-update/check?version_code=$CURRENT_VERSION_CODE"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    interface UpdateCallback {
        fun onUpdateAvailable(
            latestVersionName: String,
            latestVersionCode: Int,
            releaseNotes: String,
            downloadUrl: String,
            isMandatory: Boolean
        )
        fun onUpToDate()
        fun onError(error: String)
    }

    fun checkForUpdates(callback: UpdateCallback) {
        val request = Request.Builder()
            .url(UPDATE_ENDPOINT)
            .addHeader("User-Agent", "ActiveAiAndroid/$CURRENT_VERSION_CODE")
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                Log.e(TAG, "Update check failed: ${e.message}")
                Handler(Looper.getMainLooper()).post {
                    callback.onError(e.message ?: "Network timeout checking updates")
                }
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val body = response.body?.string()
                if (response.isSuccessful && body != null) {
                    try {
                        val json = JSONObject(body)
                        val updateAvailable = json.optBoolean("update_available", false)
                        val latestCode = json.optInt("latest_version_code", CURRENT_VERSION_CODE)
                        val latestName = json.optString("latest_version_name", "2.1.0")
                        val notes = json.optString("release_notes", "Bug fixes and performance improvements")
                        val downloadUrl = json.optString("download_url", "")
                        val isMandatory = json.optBoolean("mandatory_update", false)

                        Handler(Looper.getMainLooper()).post {
                            if (updateAvailable && latestCode > CURRENT_VERSION_CODE) {
                                callback.onUpdateAvailable(latestName, latestCode, notes, downloadUrl, isMandatory)
                            } else {
                                callback.onUpToDate()
                            }
                        }
                    } catch (e: Exception) {
                        Handler(Looper.getMainLooper()).post { callback.onError(e.message ?: "JSON parse error") }
                    }
                }
            }
        })
    }

    fun triggerApkDownload(downloadUrl: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
