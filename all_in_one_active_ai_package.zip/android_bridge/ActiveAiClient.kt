package com.androiddev.activeai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ActiveAiClient(
    private val cfDomain: String = "androiddev.cloudflareaccess.com",
    private val jwtToken: String? = null
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun executeInference(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val jsonBody = JSONObject().apply {
                put("prompt", prompt)
            }.toString()

            val requestBuilder = Request.Builder()
                .url("https://$cfDomain/api/v1/active-ai")
                .post(jsonBody.toRequestBody(jsonType))
                .addHeader("Content-Type", "application/json")

            // Attach Cloudflare Access Zero Trust assertion if present
            jwtToken?.let {
                requestBuilder.addHeader("Cf-Access-Jwt-Assertion", it)
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: $responseBody"))
            }

            val jsonRes = JSONObject(responseBody)
            val inference = jsonRes.optString("inference", jsonRes.optString("result", "No output"))
            Result.success(inference)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
