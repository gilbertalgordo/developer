#!/usr/bin/env python3
"""
Active AI Continuous Auto-Sync Daemon (Python 3)
Domain: androiddev.cloudflareaccess.com
Monitors GitHub repository changes and synchronizes configuration.
"""
import time
import json
import urllib.request
import os
import subprocess

REPO = "gilbertalgordo/developer"
BRANCH = "main"
API_URL = f"https://api.github.com/repos/{REPO}/commits/{BRANCH}"
RAW_URL = f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/cf_team.yaml"
POLL_INTERVAL_SECONDS = 30
CACHE_PATH = ".active_ai_last_sha"

def get_latest_commit():
    try:
        req = urllib.request.Request(API_URL, headers={"User-Agent": "ActiveAi-AutoUpdater/2.1"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("sha")
    except Exception as e:
        print(f"[-] GitHub API error: {e}, attempting raw head check...")
        try:
            with urllib.request.urlopen(RAW_URL, timeout=10) as resp:
                return resp.headers.get("ETag", "synced")
        except Exception as e2:
            print(f"[-] Fallback error: {e2}")
            return None

def apply_update(new_sha):
    print(f"[*] Fetching updated configuration for {new_sha}...")
    urllib.request.urlretrieve(RAW_URL, "cf_team.yaml")
    
    # Re-run local installer to update all zip distribution bundles
    if os.path.exists("installer.py"):
        print("[*] Running installer.py to recompile distribution bundles...")
        subprocess.run(["python3", "installer.py"], check=False)
        
    with open(CACHE_PATH, "w") as f:
        f.write(new_sha)
    print(f"[+] Successfully auto-updated to commit {new_sha}!")

def main():
    print(f"[+] Active AI Auto-Update Engine active. Monitoring {REPO}...")
    last_sha = ""
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, "r") as f:
            last_sha = f.read().strip()
            
    while True:
        sha = get_latest_commit()
        if sha and sha != last_sha:
            print(f"[!] Update found: {last_sha[:7]} -> {sha[:7]}")
            apply_update(sha)
            last_sha = sha
        else:
            print(f"[*] In sync with upstream ({sha[:7] if sha else 'ok'}). Sleeping {POLL_INTERVAL_SECONDS}s...")
        time.sleep(POLL_INTERVAL_SECONDS)

if __name__ == "__main__":
    main()
