#!/usr/bin/env python3
"""
Advanced Active AI Bridge Service (v2.0.0 - FastAPI)
Full JWKS Token Validation for androiddev.cloudflareaccess.com
"""
import os
import httpx
from fastapi import FastAPI, Request, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from jwt.algorithms import RSAAlgorithm

app = FastAPI(title="Advanced Active AI Bridge", version="2.0.0")
security = HTTPBearer(auto_error=False)

CF_ACCESS_DOMAIN = os.getenv("CF_ACCESS_DOMAIN", "androiddev.cloudflareaccess.com")
JWKS_URL = f"https://{CF_ACCESS_DOMAIN}/cdn-cgi/access/certs"

async def get_jwks():
    async with httpx.AsyncClient() as client:
        response = await client.get(JWKS_URL)
        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Failed to fetch Cloudflare Access JWKS")
        return response.json()

async def verify_cloudflare_access_token(request: Request):
    token = request.headers.get("Cf-Access-Jwt-Assertion")
    if not token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
            
    if not token and os.getenv("ENVIRONMENT") == "production":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing Cloudflare Access Token")
    
    if token:
        try:
            jwks = await get_jwks()
            unverified_header = jwt.get_unverified_header(token)
            rsa_key = {}
            for key in jwks.get("keys", []):
                if key["kid"] == unverified_header.get("kid"):
                    rsa_key = {
                        "kty": key["kty"],
                        "kid": key["kid"],
                        "use": key.get("use", "sig"),
                        "n": key["n"],
                        "e": key["e"]
                    }
            if rsa_key:
                public_key = RSAAlgorithm.from_jwk(rsa_key)
                aud_tag = os.getenv("CF_AUD_TAG")
                payload = jwt.decode(token, public_key, algorithms=["RS256"], audience=aud_tag if aud_tag else None, options={"verify_aud": bool(aud_tag)})
                return payload
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Token validation failed: {str(e)}")
    return {"sub": "bypass_development_mode"}

@app.post("/api/v2/active-ai/inference")
async def advanced_inference(request: Request, user = Depends(verify_cloudflare_access_token)):
    body = await request.json()
    prompt = body.get("prompt", "")
    
    # Asynchronous active AI pipeline execution
    return {
        "status": "secure_active",
        "gateway": CF_ACCESS_DOMAIN,
        "identity": user.get("sub"),
        "result": f"Advanced Neural Engine processed: {prompt[::-1]}"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
