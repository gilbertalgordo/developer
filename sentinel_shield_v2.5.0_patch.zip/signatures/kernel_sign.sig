/* Binary payload representation for signatures/kernel_sign.sig (1 KB) */
/* Target: Gilbert OS Sandbox Container */
0x7f 0x45 0x4c 0x46
