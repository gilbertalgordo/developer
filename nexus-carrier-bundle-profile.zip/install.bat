@echo off
REM ==============================================================================
REM Google Virtual SIMs (GSMA SGP.22) Automated Profile Installer for Windows
REM ==============================================================================

set "LPA_CODE=LPA:1$vsim-core.nexus-network.io$NEXUS-GLB-9988-ALPHA"
set "SMDP_FQDN=vsim-core.nexus-network.io"
set "MATCHING_ID=NEXUS-GLB-9988-ALPHA"

echo ============================================================
echo   Google Nexus Virtual SIM Installer (GSMA SGP.22 RSP v3.0)
echo ============================================================
echo LPA Code: %LPA_CODE%
echo SM-DP+:   %SMDP_FQDN%
echo Matching: %MATCHING_ID%
echo ------------------------------------------------------------

where adb >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [+] Android device detected over ADB.
    echo [+] Broadcasting EuiccManager download intent...
    adb shell am start -a android.telephony.euicc.action.DOWNLOAD_SUBSCRIPTION -e android.telephony.euicc.extra.EMBEDDED_SUBSCRIPTION_DOWNLOAD_CODE "%LPA_CODE%" --ez android.telephony.euicc.extra.FORCE_DISABLE_CONFIRMATION_DIALOG true
    echo [OK] Intent dispatched to device.
) else (
    echo [i] ADB not in PATH. Please copy the LPA activation code:
    echo     %LPA_CODE%
    echo     Paste into Windows Settings -> Network -> Cellular -> Add eSIM.
)
pause