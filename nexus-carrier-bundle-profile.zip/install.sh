#!/usr/bin/env bash
# ==============================================================================
# Google Virtual SIMs (GSMA SGP.22) Automated Profile Installer
# Target: Android (via ADB EuiccManager) / Linux ModemManager (via mmcli)
# ==============================================================================

set -e

LPA_CODE="LPA:1$vsim-core.nexus-network.io$NEXUS-GLB-9988-ALPHA"
SMDP_FQDN="vsim-core.nexus-network.io"
MATCHING_ID="NEXUS-GLB-9988-ALPHA"
ICCID="89012608899887766554"

echo "============================================================"
echo "  Google Nexus Virtual SIM Installer (GSMA SGP.22 RSP v3.0)"
echo "============================================================"
echo "LPA Activation Code: $LPA_CODE"
echo "SM-DP+ Address:      $SMDP_FQDN"
echo "Matching ID:         $MATCHING_ID"
echo "Assigned ICCID:      $ICCID"
echo "------------------------------------------------------------"

if command -v adb &>/dev/null && adb get-state &>/dev/null; then
    echo "[+] Android device detected over ADB:"
    adb devices -l
    echo "[+] Broadcasting EuiccManager download intent..."
    adb shell am start \
      -a android.telephony.euicc.action.DOWNLOAD_SUBSCRIPTION \
      -e android.telephony.euicc.extra.EMBEDDED_SUBSCRIPTION_DOWNLOAD_CODE "$LPA_CODE" \
      --ez android.telephony.euicc.extra.FORCE_DISABLE_CONFIRMATION_DIALOG true
    echo "[✓] eSIM Download Subscription intent dispatched to Android EuiccManager."
elif command -v mmcli &>/dev/null; then
    echo "[+] Linux ModemManager detected. Inspecting modems..."
    MODEM_INDEX=$(mmcli -L | grep -o '/Modem/[0-9]*' | head -n 1 | cut -d'/' -f3)
    if [ -n "$MODEM_INDEX" ]; then
        echo "[+] Found Modem index: $MODEM_INDEX. Attempting eUICC carrier activation..."
        mmcli -m "$MODEM_INDEX" --simple-connect="apn=nexus.core.5g,ip-type=ipv4v6"
        echo "[✓] Connected via ModemManager."
    fi
else
    echo "[i] For Apple iOS or Android (Manual):"
    echo "    1. Open Settings -> Cellular / Network & Internet -> Add eSIM"
    echo "    2. Select 'Use Activation Code'"
    echo "    3. Paste or enter: $LPA_CODE"
fi

echo "============================================================"
echo "Installation process initiated."