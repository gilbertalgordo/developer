# Google Virtual SIMs Carrier Bundle Package
## GSMA SGP.22 RSP v3.0 / 3GPP Rel 17 5G Standalone Profile

This carrier deployment bundle contains all cryptographic assets, network policies, and installation scripts for deploying **Google Nexus Mobile** virtual SIM leases to eUICC secure elements.

### Bundle Manifest
- `lpa_profile.json`: Standardized GSMA metadata with SM-DP+ FQDN, Matching ID, and ICCID.
- `CarrierConfig.xml`: Android CarrierConfig APN and 5G network policy settings.
- `Nexus_5G_Carrier.mobileconfig`: Apple iOS profile for instant cellular APN configuration.
- `install.sh`: POSIX shell script for automated ADB flash and Linux ModemManager setup.
- `install.bat`: Windows automated ADB flash utility.
- `milenage_auth_vectors.json`: 3GPP TS 35.206 MILENAGE subscriber authentication parameters.

### Quick Installation Instructions
#### Android:
Run `./install.sh` with device connected via ADB, or scan QR code.

#### Apple iOS:
Open `Nexus_5G_Carrier.mobileconfig` or add eSIM via iOS Settings.