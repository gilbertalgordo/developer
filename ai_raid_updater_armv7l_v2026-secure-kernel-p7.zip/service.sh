#!/system/bin/sh
# Magisk / KernelSU background service launch
MODDIR=${0%/*}
nohup /system/bin/raid_updater_daemon >/dev/null 2>&1 &
