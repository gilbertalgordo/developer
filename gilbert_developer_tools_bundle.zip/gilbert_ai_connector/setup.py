from setuptools import setup, find_packages

setup(
    name="gilbert_ai_connector",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "google-genai",
        "click"
    ],
    entry_points={
        'console_scripts': [
            'gilbert-ai=gilbert_ai.connector:main',
        ],
    },
    author="Gilbert Algordo",
    author_email="gilbert@algordo.dev",
    description="Google AI connector package built for Gilbert Algordo's developer ecosystem.",
    url="https://g.dev/gilbert_algordo",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)
