import os
import subprocess
import sys
import zipfile

def run_command(command):
    print(f"[EXECUTING] {command}")
    result = subprocess.run(command, shell=True)
    if result.returncode != 0:
        print(f"[ERROR] Command failed: {command}")
        sys.exit(1)

def create_zip_bundle():
    zip_filename = "gilbert_ai_connector.zip"
    print(f"[PACKAGING] Creating distribution zip: {zip_filename}")
    
    exclude_dirs = {'.git', '__pycache__', 'build', 'dist', '.venv', 'gilbert_ai_connector.egg-info'}
    exclude_files = {zip_filename}

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for file in files:
                if file in exclude_files:
                    continue
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, '.')
                zipf.write(filepath, arcname)
                print(f"  Added: {arcname}")
                
    print(f"[SUCCESS] Zip package created successfully: {os.path.abspath(zip_filename)}")

def main():
    print("=== Gilbert AI Connector Setup & Installer ===")
    print("Target Developer: https://g.dev/gilbert_algordo")
    
    # 1. Install local dependencies
    run_command(f"{sys.executable} -m pip install --upgrade pip")
    run_command(f"{sys.executable} -m pip install -r requirements.txt")
    
    # 2. Install package in editable/development mode
    run_command(f"{sys.executable} -m pip install -e .")
    
    # 3. Build ZIP file package
    create_zip_bundle()
    
    print("\n=== Installation & Packaging Complete ===")
    print("You can now import 'gilbert_ai' or set your GEMINI_API_KEY environment variable to start querying.")

if __name__ == "__main__":
    main()
