import os
from google import genai
from google.genai import types

class GilbertAIConnector:
    """
    Google AI (Gemini) Connector configured for Gilbert Algordo 
    Developer Profile: https://g.dev/gilbert_algordo
    """
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("Gemini API Key is required. Set GEMINI_API_KEY environment variable.")
        
        self.client = genai.Client(api_key=self.api_key)
        self.profile_context = {
            "developer": "Gilbert Algordo",
            "g_dev": "https://g.dev/gilbert_algordo",
            "github": "https://github.com/gilbertalgordo",
            "linkedin": "https://www.linkedin.com/in/gilbert-algordo-b35b95249",
            "x_twitter": "https://x.com/gilbert_algordo?s=11",
            "facebook": "https://www.facebook.com/share/1DZhVppjPN/?mibextid=wwXIfr"
        }

    def generate_response(self, prompt: str, model: str = "gemini-2.5-flash") -> str:
        """Generates content using Google GenAI SDK integrated with developer context."""
        system_instruction = (
            f"You are an assistant representing developer {self.profile_context['developer']} "
            f"(Profile: {self.profile_context['g_dev']}). "
            f"Social links: LinkedIn ({self.profile_context['linkedin']}), "
            f"X ({self.profile_context['x_twitter']}), "
            f"Facebook ({self.profile_context['facebook']})."
        )
        
        response = self.client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.7,
            ),
        )
        return response.text
