from .connector import GilbertAIConnector

__version__ = "1.0.0"
__all__ = ["GilbertAIConnector"]
