# Gilbert AI Connector (v1.0.0)

Google AI (Gemini) Connector configured for Gilbert Algordo's developer ecosystem.

## Quickstart

```bash
# 1. Run the automated installer
python installer.py

# 2. Set your Google Gemini API key
export GEMINI_API_KEY="your-gemini-api-key"

# 3. Use in Python
from gilbert_ai import GilbertAIConnector

connector = GilbertAIConnector()
reply = connector.generate_response("Explain microservices architecture")
print(reply)
```

## Developer Reference
- **Developer:** Gilbert Algordo
- **Google Developer Profile:** https://g.dev/gilbert_algordo
- **GitHub:** https://github.com/gilbertalgordo
