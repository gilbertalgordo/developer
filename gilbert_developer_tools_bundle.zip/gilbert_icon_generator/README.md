# Gilbert Icon Generator (v1.0.0)

Generates SVG & PNG technical brand icons styled with Google AI gradients and Gilbert Algordo developer identity.

## Build & Export

```bash
python installer.py
```
