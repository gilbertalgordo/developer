import os
import subprocess
import sys
import zipfile
from icons.generator import IconGenerator

def run_command(command):
    print(f"[RUNNING] {command}")
    res = subprocess.run(command, shell=True)
    if res.returncode != 0:
        print(f"[ERROR] Process failed during: {command}")
        sys.exit(1)

def package_zip():
    zip_filename = "gilbert_icon_generator.zip"
    print(f"[PACKAGE] Building deployment archive -> {zip_filename}")
    
    ignored = {'.git', '__pycache__', 'build', 'dist', '.venv', 'gilbert_icon_generator.egg-info', zip_filename}

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in ignored]
            for file in files:
                if file in ignored:
                    continue
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, '.')
                zip_ref.write(file_path, arc_name)
                print(f"  Added to archive: {arc_name}")
                
    print(f"[SUCCESS] Archive created: {os.path.abspath(zip_filename)}")

def main():
    print("=== Initializing Icon Generator Installer ===")
    print("Profile Source: https://g.dev/gilbert_algordo")
    
    # 1. Install dependencies
    run_command(f"{sys.executable} -m pip install --upgrade pip")
    run_command(f"{sys.executable} -m pip install -r requirements.txt")
    
    # 2. Run local package mount
    run_command(f"{sys.executable} -m pip install -e .")
    
    # 3. Generate initial set of custom Google AI icons
    print("\n[GENERATING] Building icon graphic assets...")
    generator = IconGenerator()
    svg_path = generator.generate_svg_icon()
    png_path = generator.generate_png_icon()
    print(f"  Generated SVG: {svg_path}")
    print(f"  Generated PNG: {png_path}")
    
    # 4. Compile ZIP file bundle
    package_zip()
    
    print("\n=== Installation, Icon Generation & Packaging Complete ===")
    print("Your zip bundle is ready: gilbert_icon_generator.zip")

if __name__ == '__main__':
    main()
