from setuptools import setup, find_packages

setup(
    name="gilbert_icon_generator",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "click",
        "pillow",
        "svgwrite"
    ],
    entry_points={
        'console_scripts': [
            'generate-icons=icons.generator:main',
        ],
    },
    author="Gilbert Algordo",
    description="Custom Google AI icon asset generator linked to g.dev/gilbert_algordo.",
    url="https://g.dev/gilbert_algordo",
    python_requires='>=3.8',
)
