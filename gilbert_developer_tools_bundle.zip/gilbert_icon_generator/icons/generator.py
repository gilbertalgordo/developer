import os
import svgwrite
from PIL import Image, ImageDraw, ImageFont

class IconGenerator:
    """
    Generates custom Google AI styled technical icons embedded with 
    Gilbert Algordo's developer ecosystem and social profiles.
    """
    def __init__(self, output_dir: str = "output_icons"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.metadata = {
            "developer": "Gilbert Algordo",
            "g_dev": "https://g.dev/gilbert_algordo",
            "linkedin": "https://www.linkedin.com/in/gilbert-algordo-b35b95249",
            "x": "https://x.com/gilbert_algordo?s=11",
            "facebook": "https://www.facebook.com/share/1DZhVppjPN/?mibextid=wwXIfr"
        }

    def generate_svg_icon(self, filename: str = "google_ai_icon.svg") -> str:
        filepath = os.path.join(self.output_dir, filename)
        dwg = svgwrite.Drawing(filepath, profile='tiny', size=('512px', '512px'))
        
        # Background gradient / base container
        defs = dwg.defs
        gradient = dwg.linearGradient(id="google_ai_grad", start=(0, 0), end=(1, 1))
        gradient.add_stop_color(0, '#4285F4')  # Google Blue
        gradient.add_stop_color(0.5, '#EA4335') # Google Red
        gradient.add_stop_color(1, '#FBBC05')  # Google Yellow
        defs.add(gradient)

        # Base rounded rect icon card
        dwg.add(dwg.rect(insert=(32, 32), size=(448, 448), rx=96, ry=96, fill='url(#google_ai_grad)', stroke='#34A853', stroke_width=8))
        
        # Inner shield/node graphics
        dwg.add(dwg.circle(center=(256, 220), r=90, fill='#FFFFFF', opacity=0.9))
        dwg.add(dwg.text("GAI", insert=(256, 235), text_anchor="middle", font_family="Arial, sans-serif", font_size="56", font_weight="bold", fill="#202124"))
        
        # Footer label branding
        dwg.add(dwg.text("GILBERT ALGORDO", insert=(256, 370), text_anchor="middle", font_family="Arial, sans-serif", font_size="22", font_weight="bold", fill="#FFFFFF"))
        
        dwg.save()
        return filepath

    def generate_png_icon(self, filename: str = "google_ai_badge.png") -> str:
        filepath = os.path.join(self.output_dir, filename)
        img = Image.new("RGBA", (512, 512), (20, 21, 24, 255))
        draw = ImageDraw.Draw(img)
        
        # Draw tech badge border and design
        draw.rounded_rectangle([32, 32, 480, 480], radius=64, fill=(66, 133, 244, 255), outline=(52, 168, 83, 255), width=6)
        draw.ellipse([160, 120, 352, 312], fill=(255, 255, 255, 255))
        
        # Save image output
        img.save(filepath, "PNG")
        return filepath
