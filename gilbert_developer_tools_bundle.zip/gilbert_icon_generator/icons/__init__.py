from .generator import IconGenerator

__version__ = "1.0.0"
__all__ = ["IconGenerator"]
