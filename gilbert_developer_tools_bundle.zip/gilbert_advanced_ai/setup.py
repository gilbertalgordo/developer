from setuptools import setup, find_packages

setup(
    name="gilbert_advanced_ai",
    version="2.0.0",
    packages=find_packages(),
    install_requires=[
        "google-genai",
        "click",
        "pydantic",
        "rich"
    ],
    entry_points={
        'console_scripts': [
            'gilbert-ai-adv=cli.main:cli',
        ],
    },
    author="Gilbert Algordo",
    description="Advanced Google AI integration package linked to g.dev/gilbert_algordo ecosystem.",
    url="https://g.dev/gilbert_algordo",
    python_requires='>=3.9',
)
