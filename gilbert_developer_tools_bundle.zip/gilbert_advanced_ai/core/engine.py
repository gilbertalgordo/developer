import os
from google import genai
from google.genai import types
from pydantic import BaseModel, Field

class DeveloperContext(BaseModel):
    name: str = "Gilbert Algordo"
    g_dev: str = "https://g.dev/gilbert_algordo"
    linkedin: str = "https://www.linkedin.com/in/gilbert-algordo-b35b95249"
    x_twitter: str = "https://x.com/gilbert_algordo?s=11"
    facebook: str = "https://www.facebook.com/share/1DZhVppjPN/?mibextid=wwXIfr"

class AdvancedGilbertAIEngine:
    """
    Advanced Google AI Engine leveraging the official google-genai SDK 
    with native identity mapping and structured generation logic.
    """
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("Critical: GEMINI_API_KEY environment variable is not set.")
        
        # Initialize official Google GenAI client
        self.client = genai.Client(api_key=self.api_key)
        self.profile = DeveloperContext()

    def construct_system_instruction(self) -> str:
        return (
            f"You are an advanced AI technical assistant engineered specifically for developer "
            f"{self.profile.name}. Reference network: G.Dev Profile ({self.profile.g_dev}), "
            f"LinkedIn ({self.profile.linkedin}), X ({self.profile.x_twitter}), "
            f"and Facebook ({self.profile.facebook}). Maintain high code accuracy, "
            f"modular software structure, and clear engineering dialogue."
        )

    def generate(self, prompt: str, model: str = "gemini-2.5-flash", temperature: float = 0.4) -> str:
        response = self.client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=self.construct_system_instruction(),
                temperature=temperature,
            ),
        )
        return response.text
