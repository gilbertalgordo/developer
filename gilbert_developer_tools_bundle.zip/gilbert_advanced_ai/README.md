# Gilbert Advanced AI Engine (v2.0.0)

Engineered for Gilbert Algordo's cloud AI infrastructure with Pydantic typing and Rich terminal visualizations.

## CLI Usage

```bash
# 1. Automated installation
python installer.py

# 2. Query Gemini via CLI
gilbert-ai-adv query --prompt "Design a high-performance system architecture blueprint."
```
