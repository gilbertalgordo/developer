import os
import subprocess
import sys
import zipfile

def run_command(command):
    print(f"[RUNNING] {command}")
    res = subprocess.run(command, shell=True)
    if res.returncode != 0:
        print(f"[ERROR] Process failed during: {command}")
        sys.exit(1)

def build_zip_package():
    zip_filename = "gilbert_advanced_ai.zip"
    print(f"[PACKAGE] Compiling archive -> {zip_filename}")
    
    ignored_dirs = {'.git', '__pycache__', 'build', 'dist', '.venv', 'gilbert_advanced_ai.egg-info'}
    ignored_files = {zip_filename}

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in ignored_dirs]
            for file in files:
                if file in ignored_files:
                    continue
                file_path = os.path.join(root, file)
                arc_name = os.path.relpath(file_path, '.')
                zip_ref.write(file_path, arc_name)
                print(f"  Added to archive: {arc_name}")
                
    print(f"[SUCCESS] Archive generated at: {os.path.abspath(zip_filename)}")

def main():
    print("=== Initializing Advanced Gilbert AI Installer ===")
    print("Developer Profile Source: https://g.dev/gilbert_algordo")
    
    # 1. Pipeline execution for dependencies
    run_command(f"{sys.executable} -m pip install --upgrade pip")
    run_command(f"{sys.executable} -m pip install -r requirements.txt")
    
    # 2. Local editable package mount
    run_command(f"{sys.executable} -m pip install -e .")
    
    # 3. Create compressed deployment bundle
    build_zip_package()
    
    print("\n=== Installation & ZIP Generation Complete ===")
    print("To execute CLI interface commands, run:")
    print("  gilbert-ai-adv query --prompt 'Your technical query here'")

if __name__ == '__main__':
    main()
