import click
from rich.console import Console
from rich.panel import Panel
from core.engine import AdvancedGilbertAIEngine

console = Console()

@click.group()
def cli():
    """Gilbert Advanced Google AI CLI Companion"""
    pass

@cli.command()
@click.option('--prompt', '-p', required=True, help="Prompt query to send to Gemini.")
@click.option('--model', '-m', default="gemini-2.5-flash", help="Gemini model version.")
def query(prompt, model):
    """Execute advanced generation linked with developer metadata."""
    try:
        engine = AdvancedGilbertAIEngine()
        console.print(Panel(f"[bold cyan]Target Model:[/bold cyan] {model}\n[bold cyan]Prompt:[/bold cyan] {prompt}", title="AI Request"))
        
        with console.status("[bold green]Synthesizing response via Google AI..."):
            result = engine.generate(prompt=prompt, model=model)
            
        console.print(Panel(result, title="[bold green]AI Response Output[/bold green]"))
    except Exception as e:
        console.print(f"[bold red]Error Execution Failed:[/bold red] {e}")

if __name__ == '__main__':
    cli()
