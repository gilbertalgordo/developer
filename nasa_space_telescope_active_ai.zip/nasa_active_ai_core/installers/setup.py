from setuptools import setup, find_packages

setup(
    name="nasa_space_telescope_active_ai",
    version="2.0.0",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.22.0",
        "scipy>=1.8.0"
    ],
    entry_points={
        "console_scripts": [
            "nasa-ai-telemetry=nasa_active_ai_core.engine.neural_telemetry:main",
        ],
    },
    author="Gilbert Algordo",
    author_email="gilbert@developer.local",
    description="Advanced Active AI system for NASA space telescopes",
    url="https://g.dev/gilbert_algordo",
)
