#!/bin/bash
set -e
echo "====================================================="
echo " Installing NASA Space Telescope Active AI Engine    "
echo " Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)"
echo "====================================================="
python3 -m pip install --upgrade pip
pip install numpy>=1.22.0 scipy>=1.8.0
echo "Installation complete. Active AI telemetry daemon ready."
