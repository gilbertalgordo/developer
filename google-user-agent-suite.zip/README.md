# Google User Agent & Client Hints Platform

A high-performance crawler testing and emulation platform featuring modern Googlebot User-Agent strings, W3C/RFC 8942 Client Hints (`Sec-CH-UA`), Chromium milestone tracking, and reverse DNS validation.

## Quick Start (Automated Installer)

### Linux / macOS:
```bash
chmod +x install.sh
./install.sh
```

### Windows:
```cmd
install.bat
```

### Docker:
```bash
docker-compose up --build -d
```

## Running the Servers

### Advanced FastAPI Service (Port 8000)
```bash
source venv/bin/activate
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

### Simple Flask Service (Port 5000)
```bash
source venv/bin/activate
python app.py
```

## API Endpoints

- `GET /api/profiles`: List all available Googlebot & Chromium crawler profiles.
- `POST /api/generate`: Generate User-Agent and Sec-CH-UA Client Hints payload.

## Distribution ZIP
To build the distribution ZIP locally using Python:
```bash
python make_zip.py
```
