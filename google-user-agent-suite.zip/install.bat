@echo off
echo ==================================================
echo  Initializing Google UA Suite Installer (Windows)
echo ==================================================

python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [Error] Python is not installed or not in your PATH.
    echo Please install Python 3.10+ from python.org and re-run.
    pause
    exit /b 1
)

echo [*] Creating isolated virtual environment...
python -m venv venv
call venv\Scripts\activate.bat

echo [*] Installing dependencies from requirements.txt...
python -m pip install --upgrade pip
pip install -r requirements.txt

echo ==================================================
echo  Installation Complete Successfully!
echo  To start the server, run:
echo  venv\Scripts\activate ^&^& uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
echo ==================================================
pause
