import os
import zipfile

def build_advanced_zip():
    zip_name = "google-ua-advanced-platform.zip"
    directories = ["backend", "frontend/templates"]
    root_files = ["requirements.txt", "install.sh"]
    
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Walk through explicit directories
        for directory in directories:
            if os.path.exists(directory):
                for root, dirs, files in os.walk(directory):
                    for file in files:
                        full_path = os.path.join(root, file)
                        zipf.write(full_path)
                        print(f"Archived directory asset: {full_path}")
            else:
                print(f"Warning: Directory {directory} missing.")
                
        # Add root configuration files
        for file in root_files:
            if os.path.exists(file):
                zipf.write(file)
                print(f"Archived root asset: {file}")
            else:
                print(f"Warning: Root asset {file} missing.")

    print(f"\n[Success] Distribution package compiled: {zip_name}")

if __name__ == "__main__":
    build_advanced_zip()
