#!/bin/bash
set -e

echo "=================================================="
echo " Initializing Advanced Google UA Suite Installer"
echo "=================================================="

# Check for python3
if ! command -v python3 &> /dev/null; then
    echo "[Error] Python 3 is required but not installed."
    exit 1
fi

# Create virtual environment
echo "[*] Setting up isolated Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip & install dependencies
echo "[*] Installing required platform dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo "=================================================="
echo " Installation Complete Successfully!"
echo " To start the advanced engine, execute:"
echo " source venv/bin/activate && uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000"
echo "=================================================="
