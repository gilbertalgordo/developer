import os

def create_icons():
    os.makedirs("frontend/static/icons", exist_ok=True)
    
    # Futuristic HUD Icon SVG
    svg_content = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#0284c7;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#38bdf8;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="512" height="512" rx="112" fill="#030712"/>
      <rect x="64" y="64" width="384" height="384" rx="64" fill="none" stroke="url(#grad)" stroke-width="24"/>
      <circle cx="256" cy="256" r="96" fill="none" stroke="#38bdf8" stroke-width="16" stroke-dasharray="16 12"/>
      <path d="M256 160v64M256 288v64M160 256h64M288 256h64" stroke="#f3f4f6" stroke-width="16" stroke-linecap="round"/>
      <circle cx="256" cy="256" r="32" fill="url(#grad)"/>
    </svg>"""
    
    icon_path = "frontend/static/icons/favicon.svg"
    with open(icon_path, "w") as f:
        f.write(svg_content)
    print(f"Generated icon asset: {icon_path}")

if __name__ == "__main__":
    create_icons()
