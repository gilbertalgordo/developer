from flask import Flask, render_template_string, jsonify
import random

app = Flask(__name__)

GOOGLE_AGENTS = {
    "Googlebot Desktop": "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Googlebot Smartphone": "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.69 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Google InspectionTool": "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.69 Mobile Safari/537.36 (compatible; Google-InspectionTool/1.0;)",
    "GoogleOther": "Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GoogleOther/1.0; +http://www.google.com/bot.html)"
}

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Google User Agent Generator</title>
    <style>
        body { font-family: Arial, sans-serif; background: #0f172a; color: #f8fafc; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #1e293b; padding: 2rem; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); width: 450px; }
        h2 { margin-top: 0; color: #38bdf8; }
        select, button { width: 100%; padding: 10px; margin-top: 10px; border-radius: 6px; border: none; font-size: 1rem; }
        select { background: #334155; color: white; }
        button { background: #0ea5e9; color: white; font-weight: bold; cursor: pointer; }
        button:hover { background: #0284c7; }
        .output { background: #0f172a; padding: 10px; margin-top: 15px; border-radius: 6px; word-break: break-all; font-family: monospace; font-size: 0.85rem; border: 1px solid #334155; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Google User Agent Generator</h2>
        <label for="agentType">Select Bot Profile:</label>
        <select id="agentType">
            {% for name in agents.keys() %}
            <option value="{{ name }}">{{ name }}</option>
            {% endfor %}
        </select>
        <button onclick="generateUA()">Generate String</button>
        <div class="output" id="result">Click generate to view user agent...</div>
    </div>
    <script>
        async function generateUA() {
            const type = document.getElementById('agentType').value;
            const response = await fetch('/api/generate', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({type: type})
            });
            const data = await response.json();
            document.getElementById('result').innerText = data.ua;
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, agents=GOOGLE_AGENTS)

@app.route('/api/generate', methods=['POST'])
def generate():
    from flask import request
    req_data = request.get_json()
    agent_type = req_data.get('type', 'Googlebot Desktop')
    return jsonify({"ua": GOOGLE_AGENTS.get(agent_type, list(GOOGLE_AGENTS.values())[0])})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
