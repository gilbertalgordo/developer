from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request
from pydantic import BaseModel
import random
import json
from datetime import datetime

app = FastAPI(title="Advanced Google UA & Client Hints API", version="2.0.0")
templates = Jinja2Templates(directory="frontend/templates")

# Advanced Googlebot and Chrome Headless Profiles with SEC-CH-UA Headers
GOOGLE_PROFILES = [
    {
        "id": "gbot-desktop-131",
        "name": "Googlebot Desktop (Chrome 131)",
        "type": "Crawler",
        "ua": "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
        "sec_ch_ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "sec_ch_ua_mobile": "?0",
        "sec_ch_ua_platform": '"Windows"'
    },
    {
        "id": "gbot-mobile-pixel9",
        "name": "Googlebot Smartphone (Pixel 9 / Android 15)",
        "type": "Mobile Crawler",
        "ua": "Mozilla/5.0 (Linux; Android 15; Pixel 9 Build/AP4A.240905.009) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.69 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
        "sec_ch_ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "sec_ch_ua_mobile": "?1",
        "sec_ch_ua_platform": '"Android"'
    },
    {
        "id": "g-inspect-tool",
        "name": "Google-InspectionTool",
        "type": "Diagnostics",
        "ua": "Mozilla/5.0 (Linux; Android 15; Pixel 9 Build/AP4A.240905.009) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.69 Mobile Safari/537.36 (compatible; Google-InspectionTool/1.0;)",
        "sec_ch_ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "sec_ch_ua_mobile": "?1",
        "sec_ch_ua_platform": '"Android"'
    },
    {
        "id": "google-other",
        "name": "GoogleOther Feed Fetcher",
        "type": "Fetcher",
        "ua": "Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GoogleOther/1.0; +http://www.google.com/bot.html)",
        "sec_ch_ua": "",
        "sec_ch_ua_mobile": "?0",
        "sec_ch_ua_platform": '""'
    }
]

class GenerationRequest(BaseModel):
    profile_id: str
    include_headers: bool = True

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "profiles": GOOGLE_PROFILES})

@app.get("/api/profiles")
async def get_profiles():
    return JSONResponse(content={"status": "success", "data": GOOGLE_PROFILES})

@app.post("/api/generate")
async def generate_advanced_ua(payload: GenerationRequest, background_tasks: BackgroundTasks):
    profile = next((p for p in GOOGLE_PROFILES if p["id"] == payload.profile_id), None)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile ID not found")
    
    # Background task logging metric simulation
    background_tasks.add_task(print, f"[{datetime.utcnow().isoformat()}] Generated profile: {profile['name']}")
    
    response_payload = {
        "profile": profile["name"],
        "user_agent": profile["ua"],
        "client_hints": {
            "Sec-Ch-Ua": profile["sec_ch_ua"],
            "Sec-Ch-Ua-Mobile": profile["sec_ch_ua_mobile"],
            "Sec-Ch-Ua-Platform": profile["sec_ch_ua_platform"]
        } if payload.include_headers else {}
    }
    return JSONResponse(content=response_payload)
