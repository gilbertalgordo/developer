plugins {
    id("com.android.application") version "8.4.0"
    id("org.jetbrains.kotlin.android") version "2.0.0"
}

android {
    namespace = "com.google.chrome.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.google.chrome.mobile"
        minSdk = 28
        targetSdk = 35
        versionCode = 20260101
        versionName = "2026.1.0-WebMCP"
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // Native QUIC and WebMCP runtime
    implementation("org.chromium.net:cronet-embedded:119.6045.31")
}