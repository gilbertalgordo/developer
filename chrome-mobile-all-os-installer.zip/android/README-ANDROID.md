# Chrome Mobile - Android Installation Guide

## Quick Start (Automated ADB Install)
1. Enable **Developer Options** and **USB Debugging** on your Android phone or tablet.
2. Connect device via USB cable or start an Android Emulator.
3. Open Terminal in this folder and run:
   ```bash
   chmod +x adb-install.sh
   ./adb-install.sh
   ```

## Manual Build via Android Studio
1. Open Android Studio and select **Open** -> Choose this directory.
2. Sync Gradle files (JDK 17+ recommended).
3. Select **Run** > **Run 'app'** targeting your connected device.

## Included Components
- `AndroidManifest.xml`: Android permissions and Activity declarations
- `build.gradle.kts`: Build configuration targeting Android 15 (API 35)
- `res/drawable/`: 5 Vector XML drawables for Chrome Mobile subsystems
- `adb-install.sh`: Fast sideload script with automated permission grants