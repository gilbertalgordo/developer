package com.google.chrome.mobile.services

import android.app.Service
import android.content.Intent
import android.os.IBinder

class ChromeOSSubsystemDaemon : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Background 15-second auto-update & quota watchdog
        return START_STICKY
    }
}