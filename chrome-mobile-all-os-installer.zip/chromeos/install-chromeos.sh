#!/usr/bin/env bash
# ==============================================================================
# Chrome Mobile ChromeOS Sideload & Crostini Installer
# ==============================================================================
set -e

echo "=== Chrome Mobile ChromeOS Sideload Utility ==="
echo "[1/2] Sideloading Unpacked Extension into Chrome..."
echo "Instructions:"
echo " 1. Open Google Chrome or ChromeOS browser."
echo " 2. Navigate to 'chrome://extensions'."
echo " 3. Toggle 'Developer mode' in the top-right corner."
echo " 4. Click 'Load unpacked' and select this unpacked directory."
echo ""
echo "[2/2] Checking Crostini Linux container..."
if [ -d "$HOME/.local/bin" ]; then
    echo "Configuring Linux Container executable link..."
    mkdir -p "$HOME/.local/share/applications"
fi

echo "SUCCESS: Chrome Mobile ready to run on ChromeOS!"