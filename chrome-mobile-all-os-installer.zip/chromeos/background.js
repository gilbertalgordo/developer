// Chrome Mobile ChromeOS Manifest V3 Background Worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('[Chrome Mobile ChromeOS] Subsystem Daemon & WebMCP Service Worker Initialized.');
  chrome.alarms.create('subsystem_watchdog', { periodInMinutes: 0.25 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'subsystem_watchdog') {
    // Poll system memory and sandbox telemetry
    if (chrome.system && chrome.system.memory) {
      chrome.system.memory.getInfo((info) => {
        const used = info.capacity - info.availableCapacity;
        console.log(`[Chrome Mobile RAM] Capacity: ${info.capacity}, Used: ${used}`);
      });
    }
  }
});