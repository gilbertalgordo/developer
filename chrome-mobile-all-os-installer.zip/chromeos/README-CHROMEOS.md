# Chrome Mobile - ChromeOS Installation Guide

## Installation Options
### Option 1: Chrome Unpacked Extension (Fastest)
1. Open Google Chrome on your Chromebook.
2. Navigate to: `chrome://extensions`
3. Enable **Developer mode** toggle in the upper-right corner.
4. Click **Load unpacked** and select this directory.
5. Chrome Mobile icon will appear in your Chrome toolbar!

### Option 2: Crostini Linux Integration
If Linux (Beta) is enabled on your Chromebook:
```bash
chmod +x install-chromeos.sh
./install-chromeos.sh
```

## Included Files
- `manifest.json`: Manifest V3 specification with system permissions
- `background.js`: Persistent background service worker
- `popup.html`: Chrome toolbar launcher interface
- `install-chromeos.sh`: Automation helper