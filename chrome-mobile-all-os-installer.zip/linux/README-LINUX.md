# Chrome Mobile - Linux Installation Guide

## Quick Start (Automated Install)
Run the automated installation script:
```bash
chmod +x install-linux.sh
./install-linux.sh
```

## Systemd Background Daemon (Optional)
To enable the 15-second background auto-update and subsystem monitor as a persistent systemd user service:
```bash
mkdir -p ~/.config/systemd/user
cp chrome-mobile-daemon.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now chrome-mobile-daemon.service
```

## Compatibility
- Works on Debian, Ubuntu, Linux Mint, Pop!_OS, Fedora, Arch Linux, openSUSE, and CentOS.
- Standard FreeDesktop / XDG compliance.