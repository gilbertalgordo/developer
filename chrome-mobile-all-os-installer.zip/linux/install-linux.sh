#!/usr/bin/env bash
# ==============================================================================
# Chrome Mobile Linux Native Installer (Debian/Ubuntu/Fedora/Arch)
# ==============================================================================
set -e

echo "=== Chrome Mobile Linux Installer ==="

TARGET_BIN="$HOME/.local/bin"
TARGET_DESKTOP="$HOME/.local/share/applications"
TARGET_ICON="$HOME/.local/share/icons/hicolor/scalable/apps"

echo "[1/4] Creating local XDG directory hierarchy..."
mkdir -p "$TARGET_BIN" "$TARGET_DESKTOP" "$TARGET_ICON"

echo "[2/4] Installing chrome-mobile executable script to $TARGET_BIN..."
cat << 'EOF' > "$TARGET_BIN/chrome-mobile"
#!/usr/bin/env bash
echo "Launching Chrome Mobile WebMCP Platform..."
xdg-open "http://localhost:3000" 2>/dev/null || sensible-browser "http://localhost:3000" || echo "Please navigate to http://localhost:3000"
EOF
chmod +x "$TARGET_BIN/chrome-mobile"

echo "[3/4] Registering Desktop Entry & Icon..."
cp chrome-mobile.desktop "$TARGET_DESKTOP/"
sed -i "s|/usr/local/bin/chrome-mobile|$TARGET_BIN/chrome-mobile|g" "$TARGET_DESKTOP/chrome-mobile.desktop"

# Refresh desktop database if available
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$TARGET_DESKTOP" 2>/dev/null || true
fi

echo "[4/4] Verifying PATH contains ~/.local/bin..."
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo "NOTE: Add 'export PATH="$HOME/.local/bin:$PATH"' to your ~/.bashrc or ~/.zshrc."
fi

echo "SUCCESS: Chrome Mobile Linux installation complete!"
echo "You can launch it from your application menu or by running 'chrome-mobile' in bash."