# Chrome Mobile - Windows Installation Guide

## Quick Start (Automated Install)
1. Double-click `install-windows.bat`.
2. A desktop shortcut named **Chrome Mobile** will be created automatically in your Desktop and Start Menu.
3. The app will launch immediately in your default browser.

## PowerShell Run
If batch execution is restricted, open PowerShell as Administrator and run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\install-windows.ps1
```

## System Requirements
- Windows 10 (Build 19041+) or Windows 11
- Microsoft Edge WebView2 Runtime (pre-installed on Windows 10/11)
- PowerShell 5.1 or later