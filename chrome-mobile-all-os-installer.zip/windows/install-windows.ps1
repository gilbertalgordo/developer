# Chrome Mobile PowerShell Advanced Installer
[CmdletBinding()]
param()

Write-Host "=== Chrome Mobile Windows PowerShell Installer ===" -ForegroundColor Cyan

$InstallDir = Join-Path $env:LOCALAPPDATA "ChromeMobile"
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    Write-Host "[OK] Created directory: $InstallDir" -ForegroundColor Green
}

# Copy files
Get-ChildItem -Path $PSScriptRoot -Exclude "*.zip" | Copy-Item -Destination $InstallDir -Recurse -Force
Write-Host "[OK] Files copied to $InstallDir" -ForegroundColor Green

# Create desktop shortcut
$Shell = New-Object -ComObject WScript.Shell
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$Shortcut = $Shell.CreateShortcut((Join-Path $DesktopPath "Chrome Mobile.lnk"))
$Shortcut.TargetPath = (Join-Path $InstallDir "launcher.bat")
$Shortcut.WorkingDirectory = $InstallDir
$Shortcut.IconLocation = "%SystemRoot%\System32\SHELL32.dll,220"
$Shortcut.Save()

Write-Host "[OK] Desktop shortcut created." -ForegroundColor Green
Write-Host "Chrome Mobile is ready to launch!" -ForegroundColor Cyan