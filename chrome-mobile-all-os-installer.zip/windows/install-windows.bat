@echo off
title Chrome Mobile Windows Installer
color 0B
echo ==============================================================================
echo Chrome Mobile Windows Automated Installer (WebMCP 2026)
echo ==============================================================================
echo.

set INSTALL_DIR=%LOCALAPPDATA%\ChromeMobile
echo [1/3] Creating installation directory at %INSTALL_DIR%...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [2/3] Copying application files and tools...
copy /Y * "%INSTALL_DIR%\" >nul 2>&1

echo [3/3] Creating Windows Desktop and Start Menu shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Chrome Mobile.lnk')); $Shortcut.TargetPath = [System.IO.Path]::Combine('%INSTALL_DIR%', 'launcher.bat'); $Shortcut.WorkingDirectory = '%INSTALL_DIR%'; $Shortcut.Description = 'Chrome Mobile WebMCP 2026 Runtime'; $Shortcut.Save()"

echo.
echo ==============================================================================
echo SUCCESS: Chrome Mobile installed successfully!
echo Desktop shortcut created. Starting Chrome Mobile...
echo ==============================================================================
start "" "%INSTALL_DIR%\launcher.bat"
pause