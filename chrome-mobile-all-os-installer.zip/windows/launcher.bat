@echo off
echo Starting Chrome Mobile WebMCP Subsystem...
start http://localhost:3000
exit