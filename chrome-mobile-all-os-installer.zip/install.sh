#!/usr/bin/env bash
# ==============================================================================
# Chrome Mobile Universal Master OS Auto-Detecting Installer
# ==============================================================================
set -e

cd "$(dirname "$0")"
OS_TYPE="$(uname -s)"

echo "=== Chrome Mobile Universal Installer ==="
echo "Detecting host operating system: $OS_TYPE"

case "$OS_TYPE" in
    Darwin*)
        echo "Detected Apple macOS! Launching macOS installer..."
        cd macos && ./install-mac.command
        ;;
    Linux*)
        if grep -qi "chrome" /etc/os-release 2>/dev/null; then
            echo "Detected Google ChromeOS! Launching ChromeOS installer..."
            cd chromeos && ./install-chromeos.sh
        else
            echo "Detected Linux! Launching Linux installer..."
            cd linux && ./install-linux.sh
        fi
        ;;
    CYGWIN*|MINGW*|MSYS*)
        echo "Detected Windows subsystem! Launching Windows installer..."
        cd windows && ./install-windows.bat
        ;;
    *)
        echo "Unknown OS type: $OS_TYPE. Please consult README in the respective OS folder."
        ;;
esac