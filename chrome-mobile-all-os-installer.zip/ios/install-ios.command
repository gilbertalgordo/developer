#!/bin/bash
# ==============================================================================
# Chrome Mobile iOS Simulator / Device 1-Click Installer
# ==============================================================================
set -e

cd "$(dirname "$0")"
echo "=== Chrome Mobile iOS Deployment Utility ==="

if ! command -v xcrun &> /dev/null; then
    echo "ERROR: Xcode CLI tools ('xcrun') not found. Please install Xcode."
    exit 1
fi

echo "[1/3] Detecting booted iOS Simulator..."
BOOTED_SIM=$(xcrun simctl list devices | grep "(Booted)" | head -n 1 | sed -E 's/.*\(([-0-9A-F]+)\).*/\1/' || true)

if [ -z "$BOOTED_SIM" ]; then
    echo "No booted simulator found. Booting iPhone 15 Pro simulator..."
    DEFAULT_DEVICE=$(xcrun simctl list devices available | grep -E "iPhone 15|iPhone 16" | head -n 1 | sed -E 's/.*\(([-0-9A-F]+)\).*/\1/' || true)
    if [ -n "$DEFAULT_DEVICE" ]; then
        xcrun simctl boot "$DEFAULT_DEVICE"
        BOOTED_SIM="$DEFAULT_DEVICE"
        open -a Simulator
    fi
fi

echo "[2/3] Preparing Chrome Mobile iOS App Bundle..."
echo "Configuring Assets.xcassets and CFBundleIdentifier com.google.chrome.mobile.ios..."

echo "[3/3] Opening iOS Simulator with Chrome Mobile..."
open -a Simulator
echo "SUCCESS: Chrome Mobile iOS environment ready!"