# Chrome Mobile - Apple iOS Installation Guide

## Quick Start (macOS Double-Click)
1. Double-click `install-ios.command` to automatically boot the iOS Simulator and configure the app.
2. Alternatively, run:
   ```bash
   chmod +x install-ios.command
   ./install-ios.command
   ```

## Physical Device (iPhone / iPad) Sideloading
1. **AltStore / Sideloadly**:
   - Package this directory into an `.ipa` archive or open the Xcode workspace.
   - Sideload with your free Apple ID.
2. **Xcode Direct Run**:
   - Open `ChromeMobile.xcodeproj` in Xcode 15+.
   - Select your connected iPhone from the device target dropdown and click **Play** (Cmd + R).

## Included Components
- `Info.plist`: iOS application capabilities, protocol handlers, and security policy.
- `Podfile`: Cronet QUIC and Google Sign-In dependencies.
- `Assets.xcassets/`: Vector catalog for iOS templates and icons.
- `ChromeMobileApp.swift`: SwiftUI native runtime harness.