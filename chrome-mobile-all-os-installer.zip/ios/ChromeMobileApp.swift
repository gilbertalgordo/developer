import SwiftUI
import WebKit

@main
struct ChromeMobileApp: App {
    var body: some Scene {
        WindowGroup {
            ChromeMobileContentView()
        }
    }
}

struct ChromeMobileContentView: View {
    var body: some View {
        Text("Chrome Mobile WebMCP 2026 Native Runtime")
            .font(.title2)
            .foregroundColor(.blue)
            .padding()
    }
}