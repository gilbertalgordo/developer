@echo off
echo === Chrome Mobile Universal Installer ===
echo Launching Windows installer from .\windows\install-windows.bat...
cd windows
call install-windows.bat