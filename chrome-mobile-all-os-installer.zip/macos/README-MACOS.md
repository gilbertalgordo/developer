# Chrome Mobile - macOS Installation Guide

## Quick Start (Double-Click Install)
1. Double-click `install-mac.command` in Finder.
2. If macOS displays a Gatekeeper prompt, click **Open** or visit **System Settings > Privacy & Security** and select **Open Anyway**.
3. Chrome Mobile will be installed to `/Applications/ChromeMobile.app`.

## Terminal Install
```bash
chmod +x install-mac.command
./install-mac.command
```

## Features Included
- Universal binary launcher for Apple Silicon (M1/M2/M3/M4) & Intel
- Custom URL scheme handler: `chromemobile://`
- Integration with macOS Launchpad and Dock