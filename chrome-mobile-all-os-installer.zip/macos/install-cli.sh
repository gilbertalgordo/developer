#!/usr/bin/env bash
set -e
echo "Installing CLI binary to /usr/local/bin/chrome-mobile..."
sudo cp ChromeMobile.app/Contents/MacOS/chrome-mobile /usr/local/bin/chrome-mobile 2>/dev/null || {
    mkdir -p "$HOME/.local/bin"
    cp ChromeMobile.app/Contents/MacOS/chrome-mobile "$HOME/.local/bin/chrome-mobile"
    echo "Installed to $HOME/.local/bin/chrome-mobile"
}
echo "Done! Run 'chrome-mobile' from any terminal."