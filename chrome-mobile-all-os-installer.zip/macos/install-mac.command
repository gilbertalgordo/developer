#!/bin/bash
# ==============================================================================
# Chrome Mobile macOS 1-Click Desktop Installer
# ==============================================================================
set -e

cd "$(dirname "$0")"
echo "=== Chrome Mobile macOS Installer ==="
echo "[1/3] Removing Gatekeeper quarantine attributes..."
xattr -cr ChromeMobile.app 2>/dev/null || true
chmod +x ChromeMobile.app/Contents/MacOS/chrome-mobile

echo "[2/3] Installing Chrome Mobile into /Applications..."
if [ -d "/Applications" ]; then
    rm -rf "/Applications/ChromeMobile.app" 2>/dev/null || true
    cp -R ChromeMobile.app /Applications/
    echo "Copied ChromeMobile.app to /Applications successfully."
fi

echo "[3/3] Launching Chrome Mobile..."
open "/Applications/ChromeMobile.app" 2>/dev/null || open "ChromeMobile.app"

echo "SUCCESS: Chrome Mobile installed and running!"