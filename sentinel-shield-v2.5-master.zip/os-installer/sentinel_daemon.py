#!/usr/bin/env python3
"""
Sentinel Shield Edge Proxy Daemon
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
Specification: https://github.com/gilbertalgordo/developer/blob/main/anti_ad_crawlers.yaml
"""

import http.server
import socketserver
import time
import json
import re

PORT = 8080
BLOCKED_SIGNATURES = ["bytespider","ccbot","gptbot","claude-web","claudebot","anthropic-ai","perplexitybot","omgili","peer39","adsbot-google","apis-google","scrapy","python-urllib","python-requests","httrack","axios/1."]

IP_BLACKLIST = {}   # ip -> expiry_timestamp
REQUEST_LEDGER = {} # ip -> [timestamps]

RATE_LIMIT_MAX = 45
RATE_LIMIT_WINDOW = 60
BAN_DURATION = 300

class SentinelHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Override standard logging
        pass

    def do_GET(self):
        self.handle_sentinel_inspection()

    def do_POST(self):
        self.handle_sentinel_inspection()

    def handle_sentinel_inspection(self):
        client_ip = self.client_address[0]
        now = time.time()
        ua = self.headers.get("User-Agent", "")

        # 1. IP Blacklist check
        if client_ip in IP_BLACKLIST:
            if IP_BLACKLIST[client_ip] > now:
                self.send_response(403)
                self.send_header("Content-Type", "application/json")
                self.send_header("X-Sentinel-Status", "BLOCKED_BLACKLIST")
                self.end_headers()
                self.wfile.write(b'{"error": "Access Denied: IP currently blacklisted by Sentinel Shield"}')
                return
            else:
                del IP_BLACKLIST[client_ip]

        # 2. Signature matching
        for sig in BLOCKED_SIGNATURES:
            if re.search(r"\b" + re.escape(sig) + r"\b", ua, re.IGNORECASE):
                IP_BLACKLIST[client_ip] = now + BAN_DURATION
                self.send_response(403)
                self.send_header("Content-Type", "application/json")
                self.send_header("X-Sentinel-Bot-Detected", sig)
                self.end_headers()
                self.wfile.write(b'{"error": "Access Denied: Malicious crawler signature detected"}')
                return

        # 3. Rate limiting
        history = [t for t in REQUEST_LEDGER.get(client_ip, []) if t > (now - RATE_LIMIT_WINDOW)]
        history.append(now)
        REQUEST_LEDGER[client_ip] = history

        if len(history) > RATE_LIMIT_MAX:
            IP_BLACKLIST[client_ip] = now + BAN_DURATION
            self.send_response(429)
            self.send_header("Content-Type", "application/json")
            self.send_header("Retry-After", str(BAN_DURATION))
            self.end_headers()
            self.wfile.write(b'{"error": "Rate limit exceeded: IP penalised"}')
            return

        # 4. Verified legitimate request
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("X-Sentinel-Protection", "Active")
        self.send_header("X-Sentinel-Author", "Gilbert Algordo")
        self.end_headers()
        response_payload = {
            "status": "ALLOWED",
            "message": "Protected ad inventory verified by Sentinel Shield",
            "client_ip": client_ip,
            "timestamp": int(now)
        }
        self.wfile.write(json.dumps(response_payload).encode("utf-8"))

if __name__ == "__main__":
    print(f"🛡️  Sentinel Shield Edge Daemon listening on port {PORT}...")
    with socketserver.TCPServer(("", PORT), SentinelHandler) as httpd:
        httpd.serve_forever()
