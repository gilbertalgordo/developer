#!/usr/bin/env bash
# ==============================================================================
# Sentinel Shield — Unified OS Edge Gateway Installer (Linux & macOS)
# Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
# Repository: https://github.com/gilbertalgordo/developer/blob/main/anti_ad_crawlers.yaml
# ==============================================================================

set -euo pipefail

INSTALL_DIR="/opt/sentinel-shield"
LOG_DIR="/var/log/sentinel-shield"
CONF_DIR="/etc/sentinel-shield"
PORT=8080

echo "🛡️  Installing Sentinel Shield Edge Daemon v2.5.0..."
echo "👤 Author: Gilbert Algordo (https://g.dev/gilbert_algordo)"

# Check root permissions
if [ "$(id -u)" -ne 0 ]; then
  echo "❌ Error: Please execute this installer as root (e.g., sudo bash install.sh)"
  exit 1
fi

# Detect Operating System
OS="$(uname -s)"
case "$OS" in
  Linux*)
    PLATFORM="linux"
    ;;
  Darwin*)
    PLATFORM="macos"
    ;;
  *)
    echo "❌ Unsupported operating system: $OS"
    exit 1
    ;;
esac

echo "Detected platform: $PLATFORM"

# Create directories
mkdir -p "$INSTALL_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$CONF_DIR"

# Copy python proxy daemon
cp sentinel_daemon.py "$INSTALL_DIR/sentinel_daemon.py"
cp anti_ad_crawlers.yaml "$CONF_DIR/anti_ad_crawlers.yaml"
chmod +x "$INSTALL_DIR/sentinel_daemon.py"

# Setup Systemd on Linux
if [ "$PLATFORM" = "linux" ]; then
  if command -v systemctl >/dev/null 2>&1; then
    cat << 'EOF' > /etc/systemd/system/sentinel-shield.service
[Unit]
Description=Sentinel Shield Anti-Ad-Crawler Edge Proxy
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/sentinel-shield
ExecStart=/usr/bin/env python3 /opt/sentinel-shield/sentinel_daemon.py
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable sentinel-shield.service
    systemctl restart sentinel-shield.service
    echo "✅ Linux Systemd Service installed and running: systemctl status sentinel-shield"
  else
    echo "⚠️ Systemd not found. Starting standalone background process..."
    nohup python3 "$INSTALL_DIR/sentinel_daemon.py" > "$LOG_DIR/daemon.log" 2>&1 &
  fi

  # Optional IPTables rate-limiting for scraper bot defense
  if command -v iptables >/dev/null 2>&1; then
    echo "🔒 Configuring kernel IPTables rate-limiting on port $PORT..."
    iptables -A INPUT -p tcp --dport "$PORT" -m state --state NEW -m recent --set --name SENTINEL_LIMIT
    iptables -A INPUT -p tcp --dport "$PORT" -m state --state NEW -m recent --update --seconds 60 --hitcount 45 -j DROP || true
  fi
fi

# Setup Launchd on macOS
if [ "$PLATFORM" = "macos" ]; then
  LAUNCHD_FILE="/Library/LaunchDaemons/com.sentinel.shield.plist"
  cat << 'EOF' > "$LAUNCHD_FILE"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.sentinel.shield</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/python3</string>
        <string>/opt/sentinel-shield/sentinel_daemon.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/var/log/sentinel-shield/daemon.log</string>
    <key>StandardErrorPath</key>
    <string>/var/log/sentinel-shield/error.log</string>
</dict>
</plist>
EOF
  launchctl load -w "$LAUNCHD_FILE" || true
  echo "✅ macOS LaunchDaemon loaded: com.sentinel.shield"
fi

echo "===================================================================="
echo "🎉 Sentinel Shield successfully installed and active on port $PORT!"
echo "   Inspect logs: tail -f $LOG_DIR/daemon.log"
echo "   Test edge: curl -I http://localhost:$PORT/api/v1/ad-content"
echo "===================================================================="
