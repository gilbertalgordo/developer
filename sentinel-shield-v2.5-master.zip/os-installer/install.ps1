# ==============================================================================
# Sentinel Shield — Windows PowerShell Installer & Firewall Hardening
# Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
# Reference: https://github.com/gilbertalgordo/developer/blob/main/anti_ad_crawlers.yaml
# ==============================================================================

# Require Administrator privileges
If (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Warning "Administrator rights required. Re-launching PowerShell as Administrator..."
    Start-Process powershell.exe -Verb RunAs -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"")
    Exit
}

$InstallDir = "$env:ProgramFiles\SentinelShield"
$Port = 8080

Write-Host "🛡️ Installing Sentinel Shield on Windows Server / Desktop..." -ForegroundColor Cyan
Write-Host "👤 Author: Gilbert Algordo (https://g.dev/gilbert_algordo)" -ForegroundColor DarkGray

# Create Target Directory
If (-Not (Test-Path -Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}

Copy-Item -Path "sentinel_daemon.py" -Destination "$InstallDir\sentinel_daemon.py" -Force
Copy-Item -Path "anti_ad_crawlers.yaml" -Destination "$InstallDir\anti_ad_crawlers.yaml" -Force

# Create Windows Defender Firewall Rules
Write-Host "🔒 Setting up Windows Defender Firewall Rule for Port $Port..." -ForegroundColor Yellow
Remove-NetFirewallRule -DisplayName "Sentinel Shield Edge Proxy" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Sentinel Shield Edge Proxy" -Direction Inbound -LocalPort $Port -Protocol TCP -Action Allow | Out-Null

# Create Scheduled Task to run on boot
Write-Host "⚙️ Registering Sentinel Shield background task..." -ForegroundColor Yellow
$Action = New-ScheduledTaskAction -Execute "python.exe" -Argument "$InstallDir\sentinel_daemon.py"
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Principal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit 0

Unregister-ScheduledTask -TaskName "SentinelShieldDaemon" -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName "SentinelShieldDaemon" -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings | Out-Null

# Start immediate instance
Start-ScheduledTask -TaskName "SentinelShieldDaemon"

Write-Host "====================================================================" -ForegroundColor Green
Write-Host "🎉 Sentinel Shield Windows Service is active on port $Port!" -ForegroundColor Green
Write-Host "   Directory: $InstallDir" -ForegroundColor White
Write-Host "   Firewall Rule: Active" -ForegroundColor White
Write-Host "====================================================================" -ForegroundColor Green
