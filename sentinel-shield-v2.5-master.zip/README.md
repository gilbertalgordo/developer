# Sentinel Shield — Multi-Platform Installation Guide

**Author**: [Gilbert Algordo](https://g.dev/gilbert_algordo)  
**Specification**: [anti_ad_crawlers.yaml](https://github.com/gilbertalgordo/developer/blob/main/anti_ad_crawlers.yaml)  
**License**: Apache-2.0

---

## 📦 What's Inside This Package

1. `/browser-extension/`  
   - `manifest.json` (Manifest v3 for Chrome, Edge, Brave, Opera, Firefox)
   - `background.js` (declarativeNetRequest & header inspection worker)
   - `content.js` (Headless crawler detection & Client Hints validator)
   - `rules.json` & `popup.html` / `popup.js`

2. `/os-installer/`  
   - `install.sh` (Unified Linux systemd & macOS launchd automated script)
   - `install.ps1` (Windows Server & Desktop PowerShell installer)
   - `sentinel_daemon.py` (Zero-dependency edge reverse proxy daemon)

3. `/middleware/`  
   - `anti_ad_crawlers.yaml` (Canonical security specification)

---

## 🚀 1. Browser Extension Installation (Chrome / Edge / Brave / Opera)

1. Unzip this file.
2. In your browser address bar, open `chrome://extensions` (or `edge://extensions`).
3. Toggle on **Developer mode** in the top-right corner.
4. Click **Load unpacked** and select the `browser-extension/` folder.
5. Sentinel Shield icon will appear in your extensions toolbar!

### Firefox Installation
1. Navigate to `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on...**
3. Select `browser-extension/manifest.json`.

---

## 🐧 2. Linux OS Installation (Ubuntu / Debian / RHEL / CentOS)

```bash
# Run automated installer as root:
sudo bash os-installer/install.sh

# Check systemd status:
sudo systemctl status sentinel-shield
```

---

## 🍏 3. macOS Installation (Launchd Daemon)

```bash
sudo bash os-installer/install.sh
# Logs located at /var/log/sentinel-shield/daemon.log
```

---

## 🪟 4. Windows Installation (PowerShell)

```powershell
# Open PowerShell as Administrator and run:
Set-ExecutionPolicy Bypass -Scope Process
.\os-installer\install.ps1
```
