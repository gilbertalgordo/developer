document.addEventListener('DOMContentLoaded', () => {
  chrome.runtime.sendMessage({ action: 'getStats' }, (stats) => {
    if (stats) {
      document.getElementById('inspectedCount').innerText = stats.inspected || 0;
      document.getElementById('blockedCount').innerText = stats.blocked || 0;
    }
  });

  document.getElementById('resetBtn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'resetStats' }, () => {
      document.getElementById('inspectedCount').innerText = '0';
      document.getElementById('blockedCount').innerText = '0';
    });
  });
});
