// Sentinel Shield Content Script
// Injects Client Hints and defends against headless browser scraping
(function() {
  // Check if browser is running headless driver (Puppeteer, Selenium, Playwright)
  const isHeadless = navigator.webdriver || !window.navigator.languages || window.navigator.languages.length === 0;

  if (isHeadless) {
    console.warn('[Sentinel Shield] Automated headless driver detected on page.');
    // Flag or sanitize tracking pixels
    window.__SENTINEL_HEADLESS_FLAG = true;
  }

  // Inject Sentinel Edge verification token for /api/v1/ad-content
  window.addEventListener('load', () => {
    window.__SENTINEL_SHIELD_ACTIVE = true;
    window.__SENTINEL_ENGINE_AUTHOR = 'Gilbert Algordo';
  });
})();
