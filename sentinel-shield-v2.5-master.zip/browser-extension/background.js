// Sentinel Shield Browser Extension Background Service Worker
// Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
// Specification: anti_ad_crawlers.yaml

const BLOCKED_SIGNATURES = ["bytespider","ccbot","gptbot","claude-web","claudebot","anthropic-ai","perplexitybot","omgili","peer39","adsbot-google","apis-google","scrapy","python-urllib","python-requests","httrack","axios/1."];
let stats = {
  inspected: 0,
  blocked: 0,
  lastBlockedAt: null,
  active: true
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ sentinelStats: stats });
  console.log('[Sentinel Shield] Browser extension installed and monitoring network requests.');
});

// Intercept headers and detect crawler / headless tampering
chrome.webRequest?.onBeforeSendHeaders?.addListener(
  (details) => {
    stats.inspected++;
    const headers = details.requestHeaders || [];
    const uaHeader = headers.find(h => h.name.toLowerCase() === 'user-agent')?.value || '';

    // Test signatures
    const isBot = BLOCKED_SIGNATURES.some(sig => uaHeader.toLowerCase().includes(sig.toLowerCase()));
    if (isBot) {
      stats.blocked++;
      stats.lastBlockedAt = new Date().toLocaleTimeString();
      chrome.storage.local.set({ sentinelStats: stats });
      chrome.action.setBadgeText({ text: stats.blocked.toString() });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
      return { cancel: true };
    }
    return { requestHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders', 'extraHeaders']
);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    chrome.storage.local.get(['sentinelStats'], (res) => {
      sendResponse(res.sentinelStats || stats);
    });
    return true;
  }
  if (request.action === 'resetStats') {
    stats = { inspected: 0, blocked: 0, lastBlockedAt: null, active: true };
    chrome.storage.local.set({ sentinelStats: stats });
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ ok: true });
  }
});
