@echo off
REM =========================================================
REM Wikipedia Sentinel - Automated Windows Installer
REM =========================================================

echo =================================================
echo   Wikipedia Sentinel - Local Windows Installer
echo =================================================

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js (v18+) from https://nodejs.org/
    pause
    exit /b 1
)

echo [INFO] Installing package dependencies...
call npm install

if %errorlevel% neq 0 (
    echo [ERROR] npm install encountered an error.
    pause
    exit /b 1
)

echo =================================================
echo   Installation complete! Launching dev server...
echo   Open http://localhost:3000 in your browser.
echo =================================================
call npm run dev
