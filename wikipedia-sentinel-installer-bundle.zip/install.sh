#!/usr/bin/env bash
# =========================================================
# Wikipedia Sentinel - Automated Local Installer & Launcher
# =========================================================

set -e

echo "=== Wikipedia Sentinel Installation Starting ==="

# Check Node.js installation
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js (version 18+ or 20+) is required."
    echo "Please install Node.js from https://nodejs.org/ and rerun this script."
    exit 1
fi

NODE_VERSION=$(node -v)
echo "[INFO] Found Node.js version: $NODE_VERSION"

# Check npm installation
if ! command -v npm &> /dev/null; then
    echo "[ERROR] npm is required but was not found."
    exit 1
fi

echo "[INFO] Installing application dependencies..."
npm install

echo "[SUCCESS] Dependencies installed successfully."
echo "================================================="
echo "Starting Wikipedia Sentinel local development server..."
echo "Open your browser at: http://localhost:3000"
echo "Press Ctrl+C to stop the application."
echo "================================================="

npm run dev
