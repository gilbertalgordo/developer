# Wikipedia Sentinel - Offline & Local Setup Guide

Welcome to the **Wikipedia Sentinel** installer package.

## Quick Start (1-Minute Setup)

### On macOS / Linux:
```bash
chmod +x install.sh
./install.sh
```

### On Windows:
Double-click `install.bat` or run in Command Prompt / PowerShell:
```cmd
install.bat
```

### Manual Setup:
```bash
npm install
npm run dev
```
Then open **http://localhost:3000** in your browser.

### Docker Setup:
```bash
docker compose up --build
```

## Features Included
- **Live Wikimedia SSE Stream**: Direct real-time connection to Wikipedia's EventStreams.
- **AI & Bot Detection Engine**: Perplexity estimations, burstiness scoring, and repetition heuristics.
- **PWA Installation**: Installable as a native desktop or mobile progressive web app.
- **Automated Rollbacks**: Simulated MediaWiki administrative rollback traces.
- **Forensic ZIP/CSV/JSON Exports**: Instant full session data exports.

Created with Google AI Studio.
