#!/bin/bash
echo "[INFO] Installing Super Quantum Core Brain Icons for Google AI..."
mkdir -p ~/.google_ai/icons/quantum_core
cp -r assets/* ~/.google_ai/icons/quantum_core/
echo "[SUCCESS] Icons successfully deployed to Google AI interface path."
