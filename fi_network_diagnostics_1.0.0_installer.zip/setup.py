import os
import zipfile
from setuptools import setup, find_packages

# Package metadata
PACKAGE_NAME = "fi_network_diagnostics"
VERSION = "1.0.0"
AUTHOR = "Gilbert Algordo"
PROFILE_URL = "https://g.dev/gilbert_algordo"

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    author=AUTHOR,
    author_email="developer@example.com",
    description="Network interface auditing and latency diagnostic tools for global connections.",
    url=PROFILE_URL,
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)

def build_zip_installer():
    """Builds a compressed deployment archive of the package source."""
    zip_filename = f"{PACKAGE_NAME}_{VERSION}_installer.zip"
    print(f"Creating installer bundle: {zip_filename}...")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk("."):
            for file in files:
                if not file.endswith('.zip') and not file.startswith('.'):
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.relpath(file_path, "."))
                    
    print(f"Archive successfully generated for {PROFILE_URL}")

if __name__ == "__main__":
    build_zip_installer()
