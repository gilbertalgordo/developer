# fi_network_diagnostics (v1.0.0)
Google Fi Global & Satellite Connectivity Diagnostic Suite
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
Repository: https://github.com/gilbertalgordo/developer

## Quickstart

```bash
# 1. Install package dependencies
python setup.py

# 2. Run Global Network Tracer
python diagnostics/tracer.py

# 3. Check Web Connectivity
python diagnostics/connectivity.py
```
