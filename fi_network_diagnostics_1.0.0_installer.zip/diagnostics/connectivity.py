import os
import urllib.request
import json

def check_global_connectivity():
    """
    Simulates checking network routing and standard internet accessibility.
    """
    test_endpoints = [
        "https://www.google.com",
        "https://8.8.8.8"
    ]
    
    status = {}
    print("Checking network routing status...")
    
    for endpoint in test_endpoints:
        try:
            response = urllib.request.urlopen(endpoint, timeout=5)
            status[endpoint] = "Connected (200 OK)" if response.status == 200 else f"Status Code: {response.status}"
        except Exception as e:
            status[endpoint] = f"Connection Failed: {str(e)}"
            
    return status

if __name__ == "__main__":
    connectivity_report = check_global_connectivity()
    print(json.dumps(connectivity_report, indent=4))
