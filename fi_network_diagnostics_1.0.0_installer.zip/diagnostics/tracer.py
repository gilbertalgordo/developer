import socket
import time
import json

class GlobalNetworkTracer:
    def __init__(self):
        # Public DNS endpoints used to test global routing
        self.target_nodes = {
            "Google Primary DNS": "8.8.8.8",
            "Google Secondary DNS": "8.8.4.4",
            "Cloudflare DNS": "1.1.1.1"
        }

    def measure_latency(self, host: str, port: int = 53, timeout: float = 3.0) -> float:
        """Measures TCP connection latency to a specific endpoint in milliseconds."""
        start_time = time.time()
        try:
            sock = socket.create_connection((host, port), timeout=timeout)
            latency = (time.time() - start_time) * 1000
            sock.close()
            return round(latency, 2)
        except (socket.timeout, socket.error):
            return -1.0

    def run_diagnostics(self) -> dict:
        """Executes connection checks across all defined target nodes."""
        results = {}
        for name, ip in self.target_nodes.items():
            latency = self.measure_latency(ip)
            results[name] = {
                "ip": ip,
                "latency_ms": latency if latency != -1.0 else "Unreachable",
                "status": "Online" if latency != -1.0 else "Offline"
            }
        return results

if __name__ == "__main__":
    tracer = GlobalNetworkTracer()
    report = tracer.run_diagnostics()
    print(json.dumps(report, indent=4))
