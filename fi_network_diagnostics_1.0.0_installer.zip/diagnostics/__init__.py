# fi_network_diagnostics package
__version__ = "1.0.0"
