#!/usr/bin/env bash
echo "Starting Active AI Drone GPS Tactical HUD Offline Server..."
if command -v npx &> /dev/null; then
  npx serve . -l 3000
elif command -v python3 &> /dev/null; then
  python3 -m http.server 3000
else
  echo "Please install Node.js (npx) or Python 3 to serve offline."
  exit 1
fi
