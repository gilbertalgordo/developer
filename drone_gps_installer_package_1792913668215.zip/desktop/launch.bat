@echo off
echo Starting Active AI Drone GPS Tactical HUD Offline Server...
npx serve . -l 3000 || python -m http.server 3000
pause
