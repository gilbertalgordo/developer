# Active AI Drone GPS Navigation — Mobile & Web Installer Package
**Version:** 1.4.0
**Author:** Gilbert Algordo ([https://g.dev/gilbert_algordo](https://g.dev/gilbert_algordo))
**Upstream:** [github.com/gilbertalgordo/developer/blob/main/drone_gps.yaml](https://github.com/gilbertalgordo/developer/blob/main/drone_gps.yaml)

---

## 1. Web / Desktop Progressive Web App (PWA)
1. Open the application in Google Chrome, Microsoft Edge, Brave, or Safari.
2. In the URL bar:
   - **Chrome / Edge**: Click the **Install** icon (desktop screen with arrow) on the right side of the URL bar.
   - Or click the three dots menu (`...`) $\rightarrow$ **Save and Share** $\rightarrow$ **Install page as app**.
3. The app now launches in its own dedicated, chromeless OS window with full offline support.

---

## 2. Mobile Installation (Android)
### Option A: Direct Web APK / Home Screen
1. Open the app URL in Google Chrome for Android.
2. Tap the three dots menu (`⋮`) in the top right.
3. Select **Add to Home screen** (or **Install App**).
4. Tap **Install** to add the tactical drone icon to your Android app drawer.

### Option B: Build Native Android APK with Google Bubblewrap
1. Open terminal inside this unzipped folder:
   ```bash
   npm install -g @bubblewrap/cli
   bubblewrap init --manifest=manifest.webmanifest
   bubblewrap build
   ```
2. The compiled signed `app-release-signed.apk` will be generated in your output directory, ready for sideloading or Google Play Store release.

---

## 3. Mobile Installation (Apple iOS / iPadOS)
1. Open the app in Apple Safari on iPhone or iPad.
2. Tap the **Share** button (box with an arrow pointing up) in the bottom toolbar.
3. Scroll down and tap **Add to Home Screen**.
4. Confirm the name **DroneHUD** and tap **Add** in the top-right corner.
5. Launch the app directly from your iOS Home Screen for a fullscreen cockpit experience without browser chrome.

---

## 4. Offline Local Execution
Run either:
- **macOS / Linux**: `bash desktop/launch.sh`
- **Windows**: Double-click `desktop/launch.bat`
