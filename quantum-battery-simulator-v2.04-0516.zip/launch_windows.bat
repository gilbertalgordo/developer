@echo off
echo Starting Quantum Battery Simulator...
call npm run dev
pause
