# Nexus Quantum Battery Simulator v2.04
Author: Gilbert Algordo
Engine: Dicke State Superabsorption & Lindbladian Master Equation Evolution
Platform: High-Fidelity Real-Time Quantum Telemetry HUD & Progressive Web App (PWA)

## Overview
This package contains the complete distribution and standalone offline runner for the Quantum Battery Simulator.
Quantum batteries exploit collective quantum phenomena (entanglement and cooperative Dicke states) to achieve superabsorption:
the charging power scales quadratically ($P \propto N^2$) rather than linearly ($P \propto N$).

### Included Components:
- **Standalone Offline Runner**: Double-click `quantum_battery_standalone_runner.html` to run immediately in ANY browser offline without Node.js or internet connection!
- **Complete Source Code**: Full React 19, TypeScript, Tailwind CSS, and Hamiltonian physics solvers located in `src/`.
- **Installer & Launcher Scripts**:
  - Windows: `install_windows.bat` / `launch_windows.bat`
  - macOS / Linux: `install_unix.sh` / `launch_unix.sh`
  - Desktop Entry: `quantum_battery.desktop`
- **Live Telemetry Snapshot**: Exported parameters captured during download in `telemetry_snapshot.json`.

## Quick Start (Offline Browser)
Simply open `quantum_battery_standalone_runner.html` directly in Google Chrome, Microsoft Edge, Mozilla Firefox, or Apple Safari.

## Quick Start (Developer Setup)
1. Install Node.js (v18+ recommended).
2. Run `npm install` (or execute `install_unix.sh` / `install_windows.bat`).
3. Run `npm run dev` to launch the local Vite development server on http://localhost:3000.
4. Run `npm run build` to build the production PWA bundle.

## Physics Principles
- **Hamiltonian**: Transverse magnetic drive $H = g \sum_{i} \sigma_x^{(i)} + J \sum_{i<j} \sigma_z^{(i)} \sigma_z^{(j)}$
- **Lindblad Decoherence**: Environmental dephasing through non-unitary jump operators $\mathcal{L}[\rho]$.
- **Superabsorption Factor**: Collective Dicke subspace transition rate acceleration $\gamma_{collective} = \gamma_0 \cdot j(j+1)$.
- **Ergotropy**: Coherent maximum extractable work under cyclical unitary operations.

Enjoy exploring quantum energetics!
