#!/usr/bin/env bash
set -e
echo "========================================================"
echo "  Nexus Quantum Battery Simulator - Automatic Setup"
echo "========================================================"
if ! command -v node &> /dev/null; then
  echo "[ERROR] Node.js is not found."
  echo "Please install Node.js (v18+) or double-click 'quantum_battery_standalone_runner.html' to run in browser."
  exit 1
fi
echo "Installing dependencies..."
npm install
echo "Setup complete! Run ./launch_unix.sh to launch the application."
