@echo off
echo ========================================================
echo   Nexus Quantum Battery Simulator - Automatic Setup
echo ========================================================
echo Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js is not installed or not in PATH.
  echo Please download and install Node.js from https://nodejs.org/
  echo Or simply double-click 'quantum_battery_standalone_runner.html' to run offline!
  pause
  exit /b 1
)
echo Installing project dependencies...
call npm install
echo.
echo Setup completed successfully!
echo To start the Quantum Battery HUD, run 'launch_windows.bat'.
pause
