export interface Complex { re: number; im: number; }
export interface TelemetryData {
  model: string;
  soc: number;
  temperature: number;
  coherence: number;
  entropy: number;
  isCharging: boolean;
  quantumBoost: number;
  stability: "STABLE" | "STABILIZING" | "CRITICAL";
  voltage: number;
  current: number;
  totalCapacity: number;
  energyStored: number;
}
export interface SimConfig {
  nCells: number;
  couplingStrength: number;
  interCellInteraction: number;
  decoherenceRate: number;
}
export interface BlochVector { x: number; y: number; z: number; }
