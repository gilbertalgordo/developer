#!/usr/bin/env bash
# Equatorial Underwater Cooling Setup Installer
set -e

echo "=========================================================="
echo " Installing Active Equator Underwater Cooling Daemon"
echo " Source: gilbertalgordo/dev"
echo "=========================================================="

# Check Python3
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is required. Please install python3."
    exit 1
fi

echo "[1/3] Creating virtual environment (.venv)..."
python3 -m venv .venv
source .venv/bin/activate

echo "[2/3] Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[3/3] Setting executable permissions..."
chmod +x equatorial_cooling_daemon.py

echo "=========================================================="
echo " Installation Complete!"
echo " Run controller with:"
echo "   source .venv/bin/activate && python3 equatorial_cooling_daemon.py"
echo "=========================================================="
