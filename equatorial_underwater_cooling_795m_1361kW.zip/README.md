# Active Equator Underwater Cooling

Interactive engineering telemetry, autonomous thermal agent, and thermocline simulator for equatorial deep-sea data centers.
Source: [gilbertalgordo/dev/active_equator_underwater_cooling.yaml](https://github.com/gilbertalgordo/dev/blob/main/active_equator_underwater_cooling.yaml)

## Package Contents
- `active_equator_underwater_cooling.yaml`: Original upstream YAML specification.
- `equatorial_cooling_daemon.py`: Standalone executable Python controller.
- `install.sh`: One-click bash installation script.
- `requirements.txt`: Python package dependencies.
- `telemetry_snapshot.json`: Live calibrated simulation telemetry snapshot.
- `subsea_pod_specification.json`: Complete titanium pressure hull & heat exchanger specs.

## Quickstart

```bash
chmod +x install.sh
./install.sh
source .venv/bin/activate
python3 equatorial_cooling_daemon.py
```

## Physics Formulations

### Equatorial Thermocline Stratification
$$T(z) = T_{\text{deep}} + (T_{\text{surf}} - T_{\text{deep}}) \cdot e^{-z / h}$$

Where:
- $T_{\text{surf}} = 32^\circ\text{C}$
- $T_{\text{deep}} = 4.2^\circ\text{C}$
- $h = 150\text{m}$

### VFD Pump Frequency Output
$$m_{\text{dot}} = \frac{Q}{C_p \cdot \Delta T}$$
$$\text{vfd\_freq} = \min(60, m_{\text{dot}} \cdot 15.5)$$
