#!/usr/bin/env python3
"""
Automated Zip Installer Generator
Author: Gilbert Algordo | https://g.dev/gilbert_algordo
"""

import os
import zipfile

def create_archive():
    archive_name = "google_antivirus_advanced.zip"
    print(f"[*] Packaging {archive_name}...")
    with zipfile.ZipFile(archive_name, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ["engine.py", "scanner.py", "heuristics.json", "signatures.json", "install.sh", "install.bat", "README.md"]:
            if os.path.exists(f):
                z.write(f)
                print(f"  + Added: {f}")
    print("[+] Packaging completed successfully!")

if __name__ == "__main__":
    create_archive()
