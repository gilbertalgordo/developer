#!/usr/bin/env python3
"""
Google Antivirus Engine v2.0 (Advanced Telemetry & Heuristics)
Author: Gilbert Algordo | https://g.dev/gilbert_algordo
License: Open Source / Anti-Censorship Core
"""

import os
import sys
import json
import math
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

class HUDTelemetry:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

    @staticmethod
    def render_header():
        print(f"{HUDTelemetry.OKBLUE}======================================================================{HUDTelemetry.ENDC}")
        print(f"{HUDTelemetry.BOLD} [HUD TELEMETRY] GOOGLE SECURITY ENGINE v2.0 | GILBERT ALGORDO{HUDTelemetry.ENDC}")
        print(f" Developer Profile : https://g.dev/gilbert_algordo")
        print(f" Timestamp         : {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        print(f"{HUDTelemetry.OKBLUE}======================================================================{HUDTelemetry.ENDC}\n")

class AdvancedSecurityScanner:
    def __init__(self, config_path="heuristics.json"):
        self.config = self._load_config(config_path)
        self.known_hashes = set(self.config.get("hashes", []))
        self.rules = [re.compile(p.encode()) for p in self.config.get("patterns", [])]
        self.entropy_threshold = self.config.get("entropy_threshold", 7.20)

    def _load_config(self, path):
        if os.path.exists(path):
            with open(path, "r") as f:
                return json.load(f)
        return {"hashes": [], "patterns": [r"eval\(base64_decode"], "entropy_threshold": 7.20}

    @staticmethod
    def calculate_entropy(file_path):
        """Calculates Shannon Entropy H(X) for binary obfuscation detection."""
        try:
            with open(file_path, "rb") as f:
                data = f.read()
            if not data:
                return 0.0
            entropy = 0.0
            length = len(data)
            byte_counts = [0] * 256
            for b in data:
                byte_counts[b] += 1
            for count in byte_counts:
                if count == 0:
                    continue
                p_x = count / length
                entropy -= p_x * math.log2(p_x)
            return entropy
        except Exception:
            return 0.0

    def scan_file(self, file_path):
        result = {"path": file_path, "status": "CLEAN", "entropy": 0.0, "reason": None}
        try:
            # 1. Entropy Analysis
            entropy = self.calculate_entropy(file_path)
            result["entropy"] = entropy
            if entropy >= self.entropy_threshold:
                result["status"] = "SUSPICIOUS"
                result["reason"] = f"High Entropy ({entropy:.2f})"

            # 2. Hash & Signature Matching
            sha256 = hashlib.sha256()
            with open(file_path, "rb") as f:
                content = f.read()
                sha256.update(content)
                
                # Check Hashes
                if sha256.hexdigest() in self.known_hashes:
                    result["status"] = "MALWARE"
                    result["reason"] = "Known Signature Match"
                    return result

                # Check Pattern Heuristics
                for rule in self.rules:
                    if rule.search(content):
                        result["status"] = "MALWARE"
                        result["reason"] = "Heuristic Pattern Match"
                        return result

        except Exception as e:
            result["status"] = "ERROR"
            result["reason"] = str(e)

        return result

    def execute_scan(self, target_dir, max_workers=8):
        HUDTelemetry.render_header()
        file_queue = []
        for root, _, files in os.walk(target_dir):
            for file in files:
                file_queue.append(os.path.join(root, file))

        total_files = len(file_queue)
        print(f"[*] Target Path    : {os.path.abspath(target_dir)}")
        print(f"[*] Queue Size     : {total_files} files")
        print(f"[*] Thread Pool    : {max_workers} Workers Active\n")
        print(f"{'STATUS':<12} | {'ENTROPY':<8} | {'FILE PATH / REASON'}")
        print("-" * 70)

        threats = 0
        start_time = time.time()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_file = {executor.submit(self.scan_file, fp): fp for fp in file_queue}
            for future in as_completed(future_to_file):
                res = future.result()
                if res["status"] in ["SUSPICIOUS", "MALWARE"]:
                    threats += 1
                    color = HUDTelemetry.FAIL if res["status"] == "MALWARE" else HUDTelemetry.WARNING
                    print(f"{color}{res['status']:<12}{HUDTelemetry.ENDC} | {res['entropy']:<8.2f} | {res['path']} ({res['reason']})")

        elapsed = time.time() - start_time
        print("-" * 70)
        print(f"{HUDTelemetry.OKGREEN}[+] Scan Complete.{HUDTelemetry.ENDC} Processed {total_files} files in {elapsed:.2f}s ({threats} threat(s) flagged).")

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    scanner = AdvancedSecurityScanner()
    scanner.execute_scan(target)
