#!/usr/bin/env python3
"""
Google Antivirus Scanner - Vector Icon Generator
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
"""

import os

SVG_ASSETS = {
    "app_icon.svg": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="gBlue" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4285F4"/>
      <stop offset="100%" stop-color="#1A73E8"/>
    </linearGradient>
    <linearGradient id="gRed" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#EA4335"/>
      <stop offset="100%" stop-color="#B31412"/>
    </linearGradient>
  </defs>
  <path d="M256 32 L416 96 V224 C416 336 341 435 256 480 C171 435 96 336 96 224 V96 Z" fill="url(#gBlue)" stroke="#174EA6" stroke-width="8"/>
  <path d="M256 64 L384 112 V224 C384 312 325 392 256 432 Z" fill="#34A853" opacity="0.85"/>
  <path d="M256 64 L128 112 V224 C128 312 187 392 256 432 Z" fill="url(#gRed)" opacity="0.85"/>
  <rect x="208" y="224" width="96" height="112" rx="16" fill="#FFFFFF"/>
  <path d="M224 224 V184 C224 166 238 152 256 152 C274 152 288 166 288 184 V224" fill="none" stroke="#FFFFFF" stroke-width="16" stroke-linecap="round"/>
  <circle cx="256" cy="272" r="12" fill="#1A73E8"/>
  <circle cx="256" cy="256" r="180" fill="none" stroke="#FBBC05" stroke-width="4" stroke-dasharray="16 12"/>
</svg>''',

    "scanner_hud.svg": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <rect width="512" height="512" rx="64" fill="#0D1117"/>
  <circle cx="256" cy="256" r="200" fill="none" stroke="#00E5FF" stroke-width="2" opacity="0.3"/>
  <circle cx="256" cy="256" r="140" fill="none" stroke="#00E5FF" stroke-width="2" stroke-dasharray="8 8" opacity="0.5"/>
  <circle cx="256" cy="256" r="80" fill="none" stroke="#00E5FF" stroke-width="2" opacity="0.7"/>
  <line x1="256" y1="36" x2="256" y2="476" stroke="#00E5FF" stroke-width="2" opacity="0.3"/>
  <line x1="36" y1="256" x2="476" y2="256" stroke="#00E5FF" stroke-width="2" opacity="0.3"/>
  <path d="M256 256 L397 115 A200 200 0 0 1 456 256 Z" fill="#00E5FF" opacity="0.35"/>
  <line x1="256" y1="256" x2="456" y2="256" stroke="#00E5FF" stroke-width="4"/>
  <circle cx="256" cy="256" r="8" fill="#00E5FF"/>
</svg>''',

    "threat_alert.svg": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <path d="M256 32 L448 432 H64 Z" fill="#EA4335" stroke="#B31412" stroke-width="8"/>
  <path d="M256 160 V288" stroke="#FFFFFF" stroke-width="28" stroke-linecap="round"/>
  <circle cx="256" cy="352" r="18" fill="#FFFFFF"/>
</svg>''',

    "secure_check.svg": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <circle cx="256" cy="256" r="224" fill="#34A853"/>
  <path d="M160 256 L224 320 L352 192" fill="none" stroke="#FFFFFF" stroke-width="36" stroke-linecap="round" stroke-linejoin="round"/>
</svg>'''
}

def build_svg_assets(output_dir="icons"):
    os.makedirs(output_dir, exist_ok=True)
    for filename, content in SVG_ASSETS.items():
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[+] Rendered Icon: {filepath}")

if __name__ == "__main__":
    build_svg_assets()
