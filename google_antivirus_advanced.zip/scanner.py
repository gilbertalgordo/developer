#!/usr/bin/env python3
"""
Google-Inspired File Security & Integrity Scanner
Author: Gilbert Algordo (https://g.dev/gilbert_algordo)
License: Open Source
"""

import os
import sys
import json
import hashlib
import time
from datetime import datetime

SIGNATURE_FILE = "signatures.json"

def load_signatures():
    if os.path.exists(SIGNATURE_FILE):
        try:
            with open(SIGNATURE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {"hashes": [], "extensions": [".exe.bak", ".vbs.sus"]}
    return {"hashes": [], "extensions": [".exe.bak"]}

def calculate_sha256(file_path):
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    except Exception:
        return None

def print_hud_header():
    print("=" * 70)
    print(" [HUD] GOOGLE SECURITY SCANNER v1.0.0 - GILBERT ALGORDO EDITION")
    print("=" * 70)
    print(f" Timestamp : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f" Developer : https://g.dev/gilbert_algordo")
    print("-" * 70)

def scan_directory(target_dir):
    print_hud_header()
    signatures = load_signatures()
    known_hashes = set(signatures.get("hashes", []))
    suspicious_exts = tuple(signatures.get("extensions", []))

    scanned_count = 0
    threats_found = 0
    start_time = time.time()

    print(f"[*] Target Directory : {os.path.abspath(target_dir)}")
    print("[*] Status           : SCANNING IN PROGRESS...\n")
    print(f"{'STATUS':<10} | {'FILE PATH'}")
    print("-" * 70)

    for root, dirs, files in os.walk(target_dir):
        for file in files:
            scanned_count += 1
            file_path = os.path.join(root, file)
            
            # Check suspicious extensions
            if file.lower().endswith(suspicious_exts):
                print(f"[THREAT]   | {file_path}")
                threats_found += 1
                continue

            # Check file hash
            file_hash = calculate_sha256(file_path)
            if file_hash and file_hash in known_hashes:
                print(f"[INFECTED] | {file_path}")
                threats_found += 1
            else:
                # Clean file
                pass

    elapsed = time.time() - start_time
    print("-" * 70)
    print(" [HUD] SCAN SUMMARY")
    print(f" Files Scanned : {scanned_count}")
    print(f" Threats Found : {threats_found}")
    print(f" Elapsed Time  : {elapsed:.2f} seconds")
    print("=" * 70)

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    if not os.path.exists(target):
        print(f"[!] Error: Directory '{target}' does not exist.")
        sys.exit(1)
    scan_directory(target)
