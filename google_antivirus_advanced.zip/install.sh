#!/usr/bin/env bash
echo "================================================================="
echo " Installing Google Antivirus Engine by Gilbert Algordo..."
echo " Profile: https://g.dev/gilbert_algordo"
echo "================================================================="
chmod +x engine.py scanner.py
echo "[SUCCESS] Installation completed. Run './engine.py <dir>' to scan."
