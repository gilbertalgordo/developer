@echo off
echo =================================================================
echo Installing Google Antivirus Engine...
echo Developer Profile: https://g.dev/gilbert_algordo
echo =================================================================
echo Ready to scan. Run "python engine.py C:\path\to\scan"
pause
