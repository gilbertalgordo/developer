import os
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw

class GoogleWalletBankIconGenerator:
    """
    Generates compliant brand assets for Google Wallet Issuer API specifications.
    
    Specs per Google Documentation:
    - Standard Logo: 660x660 px (1:1 Ratio)
    - Safe Area: 15% inner margin (561x561 px artwork zone) for circular masking
    - File Formats: PNG (32-bit transparent) and SVG
    """
    
    def __init__(self, brand_name: str, primary_hex: str = "#003399"):
        self.brand_name = brand_name.lower().replace(" ", "_")
        self.primary_hex = primary_hex
        self.canvas_size = 660
        self.margin = int(self.canvas_size * 0.15)  # 15% Safe Area Margin (99px)
        
    def generate_svg_logo(self, output_path: str):
        """Builds a 660x660 SVG with 15% padding safe zone."""
        svg = ET.Element('svg', {
            'xmlns': 'http://www.w3.org/2000/svg',
            'viewBox': f'0 0 {self.canvas_size} {self.canvas_size}',
            'width': str(self.canvas_size),
            'height': str(self.canvas_size)
        })
        
        # Transparent Background
        rect = ET.SubElement(svg, 'rect', {
            'width': '100%',
            'height': '100%',
            'fill': 'none'
        })
        
        # Safe Area Base Container
        safe_zone_size = self.canvas_size - (2 * self.margin)
        g = ET.SubElement(svg, 'g', {
            'transform': f'translate({self.margin}, {self.margin})'
        })
        
        # Emblem / Monogram Placeholder (Replace with Bank Symbol Vector)
        ET.SubElement(g, 'circle', {
            'cx': str(safe_zone_size // 2),
            'cy': str(safe_zone_size // 2),
            'r': str(safe_zone_size // 2 - 10),
            'fill': self.primary_hex
        })
        
        tree = ET.ElementTree(svg)
        ET.indent(tree, space="  ")
        tree.write(output_path, encoding='utf-8', xml_declaration=True)
        print(f"[+] Generated SVG Logo: {output_path}")

    def generate_png_logo(self, output_path: str):
        """Renders high-res 660x660 32-bit RGBA PNG."""
        img = Image.new('RGBA', (self.canvas_size, self.canvas_size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        # Calculate Safe Bounds
        left = self.margin
        top = self.margin
        right = self.canvas_size - self.margin
        bottom = self.canvas_size - self.margin
        
        # Draw Circular Bank Emblem inside Safe Zone
        draw.ellipse([left + 10, top + 10, right - 10, bottom - 10], fill=self.primary_hex)
        
        img.save(output_path, 'PNG')
        print(f"[+] Generated PNG Logo: {output_path}")

if __name__ == "__main__":
    os.makedirs("output_assets", exist_ok=True)
    generator = GoogleWalletBankIconGenerator(brand_name="GlobalBank", primary_hex="#0F52BA")
    
    generator.generate_svg_logo("output_assets/globalbank_660x660_logo.svg")
    generator.generate_png_logo("output_assets/globalbank_660x660_logo.png")