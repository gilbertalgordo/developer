import os
from PIL import Image, ImageDraw

def create_bank_wallet_asset(
    output_path: str,
    brand_color_hex: str = "#0F52BA",
    size: int = 320,
    padding: int = 60
):
    """
    Generates a Google Wallet API compliant 320x320 PNG asset for Bank Push Provisioning.
    Per Google Spec: 320x320px with 60px padding safe-zone (200x200px artwork area).
    """
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Safe artwork area calculation
    left = padding
    top = padding
    right = size - padding
    bottom = size - padding

    # Draw bank emblem within the 200x200px safe boundary
    draw.ellipse([left, top, right, bottom], fill=brand_color_hex)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    img.save(output_path, "PNG")
    print(f"Asset created: {output_path}")

if __name__ == "__main__":
    create_bank_wallet_asset("assets/acmebank_320x320_color_padding.png")