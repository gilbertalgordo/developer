import base64
import json
import os
import time
from flask import Flask, request, jsonify
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

app = Flask(__name__)

class UnifiedPushProvisioningEngine:
    """
    Bank-grade Core Engine implementing Unified Android Push Provisioning (UAPP) specs.
    Constructs the encrypted opaque payment card payload for Google Wallet SDK.
    """
    def __init__(self, bank_private_key_pem: bytes, google_public_key_pem: bytes):
        self.bank_private_key = serialization.load_pem_private_key(
            bank_private_key_pem, password=None
        )
        self.google_public_key = serialization.load_pem_public_key(
            google_public_key_pem
        )

    def generate_opaque_payload(
        self, 
        pan: str, 
        cvv: str, 
        exp_month: str, 
        exp_year: str, 
        cardholder_name: str, 
        wallet_id: str
    ) -> bytes:
        """
        Creates a dual-layer encrypted blob containing sensitive cardholder details,
        signed by the bank and encrypted with Google's UAPP Transport Key.
        """
        raw_card_data = {
            "pan": pan,
            "cvv2": cvv,
            "expirationMonth": exp_month,
            "expirationYear": exp_year,
            "cardholderName": cardholder_name,
            "clientAppId": "com.bank.mobile.android",
            "walletId": wallet_id,
            "timestamp": int(time.time() * 1000)
        }
        
        serialized_json = json.dumps(raw_card_data).encode('utf-8')

        # 1. Sign data using Bank Private Key (RSA-PSS with SHA256)
        signature = self.bank_private_key.sign(
            serialized_json,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )

        signed_payload = {
            "data": base64.b64encode(serialized_json).decode('utf-8'),
            "signature": base64.b64encode(signature).decode('utf-8')
        }

        payload_bytes = json.dumps(signed_payload).encode('utf-8')

        # 2. Hybrid AES-GCM + RSA OAEP Encryption for Google Transport Key
        aes_key = os.urandom(32)
        iv = os.urandom(12)

        cipher = Cipher(algorithms.AES(aes_key), modes.GCM(iv))
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(payload_bytes) + encryptor.finalize()

        encrypted_aes_key = self.google_public_key.encrypt(
            aes_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        final_structure = {
            "encryptedEphemeralKey": base64.b64encode(encrypted_aes_key).decode('utf-8'),
            "iv": base64.b64encode(iv).decode('utf-8'),
            "encryptedData": base64.b64encode(ciphertext).decode('utf-8'),
            "tag": base64.b64encode(encryptor.tag).decode('utf-8')
        }

        return base64.b64encode(json.dumps(final_structure).encode('utf-8'))

# API Route Endpoint for Mobile App Request
@app.route('/api/v1/wallet/provision-payload', methods=['POST'])
def provision_card():
    body = request.get_json()
    
    # Validation check
    required_fields = ["pan", "cvv", "exp_month", "exp_year", "name", "wallet_id"]
    if not all(field in body for field in required_fields):
        return jsonify({"error": "Missing mandatory field"}), 400

    # Load institutional keypairs (In production, load from HSM or KMS)
    with open("config/bank_private.pem", "rb") as f:
        bank_priv = f.read()
    with open("config/google_uapp_public.pem", "rb") as f:
        google_pub = f.read()

    engine = UnifiedPushProvisioningEngine(bank_priv, google_pub)
    
    opaque_blob = engine.generate_opaque_payload(
        pan=body["pan"],
        cvv=body["cvv"],
        exp_month=body["exp_month"],
        exp_year=body["exp_year"],
        cardholder_name=body["name"],
        wallet_id=body["wallet_id"]
    )

    return jsonify({
        "status": "APPROVED",
        "opaquePayload": opaque_blob.decode('utf-8')
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8443, ssl_context='adhoc')