import base64
import json
import os
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.serialization import load_pem_private_key

class BankWalletProvisioningEngine:
    """
    Standalone core engine for banking partners to provision payment tokens 
    directly into Google Wallet, bypassing consumer payment wrappers.
    """
    def __init__(self, issuer_id: str, private_key_path: str):
        self.issuer_id = issuer_id
        self.private_key_path = private_key_path
        self._load_credentials()

    def _load_credentials(self):
        if os.path.exists(self.private_key_path):
            with open(self.private_key_path, "rb") as key_file:
                self.private_key = load_pem_private_key(
                    key_file.read(),
                    password=None
                )
        else:
            raise FileNotFoundError(f"Issuer cryptographic key not found at: {self.private_key_path}")

    def generate_provisioning_payload(self, cardholder_name: str, opaque_card_ref: str, client_device_id: str) -> dict:
        """
        Constructs the secure provisioning payload object for token request.
        """
        payload = {
            "issuerId": self.issuer_id,
            "deviceIdentifier": client_device_id,
            "cardHolderName": cardholder_name,
            "cardReferenceId": opaque_card_ref,
            "tokenizationSource": "BANK_CORE_DIRECT",
            "timestamp": os.getenv("EPOCH_TIME", "1750000000")
        }
        
        serialized_payload = json.dumps(payload).encode('utf-8')
        encrypted_blob = self._encrypt_payload(serialized_payload)

        return {
            "status": "SUCCESS",
            "issuerContext": self.issuer_id,
            "encryptedTokenPayload": encrypted_blob
        }

    def _encrypt_payload(self, data: bytes) -> str:
        """
        Encrypts payload using institutional RSA keys established 
        during the Issuer Console onboarding phase.
        """
        encrypted = self.private_key.sign(
            data,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return base64.b64encode(encrypted).decode('utf-8')

if __name__ == "__main__":
    ISSUER_CONFIG_ID = "BANK-ISSUER-GLOBAL-9988"
    PRIVATE_KEY_FILE = "config/issuer_private_key.pem"
    
    try:
        engine = BankWalletProvisioningEngine(
            issuer_id=ISSUER_CONFIG_ID,
            private_key_path=PRIVATE_KEY_FILE
        )
        
        sample_request = engine.generate_provisioning_payload(
            cardholder_name="A. Designated Account Holder",
            opaque_card_ref="CRN-8849-XYZ-001",
            client_device_id="DEV-ANDROID-NFC-9911"
        )
        
        print("Secure Issuer Token Payload Generated:")
        print(json.dumps(sample_request, indent=2))
        
    except Exception as e:
        print(f"Provisioning halted: {e}")