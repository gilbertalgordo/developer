# Google Wallet Push Provisioning Integration Pack (UAPP)

This package contains the complete production-grade source code, Android Jetpack Compose badges, Vector Drawables, and cryptographic engines for Google Wallet Push Provisioning.

## Folder Structure:
- **/backend**:
  - `UnifiedPushProvisioningEngine.py` (Flask API + Dual-layer RSA/AES-GCM encryption)
  - `BankWalletProvisioningEngine.py` (Standalone core direct provisioning)
- **/android**:
  - `BankPushProvisioningService.kt` (Google Play Services TapAndPay client integration)
  - `AddToGoogleWalletButton.kt` (Compliant Jetpack Compose Button)
  - `add_to_google_wallet_button.xml` (Android Vector Drawable)
- **/assets**:
  - `GoogleWalletBankIconGenerator.py` (660x660 / 320x320 15% safe area generator)
  - `create_bank_wallet_asset.py`
- **google_wallet_zip.yaml**: Specification and OpenAPI architecture definition.

## Quick Start
1. Install Python dependencies:
   ```bash
   pip install flask cryptography pillow
   ```
2. Run backend API:
   ```bash
   python backend/UnifiedPushProvisioningEngine.py
   ```
3. In Android project, include:
   `implementation("com.google.android.gms:play-services-tapandpay:18.4.0")`
