package com.bank.wallet.provisioning

import android.app.Activity
import android.content.Context
import com.google.android.gms.tapandpay.TapAndPay
import com.google.android.gms.tapandpay.TapAndPayClient
import com.google.android.gms.tapandpay.issuer.IsTokenizedRequest
import com.google.android.gms.tapandpay.issuer.PushTokenizeRequest
import com.google.android.gms.tapandpay.issuer.UserAddress
import com.google.android.gms.tasks.Task

class BankPushProvisioningService(private val activity: Activity) {

    private val tapAndPayClient: TapAndPayClient = TapAndPay.getClient(activity)
    
    companion object {
        const val REQUEST_CODE_PUSH_TOKENIZE = 9001
        const val CARD_NETWORK_VISA = TapAndPay.CARD_NETWORK_VISA
        const val CARD_NETWORK_MASTERCARD = TapAndPay.CARD_NETWORK_MASTERCARD
        const val CARD_NETWORK_AMEX = TapAndPay.CARD_NETWORK_AMEX
    }

    /**
     * Checks if the target card has already been tokenized on this device.
     */
    fun checkCardTokenState(lastFourDigits: String, network: Int, callback: (Boolean) -> Unit) {
        val request = IsTokenizedRequest.Builder()
            .setIdentifier(lastFourDigits)
            .setNetwork(network)
            .build()

        tapAndPayClient.isTokenized(request)
            .addOnSuccessListener { isTokenized -> callback(isTokenized) }
            .addOnFailureListener { callback(false) }
    }

    /**
     * Obtains the Google Wallet Active Wallet ID (Stable Hardware Identifier)
     * required by the bank backend for payload target encryption.
     */
    fun fetchWalletId(onSuccess: (String) -> Unit, onFailure: (Exception) -> Unit) {
        tapAndPayClient.activeWalletId
            .addOnSuccessListener { walletId -> onSuccess(walletId) }
            .addOnFailureListener { exception -> onFailure(exception) }
    }

    /**
     * Triggers the direct OS-level Google Wallet Push Provisioning Flow.
     */
    fun executePushTokenize(
        opaquePayload: ByteArray,
        cardLastFour: String,
        cardholderName: String,
        network: Int,
        tokenServiceProvider: Int = TapAndPay.TOKEN_PROVIDER_VISA
    ) {
        val pushTokenizeRequest = PushTokenizeRequest.Builder()
            .setOpaquePaymentCard(opaquePayload)
            .setNetwork(network)
            .setTokenServiceProvider(tokenServiceProvider)
            .setDisplayName("Bank Direct Debit / Credit")
            .setLastDigits(cardLastFour)
            .setUserAddress(
                UserAddress.newBuilder()
                    .setName(cardholderName)
                    .setCountryCode("US")
                    .build()
            )
            .build()

        tapAndPayClient.pushTokenize(activity, pushTokenizeRequest, REQUEST_CODE_PUSH_TOKENIZE)
    }
}