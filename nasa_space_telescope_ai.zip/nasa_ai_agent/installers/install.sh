#!/bin/bash
echo "Installing NASA Space Telescope Active AI Agent..."
python3 -m pip install --upgrade pip
pip install numpy requests
echo "Installation complete. Run python3 -m nasa_ai_agent.core.telemetry_monitor to start."
