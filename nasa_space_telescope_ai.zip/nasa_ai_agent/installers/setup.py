from setuptools import setup, find_packages

setup(
    name="nasa_space_telescope_ai",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.20.0",
        "requests>=2.25.0"
    ],
    entry_points={
        "console_scripts": [
            "nasa-ai-run=nasa_ai_agent.core.telemetry_monitor:main",
        ],
    },
    author="Gilbert Algordo",
    description="Active AI system for NASA space telescopes",
)
