# Telemetry monitoring and real-time active AI logic
class TelescopeTelemetryAgent:
    def __init__(self, telescope_name="James Webb / Nancy Grace Roman"):
        self.telescope_name = telescope_name

    def analyze_stream(self, data_packet):
        print(f"[{self.telescope_name}] Analyzing incoming telemetry data packet...")
        # Active AI inference placeholder for drift or anomaly correction
        if data_packet.get("anomaly_detected", False):
            return "ALERT: Autonomous course/calibration correction initiated."
        return "Telemetry stable. Continuing deep-space observation scan."


if __name__ == "__main__":
    agent = TelescopeTelemetryAgent("JWST L2 Spacecraft")
    print(agent.analyze_stream({"photon_flux": 1400.2, "anomaly_detected": False}))
    print(agent.analyze_stream({"photon_flux": 3200.8, "anomaly_detected": True}))
