import os
import zipfile

# Manifest & configuration files
FILES = {
    "requirements.txt": "fastapi>=0.110.0\nuvicorn>=0.28.0\nllama-cpp-python>=0.2.50\npsutil>=5.9.0\npydantic>=2.0.0\n",
    "manifest.json": """{
    "project": "Google AI Master Offline",
    "version": "2.4.0",
    "developer_url": "https://g.dev/gilbert_algordo",
    "execution_mode": "100% Offline Local Engine",
    "recommended_models": ["gemma-2-2b-it.Q4_K_M.gguf", "gemma-2-9b-it.Q4_K_M.gguf"]
}""",
    "run.sh": """#!/bin/bash
pip install -r requirements.txt
python server.py
""",
    "run.bat": """@echo off
pip install -r requirements.txt
python server.py
pause
"""
}

def build_zip():
    zip_name = "google-ai-master-offline.zip"
    print(f"[*] Building ZIP distribution package: {zip_name}")

    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Write auto-generated config/requirements files
        for fname, content in FILES.items():
            zipf.writestr(fname, content)
            print(f"  + Added {fname}")

        # Write core application files
        for app_file in ["server.py", "index.html"]:
            if os.path.exists(app_file):
                zipf.write(app_file)
                print(f"  + Added {app_file}")

    print(f"\n[+] Bundle successfully created: {zip_name}")

if __name__ == "__main__":
    build_zip()