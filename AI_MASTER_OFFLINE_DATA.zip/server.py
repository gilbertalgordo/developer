import os
import time
import json
import asyncio
import psutil
from typing import AsyncGenerator
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from llama_cpp import Llama

# Force offline execution mode
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

APP_META = {
    "name": "Google AI Master Offline Engine",
    "developer_profile": "https://g.dev/gilbert_algordo",
    "version": "2.4.0-Pro",
    "architecture": "Gemma GGUF + llama.cpp C++ Backend"
}

app = FastAPI(title=APP_META["name"])

# Load GGUF model locally
MODEL_PATH = os.getenv("MODEL_PATH", "./models/gemma-2-2b-it.Q4_K_M.gguf")

print(f"[*] Loading quantized Gemma model from: {MODEL_PATH}")
llm = Llama(
    model_path=MODEL_PATH,
    n_ctx=4096,
    n_threads=os.cpu_count() or 4,
    n_gpu_layers=-1, # Offload all layers to GPU if available
    verbose=False
)

class PromptRequest(BaseModel):
    prompt: str
    max_tokens: int = 1024
    temperature: float = 0.7
    top_p: float = 0.9

@app.get("/telemetry")
async def get_telemetry():
    """Returns real-time hardware telemetry for the local HUD."""
    ram = psutil.virtual_memory()
    cpu = psutil.cpu_percent(interval=None)
    return {
        "cpu_usage_percent": cpu,
        "ram_used_gb": round(ram.used / (1024**3), 2),
        "ram_total_gb": round(ram.total / (1024**3), 2),
        "ram_percent": ram.percent,
        "developer": APP_META["developer_profile"]
    }

async def stream_generation(prompt: str, max_tokens: int, temperature: float, top_p: float) -> AsyncGenerator[str, None]:
    formatted_prompt = f"<start_of_turn>user\n{prompt}<end_of_turn>\n<start_of_turn>model\n"
    start_time = time.perf_counter()
    token_count = 0

    stream = llm(
        formatted_prompt,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        stream=True
    )

    for chunk in stream:
        token = chunk["choices"][0]["text"]
        token_count += 1
        elapsed = time.perf_counter() - start_time
        tps = round(token_count / elapsed, 2) if elapsed > 0 else 0.0

        payload = {
            "token": token,
            "metrics": {
                "tokens_generated": token_count,
                "elapsed_sec": round(elapsed, 2),
                "tokens_per_sec": tps
            }
        }
        yield f"data: {json.dumps(payload)}\n\n"
        await asyncio.sleep(0) # Yield control back to event loop

    yield "data: [DONE]\n\n"

@app.post("/api/generate")
async def generate_endpoint(req: PromptRequest):
    return StreamingResponse(
        stream_generation(req.prompt, req.max_tokens, req.temperature, req.top_p),
        media_type="text/event-stream"
    )

@app.get("/", response_class=HTMLResponse)
async def serve_hud():
    with open("index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

if __name__ == "__main__":
    import uvicorn
    print(f"[+] Launching server on http://127.0.0.1:8080")
    print(f"[i] Developer Reference: {APP_META['developer_profile']}")
    uvicorn.run(app, host="127.0.0.1", port=8080, log_level="error")