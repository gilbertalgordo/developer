import os
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_NAME = "google/gemma-2b-it"
SAVE_DIR = "./models/gemma"

def download_and_save():
    print(f"Downloading {MODEL_NAME} for offline deployment...")
    os.makedirs(SAVE_DIR, exist_ok=True)
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    tokenizer.save_pretrained(SAVE_DIR)
    
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
    model.save_pretrained(SAVE_DIR)
    
    print(f"[+] Download complete. Saved to '{SAVE_DIR}'. Ready for offline usage.")

if __name__ == "__main__":
    download_and_save()