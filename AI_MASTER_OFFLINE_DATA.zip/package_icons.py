import os
import zipfile
import json

ZIP_FILENAME = "google-ai-master-icons.zip"
SRC_DIR = "./generated_icons"

MANIFEST_DATA = {
    "name": "Google AI Master Offline Mode - Icon Pack",
    "developer": "https://g.dev/gilbert_algordo",
    "theme": "HUD Dark Cyber / Emerald Neon",
    "formats": ["SVG", "PNG", "ICO"],
    "resolutions": ["16x16", "32x32", "48x48", "64x64", "128x128", "256x256", "512x512"]
}

def package_bundle():
    print(f"[*] Packaging assets into archive: {ZIP_FILENAME}")
    with zipfile.ZipFile(ZIP_FILENAME, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.writestr("manifest.json", json.dumps(MANIFEST_DATA, indent=2))
        print("  + Added manifest.json")
        for root, _, files in os.walk(SRC_DIR):
            for file in files:
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, SRC_DIR)
                zipf.write(filepath, arcname)
                print(f"  + Compressed: {arcname}")
    print(f"\n[+] Archive successfully generated: {ZIP_FILENAME}")

if __name__ == "__main__":
    package_bundle()