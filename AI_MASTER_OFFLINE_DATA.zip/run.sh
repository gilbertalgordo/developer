#!/bin/bash
echo "=== Google AI Master - Offline Engine Starting ==="
pip install -r requirements.txt
python server.py
