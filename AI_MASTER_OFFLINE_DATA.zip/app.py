import os
import sys
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, TextStreamer

class OfflineGoogleAI:
    def __init__(self, model_id: str = "google/gemma-2b-it", local_dir: str = "./models/gemma"):
        self.model_id = model_id
        self.local_dir = local_dir
        self.tokenizer = None
        self.model = None

    def initialize_model(self):
        """Loads model weights locally from cached directory or Hugging Face local store."""
        print(f"[*] Initializing local engine using model path: {self.local_dir}")
        
        # Force offline mode for HuggingFace Transformers
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

        try:
            target_path = self.local_dir if os.path.exists(self.local_dir) else self.model_id
            
            self.tokenizer = AutoTokenizer.from_pretrained(target_path, local_files_only=True)
            self.model = AutoModelForCausalLM.from_pretrained(
                target_path,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                device_map="auto" if torch.cuda.is_available() else "cpu",
                local_files_only=True
            )
            print("[+] Model successfully loaded in offline mode.")
        except Exception as e:
            print(f"[-] Error loading offline model: {e}")
            print("[i] Ensure weights are saved to './models/gemma' or cached in HF store.")
            sys.exit(1)

    def generate_response(self, prompt: str, max_new_tokens: int = 512, temperature: float = 0.7):
        """Generates streaming text output strictly offline."""
        if not self.model or not self.tokenizer:
            raise RuntimeError("Model engine not initialized. Call initialize_model() first.")

        # Format prompt according to Gemma instruction template
        formatted_prompt = f"<start_of_turn>user\n{prompt}<end_of_turn>\n<start_of_turn>model\n"
        
        inputs = self.tokenizer(formatted_prompt, return_tensors="pt").to(self.model.device)
        streamer = TextStreamer(self.tokenizer, skip_prompt=True)

        print("\n--- AI Output ---")
        self.model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            do_sample=True if temperature > 0 else False,
            streamer=streamer
        )
        print("\n-----------------\n")

def main():
    ai = OfflineGoogleAI()
    ai.initialize_model()

    print("\nGoogle AI Master - Offline Mode Ready. Type 'exit' or 'quit' to close.\n")
    while True:
        try:
            user_input = input("You > ")
            if user_input.strip().lower() in ["exit", "quit"]:
                break
            if user_input.strip():
                ai.generate_response(user_input)
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()