# Google AI Master // Offline Mode

Developer: **Gilbert Algordo**
Profile: [https://g.dev/gilbert_algordo](https://g.dev/gilbert_algordo)
Architecture: Gemma GGUF + llama.cpp C++ Engine / HF Transformers Offline

## 🚀 Quick Start

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Download Gemma model weights** (Initial one-time setup):
   ```bash
   python download_weights.py
   ```

3. **Launch Offline HUD Engine**:
   ```bash
   python server.py
   ```
   Then open `http://127.0.0.1:8080` in any browser (no internet required).

4. **Launch Command-Line Offline Engine**:
   ```bash
   python app.py
   ```

## 📦 Features
- 100% Zero-Cloud Network Isolation (`HF_HUB_OFFLINE=1`)
- Real-time Hardware Telemetry HUD (CPU load, RAM consumption, Token Latency)
- Server-Sent Events (SSE) token streamer
- Quantized Gemma 2B / 9B GGUF acceleration
