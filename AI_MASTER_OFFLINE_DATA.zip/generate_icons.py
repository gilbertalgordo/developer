import os
import zipfile
from PIL import Image, ImageDraw, ImageFont

# Metadata Configuration
DEV_URL = "https://g.dev/gilbert_algordo"
APP_TITLE = "Google AI Master Offline Mode"
OUTPUT_DIR = "./generated_icons"

SVG_ICON = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <metadata>
    <developer>https://g.dev/gilbert_algordo</developer>
    <application>Google AI Master Offline Mode</application>
  </metadata>

  <defs>
    <radialGradient id="bgGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#161b22"/>
      <stop offset="100%" stop-color="#090d12"/>
    </radialGradient>

    <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feMerge>
        <feMergeNode in="blur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>

    <linearGradient id="borderGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="50%" stop-color="#10b981"/>
      <stop offset="100%" stop-color="#1e293b"/>
    </linearGradient>
  </defs>

  <rect width="512" height="512" rx="100" fill="url(#bgGrad)" stroke="url(#borderGrad)" stroke-width="8"/>

  <circle cx="256" cy="256" r="190" fill="none" stroke="#30363d" stroke-width="3" stroke-dasharray="12, 8"/>
  <circle cx="256" cy="256" r="160" fill="none" stroke="#38bdf8" stroke-width="1.5" opacity="0.4"/>

  <line x1="256" y1="36" x2="256" y2="66" stroke="#38bdf8" stroke-width="4"/>
  <line x1="256" y1="446" x2="256" y2="476" stroke="#38bdf8" stroke-width="4"/>
  <line x1="36" y1="256" x2="66" y2="256" stroke="#38bdf8" stroke-width="4"/>
  <line x1="446" y1="256" x2="476" y2="256" stroke="#38bdf8" stroke-width="4"/>

  <g filter="url(#neonGlow)">
    <polygon points="256,120 356,220 256,320 156,220" fill="none" stroke="#38bdf8" stroke-width="6"/>
    <polygon points="256,150 326,220 256,290 186,220" fill="none" stroke="#10b981" stroke-width="4" stroke-dasharray="6, 4"/>
    <circle cx="256" cy="220" r="24" fill="#38bdf8"/>
  </g>

  <g transform="translate(0, 40)">
    <path d="M256,310 L316,340 V390 C316,425 256,450 256,450 C256,450 196,425 196,390 V340 Z" 
          fill="#0d1117" stroke="#10b981" stroke-width="5" filter="url(#neonGlow)"/>
    <polygon points="258,350 242,380 256,380 252,410 270,375 256,375" fill="#10b981"/>
  </g>

  <text x="256" y="482" text-anchor="middle" fill="#94a3b8" font-family="monospace" font-size="14" letter-spacing="2">GOOGLE AI MASTER // OFFLINE</text>
</svg>"""

def draw_raster_icon(size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    scale = size / 512.0
    pad = int(10 * scale)
    
    # Outer dark body
    draw.rounded_rectangle([pad, pad, size - pad, size - pad], radius=int(80 * scale), fill=(15, 23, 42, 255), outline=(56, 189, 248, 255), width=max(1, int(6 * scale)))
    
    # HUD Circles
    center = size // 2
    r1 = int(160 * scale)
    draw.ellipse([center - r1, center - r1, center + r1, center + r1], outline=(48, 54, 61, 255), width=max(1, int(3 * scale)))
    
    # Core Diamond
    r2 = int(90 * scale)
    pts = [
        (center, center - r2),
        (center + r2, center),
        (center, center + r2),
        (center - r2, center)
    ]
    draw.polygon(pts, outline=(16, 185, 129, 255), width=max(1, int(4 * scale)))
    
    # Inner Core
    r3 = int(20 * scale)
    draw.ellipse([center - r3, center - r3, center + r3, center + r3], fill=(56, 189, 248, 255))
    
    return img

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # 1. Save Master SVG
    svg_path = os.path.join(OUTPUT_DIR, "icon-master.svg")
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(SVG_ICON)
    print(f"[+] Exported Master Vector: {svg_path}")

    # 2. Render PNG Formats
    sizes = [16, 32, 48, 64, 128, 256, 512]
    png_images = []
    
    for s in sizes:
        img = draw_raster_icon(s)
        out_png = os.path.join(OUTPUT_DIR, f"icon-{s}x{s}.png")
        img.save(out_png, "PNG")
        png_images.append(img)
        print(f"[+] Rendered PNG Asset: {out_png}")

    # 3. Export Windows ICO File
    ico_path = os.path.join(OUTPUT_DIR, "favicon.ico")
    png_images[0].save(
        ico_path,
        format="ICO",
        sizes=[(s, s) for s in [16, 32, 48, 64, 128, 256]]
    )
    print(f"[+] Generated Multi-Resolution ICO: {ico_path}")

if __name__ == "__main__":
    main()