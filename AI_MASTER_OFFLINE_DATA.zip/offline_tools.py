#!/usr/bin/env python3
"""
Offline Developer Tools & Utilities Workbench
Google AI Master - Air-Gap Toolkit
Developer: Gilbert Algordo (https://g.dev/gilbert_algordo)
"""

import sys
import os
import hashlib
import argparse

def calculate_vram(model_size_b: float, quant_bits: float = 4.5, context_len: int = 4096) -> dict:
    """Calculates memory requirements for GGUF models."""
    weight_gb = (model_size_b * quant_bits) / 8.0
    kv_cache_gb = (context_len / 4096.0) * (0.8 if model_size_b > 8.0 else 0.25)
    overhead_gb = 0.35 + (0.5 if model_size_b > 8.0 else 0.15)
    total_ram = weight_gb + kv_cache_gb + overhead_gb
    return {
        "model_weights_gb": round(weight_gb, 2),
        "kv_cache_gb": round(kv_cache_gb, 2),
        "overhead_gb": round(overhead_gb, 2),
        "total_ram_required_gb": round(total_ram, 2)
    }

def format_gemma_prompt(user_query: str, system_prompt: str = "") -> str:
    """Formats prompt with exact Gemma turn control tokens."""
    if system_prompt:
        return f"<start_of_turn>user\n[System: {system_prompt.strip()}]\n\n{user_query.strip()}<end_of_turn>\n<start_of_turn>model\n"
    return f"<start_of_turn>user\n{user_query.strip()}<end_of_turn>\n<start_of_turn>model\n"

def sha256_hash(filepath_or_text: str) -> str:
    """Computes SHA-256 for a file or raw string."""
    if os.path.exists(filepath_or_text):
        h = hashlib.sha256()
        with open(filepath_or_text, "rb") as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()
    return hashlib.sha256(filepath_or_text.encode('utf-8')).hexdigest()

def verify_airgap() -> bool:
    """Verifies air-gap offline environment variables."""
    hf_offline = os.environ.get("HF_HUB_OFFLINE") == "1"
    tf_offline = os.environ.get("TRANSFORMERS_OFFLINE") == "1"
    print(f"HF_HUB_OFFLINE=1: {'[OK]' if hf_offline else '[WARN: NOT SET]'}")
    print(f"TRANSFORMERS_OFFLINE=1: {'[OK]' if tf_offline else '[WARN: NOT SET]'}")
    return hf_offline and tf_offline

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Google AI Master Air-Gap Tools")
    sub = parser.add_subparsers(dest="tool", help="Select tool")

    # VRAM Calc
    calc = sub.add_parser("vram", help="Calculate VRAM requirement")
    calc.add_argument("--size", type=float, default=2.5, help="Model parameters in billions (e.g. 2.5, 7.2, 9.2)")
    calc.add_argument("--bpw", type=float, default=4.5, help="Bits per weight (e.g. 4.5 for Q4_K_M)")
    calc.add_argument("--ctx", type=int, default=4096, help="Context length")

    # Prompt Formatter
    fmt = sub.add_parser("prompt", help="Format Gemma prompt")
    fmt.add_argument("query", help="User input text")
    fmt.add_argument("--system", default="", help="Optional system instruction")

    # Hasher
    hasher = sub.add_parser("hash", help="SHA-256 hash a file or text")
    hasher.add_argument("target", help="File path or text string")

    # Airgap audit
    sub.add_parser("audit", help="Verify airgap environment flags")

    args = parser.parse_args()
    if args.tool == "vram":
        print(calculate_vram(args.size, args.bpw, args.ctx))
    elif args.tool == "prompt":
        print(format_gemma_prompt(args.query, args.system))
    elif args.tool == "hash":
        print(f"SHA-256: {sha256_hash(args.target)}")
    elif args.tool == "audit":
        verify_airgap()
    else:
        parser.print_help()