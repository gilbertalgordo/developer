// Tactical Cyber Audio Synthesizer via Web Audio API
class TacticalAudio {
  private ctx: AudioContext | null = null;
  public isMuted: boolean = false;

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public playTone(freq: number, type: OscillatorType, duration: number, gainValue: number = 0.08) {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(gainValue, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch {
      // Ignore audio autoplay restrictions gracefully
    }
  }

  // Tactical click / radar blip
  public playBlip() {
    this.playTone(880, 'sine', 0.05, 0.04);
  }

  // Scan chirp
  public playChirp() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1320, this.ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.12);
    } catch {
      // Ignore
    }
  }

  // Subnet exploit / override activation
  public playOverride() {
    this.playTone(330, 'sawtooth', 0.15, 0.06);
    setTimeout(() => this.playTone(660, 'sawtooth', 0.2, 0.06), 120);
    setTimeout(() => this.playTone(990, 'sine', 0.25, 0.07), 240);
  }

  // Dispatch alert
  public playDispatch() {
    this.playTone(587.33, 'triangle', 0.1, 0.07);
    setTimeout(() => this.playTone(880, 'sine', 0.15, 0.08), 80);
  }

  // Threat alarm
  public playAlarm() {
    this.playTone(900, 'sawtooth', 0.15, 0.09);
    setTimeout(() => this.playTone(700, 'sawtooth', 0.2, 0.09), 160);
  }

  // Expansion activated sound
  public playExpansionEngaged() {
    this.playTone(440, 'triangle', 0.1, 0.06);
    setTimeout(() => this.playTone(554.37, 'triangle', 0.1, 0.06), 90);
    setTimeout(() => this.playTone(659.25, 'triangle', 0.12, 0.07), 180);
    setTimeout(() => this.playTone(880, 'sine', 0.3, 0.08), 280);
  }

  // ZIP download sound
  public playDownloadSuccess() {
    this.playTone(523.25, 'sine', 0.08, 0.06);
    setTimeout(() => this.playTone(659.25, 'sine', 0.08, 0.06), 70);
    setTimeout(() => this.playTone(783.99, 'sine', 0.1, 0.06), 140);
    setTimeout(() => this.playTone(1046.50, 'triangle', 0.25, 0.07), 210);
  }

  // Installer prompt sound
  public playInstallPrompt() {
    this.playTone(392.00, 'triangle', 0.09, 0.06);
    setTimeout(() => this.playTone(523.25, 'triangle', 0.12, 0.07), 100);
  }
}

export const soundManager = new TacticalAudio();
