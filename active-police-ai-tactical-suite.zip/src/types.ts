export interface Incident {
  id: string;
  text: string;
  category: string;
  priority: 'HIGH' | 'NORMAL';
  status: 'PENDING' | 'DISPATCHED' | 'ON SCENE' | 'RESOLVED';
  threatScore: number; // 0 to 100
  timestamp: string;
  recommendedAction: string;
  assignedUnits: string[];
  summary: string;
  coordinates: { x: number; y: number };
  sector?: 'SECTOR-7' | 'SECTOR-8' | 'SECTOR-9';
}

export interface SensorFeed {
  id: string;
  name: string;
  type: 'CAMERA' | 'AUDIO' | 'THERMAL' | 'DRONE' | 'ANPR';
  location: string;
  lastDetectedText: string;
  riskScore: number; // 0.0 to 1.0
  timestamp: string;
  status: 'CLEAR' | 'WARNING' | 'CRITICAL';
  coordinates: { x: number; y: number };
  sector?: 'SECTOR-7' | 'SECTOR-8' | 'SECTOR-9';
}

export interface PatrolUnit {
  id: string;
  name: string;
  type: 'PATROL' | 'K9' | 'SWAT' | 'AIR_SUPPORT' | 'DRONE' | 'MARINE';
  status: 'IDLE' | 'RESPONDING' | 'ON_SCENE';
  assignedIncidentId: string | null;
  officer: string;
  coordinates: { x: number; y: number };
  speed: number; // mph
  heading: string;
  sector?: 'SECTOR-7' | 'SECTOR-8' | 'SECTOR-9';
}

export interface SystemLog {
  id: string;
  timestamp: string;
  source: 'SYSTEM' | 'AI' | 'SENSOR' | 'DISPATCH' | 'OVERRIDE' | 'EXPANSION';
  message: string;
  type: 'INFO' | 'ALERT' | 'CRITICAL';
}
