import React, { useRef, useEffect, useState } from 'react';
import { SystemLog, PatrolUnit } from '../types';
import { Terminal, Shield, Cpu, Activity, Server, Wifi, Network, CheckCircle2, Lock, Unlock, Zap } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface SystemTelemetryProps {
  logs: SystemLog[];
  units: PatrolUnit[];
  geminiActive: boolean;
  aiEngine: string;
  overriddenIPs?: string[];
  onExecuteOverride?: (ip: string) => void;
  onClearOverrides?: () => void;
  onToggleFullExpansion?: () => void;
  isFullExpansion?: boolean;
  onTriggerLockdown?: () => void;
  onAutoScan?: () => void;
  onAutoConnect?: () => void;
  onOpenInstaller?: () => void;
  onOpenZipExport?: () => void;
}

export default function SystemTelemetry({
  logs,
  units,
  geminiActive,
  aiEngine,
  overriddenIPs = [],
  onExecuteOverride,
  onClearOverrides,
  onToggleFullExpansion,
  isFullExpansion = true,
  onTriggerLockdown,
  onAutoScan,
  onAutoConnect,
  onOpenInstaller,
  onOpenZipExport,
}: SystemTelemetryProps) {
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const [cmdInput, setCmdInput] = useState('');
  const [activeTab, setActiveTab] = useState<'CONSOLE' | 'TOPOLOGY'>('CONSOLE');

  // Auto scroll logs to the bottom
  useEffect(() => {
    if (terminalEndRef.current && activeTab === 'CONSOLE') {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, activeTab]);

  const totalUnits = units.length;
  const idleUnits = units.filter(u => u.status === 'IDLE').length;
  const activeAlertsCount = logs.filter(l => l.type === 'CRITICAL').length;

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawCmd = cmdInput.trim();
    const cleanCmd = rawCmd.toLowerCase();
    if (!cleanCmd) return;

    if (cleanCmd.startsWith('override ')) {
      const targetIP = rawCmd.substring(9).trim();
      soundManager.playOverride();
      if (onExecuteOverride) {
        onExecuteOverride(targetIP);
      }
    } else if (cleanCmd === 'override' || cleanCmd === '192.168.1.1') {
      soundManager.playOverride();
      if (onExecuteOverride) {
        onExecuteOverride('192.168.1.1');
      }
    } else if (cleanCmd === 'clear' || cleanCmd === 'reset') {
      soundManager.playBlip();
      if (onClearOverrides) {
        onClearOverrides();
      }
    } else if (cleanCmd.includes('expand') || cleanCmd.includes('expansion')) {
      soundManager.playExpansionEngaged();
      if (onToggleFullExpansion) {
        onToggleFullExpansion();
      }
    } else if (cleanCmd.includes('lockdown')) {
      soundManager.playAlarm();
      if (onTriggerLockdown) {
        onTriggerLockdown();
      }
    } else if (cleanCmd.includes('scan') || cleanCmd.includes('sweep')) {
      soundManager.playChirp();
      if (onAutoScan) {
        onAutoScan();
      }
    } else if (cleanCmd.includes('deploy') || cleanCmd.includes('connect')) {
      soundManager.playDispatch();
      if (onAutoConnect) {
        onAutoConnect();
      }
    } else if (cleanCmd === 'help') {
      soundManager.playBlip();
      // Add local help command
      const helpMsg = `COMMAND DIRECTORY: "override <ip>" (e.g. override 192.168.1.1), "expand", "lockdown", "scan", "deploy all", "install", "zip", "clear".`;
      if (onExecuteOverride) {
        // Log locally
      }
    } else if (cleanCmd.includes('install') || cleanCmd === 'pwa' || cleanCmd === 'setup') {
      soundManager.playInstallPrompt();
      if (onOpenInstaller) {
        onOpenInstaller();
      }
    } else if (cleanCmd.includes('zip') || cleanCmd.includes('export') || cleanCmd.includes('download') || cleanCmd.includes('archive')) {
      soundManager.playDownloadSuccess();
      if (onOpenZipExport) {
        onOpenZipExport();
      }
    } else {
      // Default: if looks like an IP, override it
      if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(rawCmd)) {
        soundManager.playOverride();
        if (onExecuteOverride) onExecuteOverride(rawCmd);
      }
    }
    setCmdInput('');
  };

  return (
    <div className="bg-cyber-panel border border-slate-800 rounded-none p-4 font-mono shadow-xl relative flex flex-col h-full" id="system-telemetry-panel">
      {/* Title & View Switcher */}
      <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2 mb-3 uppercase tracking-widest flex justify-between items-center">
        <div className="flex items-center gap-1.5">
          <Terminal className="w-4 h-4 text-cyber-blue" />
          <span>Tactical Command & Telemetry</span>
        </div>

        {/* Console vs Topology Matrix tabs */}
        <div className="flex bg-[#0a0c12] border border-slate-800 p-0.5 text-[8px] font-bold">
          <button
            onClick={() => {
              soundManager.playBlip();
              setActiveTab('CONSOLE');
            }}
            className={`px-2 py-0.5 rounded-none transition-colors cursor-pointer flex items-center gap-1 ${
              activeTab === 'CONSOLE' ? 'bg-cyber-blue text-white font-black' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Activity className="w-3 h-3" />
            DIAGNOSTICS
          </button>
          <button
            onClick={() => {
              soundManager.playBlip();
              setActiveTab('TOPOLOGY');
            }}
            className={`px-2 py-0.5 rounded-none transition-colors cursor-pointer flex items-center gap-1 ${
              activeTab === 'TOPOLOGY' ? 'bg-cyan-600 text-white font-black' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Network className="w-3 h-3 text-cyan-400" />
            SUBNET MESH
          </button>
        </div>
      </div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        <div className="bg-cyber-bg border border-slate-800 p-2 text-center">
          <span className="text-[7.5px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">Sectors</span>
          <span className="text-[10px] font-black text-slate-200">
            {isFullExpansion ? 'S7 • S8 • S9' : 'SECTOR-7'}
          </span>
        </div>
        <div className="bg-cyber-bg border border-slate-800 p-2 text-center">
          <span className="text-[7.5px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">Engine Core</span>
          <span className={`text-[9px] font-black truncate block uppercase ${geminiActive ? 'text-cyan-400' : 'text-cyber-blue'}`}>
            {geminiActive ? 'GEMINI 3.5' : 'KAIZEN NLP'}
          </span>
        </div>
        <div className="bg-cyber-bg border border-slate-800 p-2 text-center">
          <span className="text-[7.5px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">Fleet Readiness</span>
          <span className="text-[10px] font-black text-slate-200">
            {idleUnits}/{totalUnits} <span className="text-[7.5px] text-slate-500 font-normal">IDLE</span>
          </span>
        </div>
        <div className="bg-cyber-bg border border-slate-800 p-2 text-center">
          <span className="text-[7.5px] text-slate-500 font-bold block uppercase tracking-wider mb-0.5">Threat Index</span>
          <span className={`text-[10px] font-black ${activeAlertsCount > 0 ? 'text-red-400 animate-pulse' : 'text-cyan-400'}`}>
            {activeAlertsCount > 0 ? `${activeAlertsCount} CRITICAL` : 'NOMINAL'}
          </span>
        </div>
      </div>

      {/* Interactive Subnet Manual Override Status Row */}
      <div className="mb-3 bg-cyber-bg/60 border border-slate-800 p-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div className="flex items-center gap-2">
          {overriddenIPs.length > 0 ? (
            <>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
              </span>
              <div>
                <span className="text-[8.5px] text-cyan-400 font-black block uppercase tracking-widest leading-none">
                  GATEWAY OVERRIDE ACTIVE • ROOT BYPASS
                </span>
                <span className="text-[7.5px] text-slate-400 font-bold block mt-0.5 font-mono">
                  Controlled Node: <span className="text-white font-black">{overriddenIPs.join(', ')}</span> (Port 22/80/443 Bypassed)
                </span>
              </div>
            </>
          ) : (
            <>
              <Wifi className="w-4 h-4 text-slate-500" />
              <div>
                <span className="text-[8.5px] text-slate-400 font-black block uppercase tracking-widest leading-none">
                  STANDARD FIREWALL DEFENSE
                </span>
                <span className="text-[7.5px] text-slate-600 font-bold block mt-0.5 font-mono">
                  Gateway 192.168.1.1 in default restricted isolation
                </span>
              </div>
            </>
          )}
        </div>

        <div className="flex gap-1.5 w-full sm:w-auto self-stretch sm:self-auto justify-end">
          {overriddenIPs.length > 0 ? (
            <button
              onClick={() => {
                soundManager.playBlip();
                if (onClearOverrides) onClearOverrides();
              }}
              className="text-[8px] font-black bg-cyan-950/30 border border-cyan-500/60 text-cyan-400 hover:bg-cyan-950/50 transition-colors cursor-pointer rounded-none px-2 py-1 uppercase"
            >
              Release Override
            </button>
          ) : (
            <button
              onClick={() => {
                soundManager.playOverride();
                if (onExecuteOverride) onExecuteOverride('192.168.1.1');
              }}
              className="text-[8px] font-black bg-blue-950/30 border border-cyber-blue text-cyber-blue hover:bg-blue-900/40 transition-colors cursor-pointer rounded-none px-2.5 py-1 uppercase shadow-[0_0_8px_rgba(59,130,246,0.3)]"
            >
              Override 192.168.1.1
            </button>
          )}
        </div>
      </div>

      {/* Main Body: Console Logs OR Subnet Topology Matrix */}
      {activeTab === 'CONSOLE' ? (
        <div className="flex-1 flex flex-col min-h-[140px] bg-[#030406] border border-slate-800 rounded-none overflow-hidden">
          <div className="bg-[#0a0c12]/80 border-b border-slate-800 px-3 py-1 flex justify-between items-center text-[7.5px] text-slate-500 font-bold uppercase tracking-wider">
            <span className="flex items-center gap-1 text-cyber-blue">
              <Activity className="w-3 h-3" />
              Live Diagnostic Event Stream
            </span>
            <span>Buffer Sync 100%</span>
          </div>

          {/* Console logs list */}
          <div className="flex-1 overflow-y-auto p-2.5 text-[8.5px] font-mono leading-tight flex flex-col gap-1.5 max-h-[160px] bg-cyber-bg/90 pr-1">
            {logs.map((log) => {
              const isCritical = log.type === 'CRITICAL';
              const isAlert = log.type === 'ALERT';
              return (
                <div key={log.id} className="flex gap-2 items-start border-b border-slate-900/40 pb-1">
                  <span className="text-slate-600 font-bold select-none whitespace-nowrap">
                    [{log.timestamp}]
                  </span>
                  <span className={`uppercase font-bold shrink-0 text-[7.5px] px-1 py-0.2 rounded-none border ${
                    isCritical 
                      ? 'border-red-500/40 bg-red-950/30 text-red-400' 
                      : isAlert 
                        ? 'border-amber-500/40 bg-amber-950/30 text-amber-400' 
                        : log.source === 'EXPANSION'
                          ? 'border-cyan-500/40 bg-cyan-950/30 text-cyan-400'
                          : 'border-blue-500/30 bg-blue-950/20 text-blue-400'
                  }`}>
                    {log.source}
                  </span>
                  <span className="text-slate-300 flex-1 leading-normal font-mono break-all font-medium">
                    {log.message}
                  </span>
                </div>
              );
            })}
            <div ref={terminalEndRef} />
          </div>

          {/* Quick Command Suggestions */}
          <div className="bg-[#04060a] border-t border-slate-800 px-2 py-1 flex flex-wrap gap-1 items-center text-[7.5px]">
            <span className="text-slate-500 uppercase font-black mr-1">QUICK:</span>
            <button
              type="button"
              onClick={() => {
                soundManager.playOverride();
                if (onExecuteOverride) onExecuteOverride('192.168.1.1');
              }}
              className="text-cyan-400 hover:text-cyan-300 bg-cyan-950/20 border border-cyan-500/30 px-1.5 py-0.5 uppercase cursor-pointer"
            >
              override 192.168.1.1
            </button>
            <button
              type="button"
              onClick={() => {
                soundManager.playExpansionEngaged();
                if (onToggleFullExpansion) onToggleFullExpansion();
              }}
              className="text-blue-400 hover:text-blue-300 bg-blue-950/20 border border-blue-500/30 px-1.5 py-0.5 uppercase cursor-pointer"
            >
              {isFullExpansion ? 'disable expansion' : 'enable full expansion'}
            </button>
            <button
              type="button"
              onClick={() => {
                soundManager.playChirp();
                if (onAutoScan) onAutoScan();
              }}
              className="text-amber-400 hover:text-amber-300 bg-amber-950/20 border border-amber-500/30 px-1.5 py-0.5 uppercase cursor-pointer"
            >
              auto scan
            </button>
            <button
              type="button"
              onClick={() => {
                soundManager.playInstallPrompt();
                if (onOpenInstaller) onOpenInstaller();
              }}
              className="text-emerald-400 hover:text-emerald-300 bg-emerald-950/20 border border-emerald-500/30 px-1.5 py-0.5 uppercase cursor-pointer"
            >
              installer
            </button>
            <button
              type="button"
              onClick={() => {
                soundManager.playDownloadSuccess();
                if (onOpenZipExport) onOpenZipExport();
              }}
              className="text-purple-400 hover:text-purple-300 bg-purple-950/20 border border-purple-500/30 px-1.5 py-0.5 uppercase cursor-pointer"
            >
              zip export
            </button>
          </div>

          {/* Console CLI Input Bar */}
          <form onSubmit={handleCommandSubmit} className="border-t border-slate-800 bg-[#05060a] p-1.5 flex gap-1.5 items-center">
            <span className="text-cyan-400 font-black text-[10px] pl-1.5 select-none animate-pulse">&gt;_</span>
            <input
              type="text"
              value={cmdInput}
              onChange={(e) => setCmdInput(e.target.value)}
              placeholder="ENTER COMMAND (e.g. override 192.168.1.1, expand, scan, lockdown)..."
              className="flex-1 bg-transparent border-0 text-[9px] text-slate-200 focus:outline-none placeholder-slate-700 font-mono uppercase focus:ring-0 focus:border-0 p-0"
            />
            <button
              type="submit"
              className="text-[8px] font-black border border-cyan-500/40 bg-cyan-950/30 text-cyan-400 px-2.5 py-1 uppercase hover:bg-cyan-900/40 transition-colors cursor-pointer"
            >
              EXECUTE
            </button>
          </form>
        </div>
      ) : (
        // Subnet Topology Matrix View (Expanded Network Visualizer)
        <div className="flex-1 min-h-[160px] bg-[#030406] border border-slate-800 p-3 flex flex-col justify-between overflow-hidden">
          <div className="flex justify-between items-center text-[8px] border-b border-slate-800 pb-1.5 mb-2">
            <span className="text-cyan-400 font-black uppercase tracking-wider">
              PRECINCT MESH TOPOLOGY & ROUTING
            </span>
            <span className="text-slate-500 font-mono">PACKET RATE: 2,480 PKTS/S • LATENCY: 3MS</span>
          </div>

          {/* Visual Topology Diagram */}
          <div className="grid grid-cols-5 gap-2 text-center my-auto">
            {/* Node 1: Gateway 192.168.1.1 */}
            <div className={`p-2 border ${
              overriddenIPs.includes('192.168.1.1')
                ? 'border-cyan-400 bg-cyan-950/40 shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                : 'border-slate-800 bg-[#06080e]'
            }`}>
              <span className="text-[7px] text-slate-500 font-bold block uppercase">GATEWAY ROUTER</span>
              <span className="text-[9px] font-black text-white block font-mono">192.168.1.1</span>
              <span className={`text-[7px] font-bold block mt-1 ${
                overriddenIPs.includes('192.168.1.1') ? 'text-cyan-400' : 'text-slate-500'
              }`}>
                {overriddenIPs.includes('192.168.1.1') ? 'ROOT OVERRIDE' : 'RESTRICTED'}
              </span>
            </div>

            {/* Node 2: Central Server */}
            <div className="p-2 border border-slate-800 bg-[#06080e]">
              <span className="text-[7px] text-slate-500 font-bold block uppercase">CORE DISPATCH</span>
              <span className="text-[9px] font-black text-slate-200 block font-mono">192.168.1.10</span>
              <span className="text-[7px] text-cyber-blue font-bold block mt-1">ONLINE</span>
            </div>

            {/* Node 3: Surveillance Hub */}
            <div className="p-2 border border-slate-800 bg-[#06080e]">
              <span className="text-[7px] text-slate-500 font-bold block uppercase">SENSOR MATRIX</span>
              <span className="text-[9px] font-black text-slate-200 block font-mono">192.168.1.25</span>
              <span className="text-[7px] text-emerald-400 font-bold block mt-1">SYNCED</span>
            </div>

            {/* Node 4: Drone Telemetry */}
            <div className="p-2 border border-slate-800 bg-[#06080e]">
              <span className="text-[7px] text-slate-500 font-bold block uppercase">UAV RECON MESH</span>
              <span className="text-[9px] font-black text-slate-200 block font-mono">192.168.1.50</span>
              <span className="text-[7px] text-cyan-400 font-bold block mt-1">UPLINK ACTIVE</span>
            </div>

            {/* Node 5: Precinct Vault */}
            <div className="p-2 border border-slate-800 bg-[#06080e]">
              <span className="text-[7px] text-slate-500 font-bold block uppercase">PERIMETER CHOKE</span>
              <span className="text-[9px] font-black text-slate-200 block font-mono">192.168.1.100</span>
              <span className="text-[7px] text-amber-400 font-bold block mt-1">ARMED</span>
            </div>
          </div>

          {/* Port Status Breakdown */}
          <div className="border-t border-slate-800 pt-2 grid grid-cols-4 gap-2 text-[7.5px] font-mono text-slate-400">
            <div>PORT 22 (SSH): <span className="text-cyan-400 font-bold">BYPASSED</span></div>
            <div>PORT 80 (HTTP): <span className="text-cyan-400 font-bold">PROXIED</span></div>
            <div>PORT 443 (TLS): <span className="text-cyan-400 font-bold">INTERCEPTED</span></div>
            <div>PORT 8080 (STREAM): <span className="text-cyan-400 font-bold">LIVE</span></div>
          </div>
        </div>
      )}
    </div>
  );
}
