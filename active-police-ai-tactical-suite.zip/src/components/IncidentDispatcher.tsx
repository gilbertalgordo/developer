import React, { useState } from 'react';
import { Incident, PatrolUnit } from '../types';
import { Send, AlertTriangle, Shield, CheckCircle2, RefreshCw, Cpu, Plus, Users, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { soundManager } from '../utils/audio';

interface IncidentDispatcherProps {
  availableUnits: PatrolUnit[];
  onDispatchConfirmed: (incidentData: Partial<Incident>, assignedUnitIds: string[]) => void;
  geminiActive: boolean;
  onAddLog: (message: string, type: 'INFO' | 'ALERT' | 'CRITICAL') => void;
}

const TEMPLATES = [
  {
    label: "🚨 Bank Robbery",
    text: "Armed robbery at downtown central bank on Main St, suspects fleeing with weapons",
  },
  {
    label: "🔥 Gateway Infiltration",
    text: "Intrusion alarm on subnet gateway node 192.168.1.1, unauthorized physical terminal access",
  },
  {
    label: "🚗 High-Speed Pursuit",
    text: "High-speed vehicle pursuit eastbound toward Sector-8 Harbor, crossing red signals",
  },
  {
    label: "🚁 Hostage Emergency",
    text: "Critical hostage barricade incident inside high-rise office, weapon sighted",
  },
  {
    label: "🌊 Pier Smuggling Intrusion",
    text: "Unregistered watercraft docking at Sector-8 cargo container slip with unauthorized cargo",
  },
  {
    label: "🔊 Acoustic Disorder",
    text: "Acoustic sensor flagged shouting and disturbance near subway transit entrance",
  }
];

export default function IncidentDispatcher({
  availableUnits,
  onDispatchConfirmed,
  geminiActive,
  onAddLog,
}: IncidentDispatcherProps) {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Tactical analysis output state
  const [analysis, setAnalysis] = useState<{
    category: string;
    priority: 'HIGH' | 'NORMAL';
    threatScore: number;
    recommendedAction: string;
    summary: string;
    suggestedUnits: string[];
    source: string;
  } | null>(null);

  // Unit dispatch selection
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);

  const handleTemplateClick = (text: string) => {
    soundManager.playBlip();
    setInputText(text);
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    soundManager.playChirp();
    setIsAnalyzing(true);
    setAnalysis(null);
    setSelectedUnitIds([]);

    try {
      onAddLog(`Initiating cognitive analysis: "${inputText.substring(0, 40)}..."`, 'INFO');
      
      const response = await fetch('/api/analyze-incident', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      });

      if (!response.ok) {
        throw new Error(`Server returned error status: ${response.status}`);
      }

      const data = await response.json();
      setAnalysis({
        category: data.category,
        priority: data.priority,
        threatScore: data.threatScore,
        recommendedAction: data.recommendedAction,
        summary: data.summary,
        suggestedUnits: data.suggestedUnits || ["PATROL"],
        source: data.source,
      });

      // Automatically suggest units based on analysis
      const preselect: string[] = [];
      const matchType = data.suggestedUnits?.map((u: string) => u.toUpperCase()) || ["PATROL"];
      
      availableUnits.forEach(u => {
        if (u.status === 'IDLE' && (matchType.includes(u.type.toUpperCase()) || matchType.includes('PATROL'))) {
          if (preselect.length < 3) {
            preselect.push(u.id);
          }
        }
      });

      if (preselect.length === 0) {
        const firstIdle = availableUnits.find(u => u.status === 'IDLE');
        if (firstIdle) preselect.push(firstIdle.id);
      }

      setSelectedUnitIds(preselect);
      
      const logType = data.priority === 'HIGH' ? 'CRITICAL' : 'ALERT';
      if (data.priority === 'HIGH') {
        soundManager.playAlarm();
      } else {
        soundManager.playDispatch();
      }
      onAddLog(`Analysis Complete: ${data.category.toUpperCase()} (Threat ${data.threatScore}%)`, logType);

    } catch (err) {
      console.error(err);
      onAddLog('Cognitive incident classification failed. Check backend telemetry.', 'ALERT');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleUnitSelection = (unitId: string) => {
    soundManager.playBlip();
    setSelectedUnitIds(prev =>
      prev.includes(unitId) ? prev.filter(id => id !== unitId) : [...prev, unitId]
    );
  };

  const handleSelectAllAvailable = () => {
    soundManager.playBlip();
    const idleIds = availableUnits.filter(u => u.status === 'IDLE').map(u => u.id);
    setSelectedUnitIds(idleIds.slice(0, 4));
  };

  const handleConfirmDispatch = () => {
    if (!analysis || selectedUnitIds.length === 0) return;

    soundManager.playDispatch();
    onDispatchConfirmed(
      {
        text: inputText,
        category: analysis.category,
        priority: analysis.priority,
        threatScore: analysis.threatScore,
        recommendedAction: analysis.recommendedAction,
        summary: analysis.summary,
      },
      selectedUnitIds
    );

    onAddLog(`DISPATCH CONFIRMED: ${selectedUnitIds.length} units mobilized for "${analysis.category}"`, 'CRITICAL');
    
    // Clear inputs after dispatch
    setInputText('');
    setAnalysis(null);
    setSelectedUnitIds([]);
  };

  return (
    <div className="bg-cyber-panel border border-slate-800 rounded-none p-4 font-mono shadow-xl relative flex flex-col" id="incident-dispatcher-panel">
      {/* Title */}
      <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2 mb-3 uppercase tracking-widest flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Send className="w-4 h-4 text-cyber-blue" />
          Tactical Dispatch Command
        </div>
        <div className="text-[9px] text-slate-500 font-bold uppercase flex items-center gap-1">
          <Cpu className="w-3 h-3 text-cyan-400" />
          {geminiActive ? 'Gemini 3.5 Active' : 'Kaizen Heuristics'}
        </div>
      </div>

      {/* Quick Templates */}
      <div className="flex flex-wrap gap-1 mb-3">
        {TEMPLATES.map((tmpl, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleTemplateClick(tmpl.text)}
            className="text-[8px] bg-cyber-bg border border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40 px-2 py-1 transition-colors cursor-pointer"
          >
            {tmpl.label}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <form onSubmit={handleAnalyze} className="flex flex-col gap-2 mb-3">
        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={2}
            placeholder="Enter raw incident description, 911 dispatch transcript, or radio call..."
            className="w-full bg-[#030406] border border-slate-800 focus:border-cyan-400 p-2 text-xs text-slate-200 placeholder-slate-700 font-mono focus:outline-none resize-none"
          />
        </div>
        <div className="flex justify-between items-center">
          <span className="text-[8px] text-slate-500">
            Directive: Classify risk, assign tactical units, estimate vectors
          </span>
          <button
            type="submit"
            disabled={isAnalyzing || !inputText.trim()}
            className="bg-cyber-blue hover:bg-blue-600 text-white px-3 py-1.5 text-[9px] font-black uppercase transition-colors disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1.5 shadow-[0_0_8px_rgba(59,130,246,0.3)]"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-3 h-3 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Zap className="w-3 h-3 text-cyan-300" />
                Analyze Incident
              </>
            )}
          </button>
        </div>
      </form>

      {/* Analysis Results & Unit Selection */}
      <AnimatePresence>
        {analysis && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="border border-slate-800 bg-[#030406] p-3 flex flex-col gap-2.5 overflow-hidden mb-1"
          >
            {/* Header info */}
            <div className="flex justify-between items-start border-b border-slate-800 pb-2">
              <div>
                <span className="text-[8px] text-slate-500 font-bold uppercase block">CLASSIFICATION</span>
                <span className="text-xs font-black text-white uppercase">{analysis.category}</span>
              </div>
              <div className="text-right">
                <span className="text-[8px] text-slate-500 font-bold uppercase block">THREAT SCORE</span>
                <span className={`text-xs font-black ${
                  analysis.priority === 'HIGH' ? 'text-red-400 animate-pulse' : 'text-amber-400'
                }`}>
                  {analysis.threatScore}% [{analysis.priority}]
                </span>
              </div>
            </div>

            {/* Directive */}
            <div className="text-[8.5px] bg-cyber-bg border border-slate-800 p-2 text-slate-300 font-mono">
              <strong className="text-cyan-400 block mb-0.5">DIRECTIVE:</strong>
              {analysis.recommendedAction}
            </div>

            {/* Available Units Selection */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[8px] text-slate-400 font-bold uppercase">
                  ASSIGN RESPONSE UNITS ({selectedUnitIds.length} SELECTED)
                </span>
                <button
                  type="button"
                  onClick={handleSelectAllAvailable}
                  className="text-[7.5px] text-cyan-400 hover:underline uppercase cursor-pointer"
                >
                  DEPLOY TASK FORCE (AUTO)
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 max-h-[110px] overflow-y-auto pr-1">
                {availableUnits.map(unit => {
                  const isSelected = selectedUnitIds.includes(unit.id);
                  const isIdle = unit.status === 'IDLE';

                  return (
                    <div
                      key={unit.id}
                      onClick={() => isIdle && toggleUnitSelection(unit.id)}
                      className={`p-1.5 border text-[8px] font-mono flex flex-col justify-between transition-colors ${
                        !isIdle
                          ? 'border-slate-900 bg-slate-950/20 opacity-40 cursor-not-allowed'
                          : isSelected
                            ? 'border-cyan-400 bg-cyan-950/30 text-white shadow-[0_0_6px_rgba(6,182,212,0.3)] cursor-pointer'
                            : 'border-slate-800 bg-[#06080e] text-slate-400 hover:border-slate-700 cursor-pointer'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold">{unit.id}</span>
                        <span className={`text-[7px] ${
                          unit.status === 'IDLE' ? 'text-emerald-400' : 'text-amber-400'
                        }`}>
                          {unit.status}
                        </span>
                      </div>
                      <span className="text-[7px] text-slate-500 truncate">{unit.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Dispatch Confirmation Button */}
            <button
              onClick={handleConfirmDispatch}
              disabled={selectedUnitIds.length === 0}
              className="w-full bg-red-600 hover:bg-red-500 text-white py-2 text-[10px] font-black uppercase tracking-wider transition-colors disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(239,68,68,0.4)]"
            >
              <Send className="w-3.5 h-3.5" />
              CONFIRM DISPATCH & ROUTE ({selectedUnitIds.length} UNITS)
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
