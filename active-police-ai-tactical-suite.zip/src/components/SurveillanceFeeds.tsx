import React, { useState } from 'react';
import { SensorFeed } from '../types';
import { Camera, Radio, Flame, ShieldAlert, Plus, Eye, Video, Activity, Sparkles, Crosshair } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { soundManager } from '../utils/audio';

interface SurveillanceFeedsProps {
  feeds: SensorFeed[];
  onTriggerIntrusion: (feedId: string, text: string) => void;
  onAddLog: (message: string, type: 'INFO' | 'ALERT' | 'CRITICAL') => void;
}

const PRESETS = [
  { label: "🚨 Weapon & Shouting", text: "shouting weapon detected running" },
  { label: "🔥 Thermal Intrusion", text: "thermal hotspot breach detected running" },
  { label: "🚗 High-Speed Pursuit", text: "speeding vehicle pursuit through perimeter" },
  { label: "🔒 Gateway Breach", text: "gateway node breach override attempt" },
  { label: "🏃 Running Suspect", text: "running shouting on sidewalk" },
  { label: "🛡️ Standard Clear", text: "routine patrol pedestrian clear" }
];

export default function SurveillanceFeeds({
  feeds,
  onTriggerIntrusion,
  onAddLog
}: SurveillanceFeedsProps) {
  const [selectedFeedId, setSelectedFeedId] = useState<string>(feeds[0]?.id || '');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [customMetadata, setCustomMetadata] = useState('');

  const selectedFeed = feeds.find(f => f.id === selectedFeedId) || feeds[0];

  const filteredFeeds = feeds.filter(f => {
    if (filterType === 'ALL') return true;
    return f.type === filterType;
  });

  const calculatePreviewScore = (text: string) => {
    const lowercase = text.toLowerCase();
    const weights: Record<string, number> = {
      weapon: 0.9,
      shouting: 0.4,
      running: 0.3,
      loitering: 0.1,
      thermal: 0.7,
      breach: 0.85,
      pursuit: 0.75,
      override: 0.8,
      speeding: 0.4
    };
    
    const words = lowercase.split(/\s+/);
    let score = 0;
    for (const word of words) {
      const cleanWord = word.replace(/[^a-z]/g, "");
      if (weights[cleanWord] !== undefined) {
        score += weights[cleanWord];
      }
    }
    return Math.min(score, 1.0);
  };

  const currentPreviewScore = calculatePreviewScore(customMetadata);

  const handleSubmitCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMetadata.trim() || !selectedFeedId) return;

    soundManager.playDispatch();
    onTriggerIntrusion(selectedFeedId, customMetadata);
    setCustomMetadata('');
  };

  const handleApplyPreset = (text: string) => {
    if (!selectedFeedId) return;
    soundManager.playDispatch();
    onTriggerIntrusion(selectedFeedId, text);
  };

  return (
    <div className="bg-cyber-panel border border-slate-800 rounded-none p-4 font-mono shadow-xl relative flex flex-col h-full" id="surveillance-feeds-panel">
      {/* Title Bar & Filter Pills */}
      <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2 mb-3 uppercase tracking-widest flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center gap-1.5">
          <Camera className="w-4 h-4 text-cyber-blue" />
          <span>Multi-Spectrum Sensor Feeds</span>
          <span className="text-[8px] bg-cyan-950/40 border border-cyan-500/40 text-cyan-400 px-1 py-0.2 font-black">
            {feeds.length} STREAMS
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex bg-[#0a0c12] border border-slate-800 p-0.5 text-[7.5px] font-bold">
          {['ALL', 'CAMERA', 'AUDIO', 'THERMAL', 'DRONE'].map((type) => (
            <button
              key={type}
              onClick={() => {
                soundManager.playBlip();
                setFilterType(type);
              }}
              className={`px-1.5 py-0.5 rounded-none transition-colors cursor-pointer ${
                filterType === type
                  ? 'bg-cyber-blue text-white font-black'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Feed Live Optical/Acoustic HUD Monitor */}
      {selectedFeed && (
        <div className="bg-[#030406] border border-slate-800 mb-3 relative overflow-hidden p-2.5 flex flex-col gap-1.5">
          <div className="flex justify-between items-center text-[8px] border-b border-slate-800/80 pb-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping inline-block" />
              <span className="text-red-400 font-black tracking-widest uppercase">REC [LIVE 30 FPS]</span>
              <span className="text-slate-500 font-mono">| {selectedFeed.id} ({selectedFeed.type})</span>
            </div>
            <div className="text-slate-400 font-mono font-bold">
              {selectedFeed.sector || 'SECTOR-7'} • {selectedFeed.location}
            </div>
          </div>

          {/* Video Viewport Simulation with CRT scan lines */}
          <div className="relative h-24 bg-[#080b11] border border-slate-900 flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 pointer-events-none opacity-20 crt-lines" />
            
            {/* Live Camera Targeting Reticle */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <Crosshair className="w-10 h-10 text-cyber-blue/30 animate-[spin_30s_linear_infinite]" />
            </div>

            {/* If AUDIO feed, show simulated acoustic equalizer bars */}
            {selectedFeed.type === 'AUDIO' ? (
              <div className="flex items-end gap-1 h-12 w-3/4 justify-center z-10">
                {[40, 75, 90, 60, 30, 85, 95, 50, 65, 80, 45, 90, 70, 35].map((h, i) => (
                  <div
                    key={i}
                    className="w-1.5 bg-cyan-400/80 rounded-none transition-all duration-300"
                    style={{
                      height: `${(h * (0.5 + Math.random() * 0.5))}%`,
                      backgroundColor: selectedFeed.status === 'CRITICAL' ? '#ef4444' : selectedFeed.status === 'WARNING' ? '#f59e0b' : '#06b6d4'
                    }}
                  />
                ))}
              </div>
            ) : selectedFeed.type === 'THERMAL' ? (
              // Thermal Spectrum View
              <div className="z-10 text-center flex flex-col items-center">
                <Flame className="w-8 h-8 text-amber-500 animate-pulse mb-1" />
                <span className="text-[8px] text-amber-400 font-bold uppercase tracking-wider">
                  FLIR THERMAL INFRARED MATRIX • OPTICAL SENSING NOMINAL
                </span>
              </div>
            ) : (
              // Optical Camera or Drone Feed
              <div className="z-10 text-center flex flex-col items-center px-4">
                <span className="text-[9px] text-slate-300 font-bold tracking-tight">
                  "{selectedFeed.lastDetectedText || 'Continuous optical telemetry clear'}"
                </span>
                <span className="text-[7.5px] text-slate-500 font-mono mt-0.5">
                  AI DETECTION BOUNDING CONFIDENCE: {Math.max(68, Math.round(selectedFeed.riskScore * 100))}%
                </span>
              </div>
            )}

            {/* Corner Bracket Graphics */}
            <div className="absolute top-1.5 left-1.5 w-2 h-2 border-t border-l border-cyan-500/60" />
            <div className="absolute top-1.5 right-1.5 w-2 h-2 border-t border-r border-cyan-500/60" />
            <div className="absolute bottom-1.5 left-1.5 w-2 h-2 border-b border-l border-cyan-500/60" />
            <div className="absolute bottom-1.5 right-1.5 w-2 h-2 border-b border-r border-cyan-500/60" />
          </div>
        </div>
      )}

      {/* Grid of Feeds */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3 overflow-y-auto max-h-[160px] pr-1">
        {filteredFeeds.map((feed) => {
          const isCritical = feed.status === 'CRITICAL';
          const isWarning = feed.status === 'WARNING';
          const isSelected = selectedFeedId === feed.id;
          
          const statusBg = isCritical 
            ? 'bg-red-950/15 border-red-900/60 text-red-400' 
            : isWarning 
              ? 'bg-amber-950/15 border-amber-500/50 text-amber-400' 
              : 'bg-[#0a0c12]/70 border-slate-800 text-cyber-blue';

          return (
            <div
              key={feed.id}
              onClick={() => {
                soundManager.playBlip();
                setSelectedFeedId(feed.id);
              }}
              className={`p-2 rounded-none border transition-all cursor-pointer relative overflow-hidden flex flex-col gap-1 ${statusBg} ${
                isSelected ? 'ring-1 ring-cyan-400 border-cyan-500/80 shadow-[0_0_8px_rgba(6,182,212,0.3)]' : ''
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="text-[9.5px] font-black uppercase tracking-wider">{feed.id}</span>
                <span className={`text-[8.5px] font-black ${isCritical ? 'text-red-400' : isWarning ? 'text-amber-400' : 'text-blue-400'}`}>
                  {Math.round(feed.riskScore * 100)}%
                </span>
              </div>
              <div className="text-[8px] text-slate-400 font-bold truncate leading-none">
                {feed.location}
              </div>
              <div className="text-[7.5px] text-slate-500 italic truncate border-t border-slate-800/60 pt-0.5 mt-0.5">
                "{feed.lastDetectedText || 'Static'}"
              </div>
            </div>
          );
        })}
      </div>

      {/* Sensor Input Simulator / Injection Controls */}
      <div className="bg-[#030406] border border-slate-800 rounded-none p-2.5 flex flex-col gap-2">
        <div className="flex justify-between items-center">
          <span className="text-[8.5px] text-slate-400 font-black uppercase tracking-wider">
            Simulate Event Injection
          </span>
          <span className="text-[8px] text-slate-500 font-mono">
            Target: <strong className="text-cyan-400 uppercase font-bold">{selectedFeedId}</strong>
          </span>
        </div>

        {/* Quick preset trigger buttons */}
        <div className="flex flex-wrap gap-1">
          {PRESETS.map((preset, index) => {
            const isCrit = preset.text.includes("weapon") || preset.text.includes("thermal") || preset.text.includes("breach");
            const isWarn = preset.text.includes("speeding") || preset.text.includes("running");
            const bColor = isCrit
              ? 'hover:border-red-500/60 hover:bg-red-950/30 text-red-300'
              : isWarn
                ? 'hover:border-amber-500/60 hover:bg-amber-950/30 text-amber-300'
                : 'hover:border-blue-500/60 text-slate-300';
            
            return (
              <button
                key={index}
                type="button"
                onClick={() => handleApplyPreset(preset.text)}
                className={`text-[8px] bg-cyber-bg border border-slate-800 rounded-none px-2 py-1 transition-colors cursor-pointer ${bColor}`}
              >
                {preset.label}
              </button>
            );
          })}
        </div>

        {/* Custom transcript injection input */}
        <form onSubmit={handleSubmitCustom} className="flex gap-1.5 mt-1">
          <input
            type="text"
            value={customMetadata}
            onChange={(e) => setCustomMetadata(e.target.value)}
            placeholder="Custom transcript (e.g. thermal breach weapon detected)..."
            className="bg-cyber-bg border border-slate-800 focus:border-cyan-400 focus:ring-0 rounded-none px-2 py-1 text-xs text-slate-200 placeholder-slate-700 flex-1 font-mono focus:outline-none"
          />
          <button
            type="submit"
            disabled={!customMetadata.trim()}
            className="bg-cyber-blue hover:bg-blue-600 text-white px-3 py-1 text-[9px] font-bold uppercase transition-colors disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1 shrink-0"
          >
            <Plus className="w-3 h-3" />
            Inject
          </button>
        </form>

        {/* Dynamic preview risk */}
        {customMetadata.trim() && (
          <div className="flex justify-between items-center bg-cyber-bg border border-slate-800 p-1 px-2 text-[8px] font-mono">
            <span className="text-slate-400">Heuristic Risk:</span>
            <span className={`font-black ${
              currentPreviewScore >= 0.75 ? 'text-red-400' : currentPreviewScore >= 0.3 ? 'text-amber-400' : 'text-blue-400'
            }`}>
              {Math.round(currentPreviewScore * 100)}% ({currentPreviewScore >= 0.75 ? 'CRITICAL INTERCEPT' : currentPreviewScore >= 0.3 ? 'WARNING' : 'CLEAR'})
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
