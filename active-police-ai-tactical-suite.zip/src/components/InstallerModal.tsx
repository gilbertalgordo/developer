import React, { useState, useEffect } from 'react';
import { Download, Monitor, Smartphone, Terminal, CheckCircle2, Shield, X, ExternalLink, Cpu, HardDrive } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface InstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function InstallerModal({ isOpen, onClose }: InstallerModalProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [activeTab, setActiveTab] = useState<'pwa' | 'desktop' | 'mobile' | 'script'>('pwa');
  const [isInstalling, setIsInstalling] = useState(false);
  const [installStatusMsg, setInstallStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    // Check if already in standalone mode
    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true
    ) {
      setIsInstalled(true);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      console.log('Tactical PWA: beforeinstallprompt intercepted');
    };

    window.addEventListener('beforeinstallprompt', handler);

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
      soundManager.playDownloadSuccess();
      setInstallStatusMsg('Tactical Command Desk installed successfully.');
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    soundManager.playInstallPrompt();
    if (deferredPrompt) {
      setIsInstalling(true);
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
        setInstallStatusMsg('Tactical Desk installation accepted.');
      } else {
        setInstallStatusMsg('Installation dismissed by operator.');
      }
      setDeferredPrompt(null);
      setIsInstalling(false);
    } else {
      // Fallback instructions if native prompt isn't directly invocable (e.g. iframe context)
      setInstallStatusMsg('Follow the quick instructions below to complete installation.');
    }
  };

  const handleDownloadScript = (type: 'sh' | 'bat') => {
    soundManager.playDownloadSuccess();
    const scriptContent =
      type === 'sh'
        ? `#!/usr/bin/env bash
set -e
echo "=========================================================="
echo "    ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       "
echo "=========================================================="
echo "Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js 18+ is required. Install from https://nodejs.org"
    exit 1
fi
echo "Installing dependencies..."
npm install
echo "Building tactical production bundles..."
npm run build
echo "Installation complete!"
echo "Starting Active Police AI Tactical Desk on port 3000..."
npm run dev
`
        : `@echo off
echo ==========================================================
echo     ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       
echo ==========================================================
echo Checking Node.js environment...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js not found. Please install Node.js 18+ from https://nodejs.org
    pause
    exit /b 1
)
echo Installing dependencies...
call npm install
echo Building application...
call npm run build
echo Launching Tactical Command Desk on http://localhost:3000...
call npm run dev
pause
`;

    const blob = new Blob([scriptContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = type === 'sh' ? 'install-tactical-desk.sh' : 'install-tactical-desk.bat';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in" id="installer-modal-overlay">
      <div className="bg-cyber-panel border border-cyan-500/40 w-full max-w-2xl text-slate-100 shadow-[0_0_30px_rgba(6,182,212,0.25)] flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="p-3.5 border-b border-slate-800 bg-[#0a0d14] flex justify-between items-center relative">
          <div className="flex items-center gap-2.5">
            <div className="bg-cyan-950/60 border border-cyan-500 p-1.5 flex items-center justify-center">
              <Download className="w-4 h-4 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-black tracking-widest text-slate-100 uppercase">
                  Tactical App Installer & Offline PWA Suite
                </h3>
                <span className="text-[8px] bg-cyan-950 border border-cyan-500/50 text-cyan-300 px-1.5 py-0.2 font-mono uppercase font-black">
                  STANDALONE
                </span>
              </div>
              <p className="text-[9px] text-slate-400 font-mono tracking-tight">
                Install as a native desktop/mobile application or download automated local deployment scripts.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-cyber-bg text-[10px] font-mono font-bold uppercase">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 border-r border-slate-800 transition-colors ${
              activeTab === 'pwa'
                ? 'bg-cyan-950/40 text-cyan-300 border-b-2 border-b-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>1-Click PWA Install</span>
          </button>
          <button
            onClick={() => setActiveTab('desktop')}
            className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 border-r border-slate-800 transition-colors ${
              activeTab === 'desktop'
                ? 'bg-cyan-950/40 text-cyan-300 border-b-2 border-b-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Desktop Window</span>
          </button>
          <button
            onClick={() => setActiveTab('mobile')}
            className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 border-r border-slate-800 transition-colors ${
              activeTab === 'mobile'
                ? 'bg-cyan-950/40 text-cyan-300 border-b-2 border-b-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile & Tablet</span>
          </button>
          <button
            onClick={() => setActiveTab('script')}
            className={`flex-1 py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'script'
                ? 'bg-cyan-950/40 text-cyan-300 border-b-2 border-b-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>CLI Scripts</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 overflow-y-auto space-y-4 font-mono flex-1 text-xs">
          
          {/* Status banner */}
          <div className="bg-[#090e17] border border-slate-800 p-2.5 flex items-center justify-between text-[9.5px]">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isInstalled ? 'bg-emerald-400 animate-pulse' : 'bg-cyan-400 animate-pulse'}`} />
              <span className="text-slate-300 font-bold uppercase">System Status:</span>
              <span className="text-cyan-400">
                {isInstalled ? 'ACTIVE IN STANDALONE MODE' : deferredPrompt ? 'NATIVE PROMPT READY' : 'PWA SERVICE WORKER ACTIVE'}
              </span>
            </div>
            <div className="text-slate-500 uppercase">
              Web App Manifest: <span className="text-emerald-400">LOADED</span>
            </div>
          </div>

          {installStatusMsg && (
            <div className="bg-cyan-950/50 border border-cyan-500/50 p-2 text-[10px] text-cyan-300 flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>{installStatusMsg}</span>
            </div>
          )}

          {/* TAB 1: 1-Click PWA */}
          {activeTab === 'pwa' && (
            <div className="space-y-3">
              <div className="bg-[#0c121e] border border-cyan-500/20 p-3.5 text-center flex flex-col items-center gap-2">
                <div className="w-12 h-12 bg-cyan-950/80 border border-cyan-400 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                  <Shield className="w-6 h-6 text-cyan-300" />
                </div>
                <div className="text-sm font-black text-slate-100 uppercase tracking-wider">
                  Active Police AI Command Desk
                </div>
                <p className="text-[10px] text-slate-400 max-w-md">
                  Runs with native operating system window integration, zero browser address bar clutter, high-performance GPU canvas rendering, and offline emergency mode.
                </p>

                <button
                  onClick={handleInstallClick}
                  disabled={isInstalling || isInstalled}
                  className={`mt-2 px-5 py-2 text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all shadow-[0_0_12px_rgba(6,182,212,0.3)] cursor-pointer ${
                    isInstalled
                      ? 'bg-emerald-950/60 border border-emerald-500 text-emerald-300 cursor-default'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-slate-950 border border-cyan-300'
                  }`}
                >
                  <Download className="w-4 h-4" />
                  <span>{isInstalled ? 'APPLICATION ALREADY INSTALLED' : isInstalling ? 'LAUNCHING INSTALLER...' : 'INSTALL APPLICATION NOW'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[9.5px]">
                <div className="bg-[#0a0d14] border border-slate-800 p-2.5 space-y-1">
                  <span className="text-cyan-400 font-bold uppercase flex items-center gap-1">
                    <Cpu className="w-3 h-3" /> Offline Resilience
                  </span>
                  <p className="text-slate-400">
                    Service worker pre-caches all tactical assets. Operates even when field telemetry is disconnected.
                  </p>
                </div>
                <div className="bg-[#0a0d14] border border-slate-800 p-2.5 space-y-1">
                  <span className="text-cyan-400 font-bold uppercase flex items-center gap-1">
                    <HardDrive className="w-3 h-3" /> Zero Footprint
                  </span>
                  <p className="text-slate-400">
                    Native web sandbox with hardware acceleration and automatic live sync upon network reconnection.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Desktop Window */}
          {activeTab === 'desktop' && (
            <div className="space-y-3">
              <div className="bg-[#0a0d14] border border-slate-800 p-3 space-y-2.5">
                <div className="text-xs font-bold text-cyan-400 uppercase flex items-center gap-1.5">
                  <Monitor className="w-3.5 h-3.5" />
                  Google Chrome / Microsoft Edge (Desktop)
                </div>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[10px] pl-1">
                  <li>
                    Look at the browser URL bar on the top right for the <span className="text-cyan-300 font-bold">"Install App"</span> icon (a monitor with down arrow).
                  </li>
                  <li>
                    Or click the browser menu <span className="text-slate-200 font-bold">⋮</span> &rarr; <span className="text-cyan-300 font-bold">"Install Active Police AI Tactical HUD"</span>.
                  </li>
                  <li>
                    The Command Desk will pop out into an independent, distraction-free tactical window pinned to your taskbar / dock.
                  </li>
                </ol>
              </div>

              <div className="bg-[#0a0d14] border border-slate-800 p-3 space-y-2">
                <div className="text-xs font-bold text-amber-400 uppercase">
                  Keyboard Shortcuts in Standalone HUD
                </div>
                <div className="grid grid-cols-2 gap-2 text-[9.5px]">
                  <div className="bg-[#0e1422] p-1.5 border border-slate-800">
                    <span className="text-slate-400">F11:</span> Fullscreen Tactical Radar
                  </div>
                  <div className="bg-[#0e1422] p-1.5 border border-slate-800">
                    <span className="text-slate-400">Ctrl/Cmd + R:</span> Quick Telemetry Refresh
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Mobile & Tablet */}
          {activeTab === 'mobile' && (
            <div className="space-y-3">
              <div className="bg-[#0a0d14] border border-slate-800 p-3 space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  Apple iOS (Safari)
                </span>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[10px] pl-1">
                  <li>Tap the <span className="text-cyan-300 font-bold">Share</span> button (square with arrow pointing up) at the bottom.</li>
                  <li>Scroll down and tap <span className="text-cyan-300 font-bold">"Add to Home Screen"</span>.</li>
                  <li>Tap <span className="text-emerald-400 font-bold">Add</span> in the top right corner.</li>
                </ol>
              </div>

              <div className="bg-[#0a0d14] border border-slate-800 p-3 space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  Android (Chrome / Samsung Internet)
                </span>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[10px] pl-1">
                  <li>Tap the browser menu <span className="text-slate-200 font-bold">⋮</span> in the top-right.</li>
                  <li>Select <span className="text-cyan-300 font-bold">"Install app"</span> or <span className="text-cyan-300 font-bold">"Add to Home screen"</span>.</li>
                  <li>Confirm installation to add the Tactical Desk icon directly to your app launcher.</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 4: CLI Scripts */}
          {activeTab === 'script' && (
            <div className="space-y-3">
              <p className="text-[10px] text-slate-400">
                Download autonomous shell installer scripts to bootstrap the Tactical Node on any local server, development workstation, or air-gapped terminal with one command.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-[#0a0d14] border border-slate-800 p-3 flex flex-col justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold text-cyan-400 uppercase flex items-center gap-1.5 mb-1">
                      <Terminal className="w-3.5 h-3.5" />
                      macOS / Linux Installer
                    </div>
                    <p className="text-[9.5px] text-slate-400 font-mono">
                      Installs dependencies, builds production bundles, and launches the Tactical Desk on port 3000.
                    </p>
                  </div>
                  <button
                    onClick={() => handleDownloadScript('sh')}
                    className="w-full py-1.5 bg-blue-950/40 hover:bg-blue-900/60 border border-cyber-blue text-cyber-blue text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download install.sh</span>
                  </button>
                </div>

                <div className="bg-[#0a0d14] border border-slate-800 p-3 flex flex-col justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold text-cyan-400 uppercase flex items-center gap-1.5 mb-1">
                      <Terminal className="w-3.5 h-3.5" />
                      Windows Installer
                    </div>
                    <p className="text-[9.5px] text-slate-400 font-mono">
                      Batch script to check Node.js, install packages, and initialize local server.
                    </p>
                  </div>
                  <button
                    onClick={() => handleDownloadScript('bat')}
                    className="w-full py-1.5 bg-blue-950/40 hover:bg-blue-900/60 border border-cyber-blue text-cyber-blue text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download install.bat</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-[#0a0d14] flex justify-between items-center text-[9px] text-slate-500 font-mono">
          <div>
            TACTICAL PWA BUILD • CHROMIUM & WEBKIT COMPLIANT
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 uppercase font-black tracking-wider transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
