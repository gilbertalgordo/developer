import React, { useState } from 'react';
import { Incident, PatrolUnit } from '../types';
import { FileText, Shield, CheckCircle2, AlertTriangle, Eye, Navigation, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface IncidentDatabaseProps {
  incidents: Incident[];
  onResolveIncident: (incidentId: string) => void;
  selectedIncident: Incident | null;
  onSelectIncident: (incident: Incident | null) => void;
  onFocusIncidentCoords: (coordinates: { x: number; y: number }) => void;
}

export default function IncidentDatabase({
  incidents,
  onResolveIncident,
  selectedIncident,
  onSelectIncident,
  onFocusIncidentCoords
}: IncidentDatabaseProps) {
  const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'RESOLVED'>('ACTIVE');

  const filteredIncidents = incidents.filter((incident) => {
    if (filter === 'ACTIVE') return incident.status !== 'RESOLVED';
    if (filter === 'RESOLVED') return incident.status === 'RESOLVED';
    return true;
  });

  return (
    <div className="bg-cyber-panel border border-slate-800 rounded-none p-4 font-mono shadow-xl relative flex flex-col h-full" id="incident-database-panel">
      
      {/* Title & Filters */}
      <div className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 uppercase tracking-widest flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-cyber-blue" />
          Tactical Incident Database
        </div>
        
        {/* Simple filters */}
        <div className="flex bg-[#0a0c12]/80 border border-slate-800 rounded-none p-0.5 text-[8px] font-bold">
          {['ACTIVE', 'RESOLVED', 'ALL'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-2 py-0.5 rounded-none cursor-pointer transition-colors ${
                filter === f ? 'bg-cyber-blue text-slate-100 font-extrabold' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Incident List */}
      <div className="flex-1 overflow-y-auto max-h-[300px] flex flex-col gap-2 pr-1">
        {filteredIncidents.map((incident) => {
          const isSelected = selectedIncident?.id === incident.id;
          const isHigh = incident.priority === 'HIGH';
          const isResolved = incident.status === 'RESOLVED';

          return (
            <div
              key={incident.id}
              onClick={() => onSelectIncident(isSelected ? null : incident)}
              className={`p-3 rounded-none border transition-all cursor-pointer relative overflow-hidden flex flex-col gap-1.5 ${
                isSelected 
                  ? 'border-cyber-blue bg-cyber-blue/10'
                  : isResolved 
                    ? 'border-slate-900 bg-slate-950/20 opacity-65 hover:opacity-100'
                    : isHigh
                      ? 'border-red-900/50 bg-red-950/10 hover:border-red-500/40'
                      : 'border-slate-800 bg-slate-900/20 hover:border-slate-700'
              }`}
            >
              {/* Alert Stripe */}
              {!isResolved && (
                <div className={`absolute top-0 left-0 right-0 h-0.5 ${isHigh ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-amber-500'}`} />
              )}

              {/* Header row */}
              <div className="flex justify-between items-start">
                <div className="flex flex-col gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-extrabold text-slate-200 uppercase tracking-wide">
                      {incident.category}
                    </span>
                    <span className={`text-[8px] px-1 py-0.2 border rounded-none font-bold uppercase ${
                      isResolved 
                        ? 'text-slate-500 border-slate-800 bg-[#0a0c12]'
                        : isHigh 
                          ? 'text-white border-red-500 bg-red-600 font-extrabold'
                          : 'text-amber-400 border-amber-500/20 bg-amber-950/30'
                    }`}>
                      {isResolved ? 'RESOLVED' : isHigh ? 'PRIORITY 1' : 'PRIORITY 3'}
                    </span>
                  </div>
                  <span className="text-[8px] text-slate-500 font-bold uppercase font-mono">
                    ID: {incident.id.substring(0, 10)} | {incident.timestamp}
                  </span>
                </div>

                <div className="text-right flex flex-col items-end gap-1">
                  <span className={`text-xs font-black ${
                    isResolved ? 'text-slate-500' : isHigh ? 'text-red-400' : 'text-amber-400'
                  }`}>
                    {incident.threatScore}% Threat
                  </span>
                  <span className={`text-[8px] font-black uppercase rounded-none px-1.5 py-0.2 ${
                    isResolved 
                      ? 'text-slate-500 bg-slate-900'
                      : incident.status === 'PENDING'
                        ? 'text-amber-400 bg-amber-950/30 border border-amber-500/20 animate-pulse'
                        : incident.status === 'ON SCENE'
                          ? 'text-red-400 bg-red-950/30 border border-red-500/20'
                          : 'text-cyber-blue bg-blue-950/30 border border-blue-500/20'
                  }`}>
                    {incident.status}
                  </span>
                </div>
              </div>

              {/* Brief summary */}
              <div className="text-[10px] text-slate-300 leading-normal font-mono border-t border-slate-900 pt-1.5 font-medium">
                {incident.summary}
              </div>

              {/* Progress visual bar for high alerts to match active Armed Robbery card */}
              {isHigh && !isResolved && (
                <div className="mt-1 w-full bg-slate-800 h-1">
                  <div className="bg-red-500 h-full w-4/5 shadow-[0_0_8px_#ef4444] glow-red"></div>
                </div>
              )}

              {/* Assigned units and action row */}
              <div className="flex justify-between items-center mt-1 pt-1.5 border-t border-slate-900/60 text-[9px]">
                <div className="flex items-center gap-1 text-slate-500">
                  <Shield className="w-3 h-3 text-cyber-blue shrink-0" />
                  <span className="font-bold">Units:</span>
                  <span className="text-slate-300 font-extrabold uppercase">
                    {incident.assignedUnits.length > 0 ? incident.assignedUnits.join(', ') : 'None Assigned'}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-slate-500">
                  <MapPin className="w-3 h-3 text-cyber-blue" />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onFocusIncidentCoords(incident.coordinates);
                    }}
                    className="hover:text-cyber-blue font-bold underline transition-colors uppercase bg-transparent border-0 cursor-pointer text-[9px]"
                  >
                    Locate [{incident.coordinates.x},{incident.coordinates.y}]
                  </button>
                </div>
              </div>

              {/* Detailed dropdown info on selection */}
              <AnimatePresence>
                {isSelected && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-slate-800/80 pt-2 flex flex-col gap-2"
                  >
                    <div>
                      <span className="text-[8px] text-slate-500 font-bold uppercase block">Raw Report text</span>
                      <p className="text-[9px] text-slate-400 leading-tight italic font-serif">
                        "{incident.text}"
                      </p>
                    </div>

                    <div>
                      <span className="text-[8px] text-slate-500 font-bold uppercase block">Operational directives</span>
                      <div className={`p-1.5 rounded-none border text-[9px] font-bold uppercase ${
                        isResolved 
                          ? 'border-slate-800 bg-slate-950 text-slate-500'
                          : isHigh 
                            ? 'border-red-500/20 bg-red-950/20 text-red-400' 
                            : 'border-amber-500/20 bg-amber-950/20 text-amber-400'
                      }`}>
                        {incident.recommendedAction}
                      </div>
                    </div>

                    {/* Action button if active */}
                    {!isResolved && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onResolveIncident(incident.id);
                        }}
                        className="w-full bg-red-600 hover:bg-red-500 text-white font-extrabold uppercase text-[9px] py-1.5 rounded-none transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-[0_0_8px_rgba(239,68,68,0.3)] glow-red"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        Acknowledge & Close Case (Release Units)
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}

        {filteredIncidents.length === 0 && (
          <div className="text-center text-slate-600 border border-slate-800 border-dashed rounded-none p-6 py-10 font-mono text-[10px]">
            No records matched the filter criteria in Sector-7 logs.
          </div>
        )}
      </div>
    </div>
  );
}
