import React, { useState } from 'react';
import { PatrolUnit, Incident, SensorFeed } from '../types';
import { Shield, Radio, Camera, AlertTriangle, User, Navigation, Maximize2, Minimize2, Flame, Layers, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { soundManager } from '../utils/audio';

interface TacticalGridProps {
  units: PatrolUnit[];
  incidents: Incident[];
  sensors: SensorFeed[];
  selectedUnit: PatrolUnit | null;
  onSelectUnit: (unit: PatrolUnit) => void;
  selectedIncident: Incident | null;
  onSelectIncident: (incident: Incident) => void;
  isScanning?: boolean;
  scanningSensorId?: string | null;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  isFullExpansion?: boolean;
}

export default function TacticalGrid({
  units,
  incidents,
  sensors,
  selectedUnit,
  onSelectUnit,
  selectedIncident,
  onSelectIncident,
  isScanning = false,
  scanningSensorId = null,
  isExpanded = false,
  onToggleExpand,
  isFullExpansion = true,
}: TacticalGridProps) {
  const [hoveredEntity, setHoveredEntity] = useState<{
    type: 'UNIT' | 'INCIDENT' | 'SENSOR';
    name: string;
    details: string;
  } | null>(null);

  const [activeSector, setActiveSector] = useState<'ALL' | 'SECTOR-7' | 'SECTOR-8' | 'SECTOR-9'>('ALL');
  const [isThermalMode, setIsThermalMode] = useState(false);

  // SVG grid dimensions
  const width = isExpanded ? 700 : 500;
  const height = isExpanded ? 500 : 400;

  // Filter entities by active sector if selected
  const filteredUnits = units.filter(u => activeSector === 'ALL' || !u.sector || u.sector === activeSector);
  const filteredSensors = sensors.filter(s => activeSector === 'ALL' || !s.sector || s.sector === activeSector);
  const filteredIncidents = incidents.filter(i => activeSector === 'ALL' || !i.sector || i.sector === activeSector);

  // Convert logical coordinates (0-100) to SVG viewbox coordinates
  const getCoords = (coord: { x: number; y: number }) => {
    const x = 50 + (coord.x / 100) * (width - 100);
    const y = 40 + (coord.y / 100) * (height - 80);
    return { x, y };
  };

  const handleUnitClick = (unit: PatrolUnit) => {
    soundManager.playBlip();
    onSelectUnit(unit);
  };

  const handleIncidentClick = (incident: Incident) => {
    soundManager.playBlip();
    onSelectIncident(incident);
  };

  return (
    <div
      className={`bg-cyber-deep border border-slate-800 rounded-none p-4 font-mono shadow-xl relative overflow-hidden flex flex-col transition-all ${
        isExpanded ? 'fixed inset-4 z-50 bg-[#030406]/98 border-cyber-blue shadow-[0_0_30px_rgba(59,130,246,0.3)]' : 'h-full'
      }`}
      id="tactical-grid-container"
    >
      {/* Background cybernetic grid lines and radar rings */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-2 mb-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyber-blue" />
          <span className="text-xs font-bold text-slate-200 uppercase tracking-widest">
            Vector Tactical Radar
          </span>
          {isFullExpansion && (
            <span className="text-[8px] bg-cyan-950/40 border border-cyan-500/40 text-cyan-400 px-1.5 py-0.2 font-black uppercase tracking-wider">
              MULTI-SECTOR EXPANSION
            </span>
          )}
        </div>

        {/* Tactical Controls & Filters */}
        <div className="flex items-center gap-1.5">
          {/* Sector Selector */}
          <div className="flex bg-[#0a0c12] border border-slate-800 p-0.5 text-[8px] font-bold">
            {(['ALL', 'SECTOR-7', 'SECTOR-8', 'SECTOR-9'] as const).map(sec => (
              <button
                key={sec}
                onClick={() => {
                  soundManager.playBlip();
                  setActiveSector(sec);
                }}
                className={`px-1.5 py-0.5 rounded-none transition-colors cursor-pointer ${
                  activeSector === sec
                    ? 'bg-cyber-blue text-white font-black'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {sec === 'ALL' ? 'ALL SECTORS' : sec.replace('SECTOR-', 'S-')}
              </button>
            ))}
          </div>

          {/* Thermal IR Mode Toggle */}
          <button
            onClick={() => {
              soundManager.playBlip();
              setIsThermalMode(!isThermalMode);
            }}
            className={`p-1 border text-[8px] font-black uppercase flex items-center gap-1 transition-colors cursor-pointer ${
              isThermalMode
                ? 'bg-amber-950/40 border-amber-500 text-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                : 'bg-cyber-bg border-slate-800 text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Thermal Infrared Scope"
          >
            <Flame className="w-3 h-3 text-amber-500" />
            <span className="hidden sm:inline">THERMAL</span>
          </button>

          {/* Expand / Minimize Button */}
          {onToggleExpand && (
            <button
              onClick={() => {
                soundManager.playBlip();
                onToggleExpand();
              }}
              className="p-1 border border-slate-800 bg-cyber-bg text-slate-400 hover:text-cyber-blue hover:border-cyber-blue/40 transition-colors cursor-pointer"
              title={isExpanded ? 'Restore grid view' : 'Maximize grid view'}
            >
              {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* SVG Canvas */}
      <div className={`relative border border-slate-800 rounded-none flex-1 flex items-center justify-center overflow-hidden transition-colors ${
        isThermalMode ? 'bg-[#0a0505]' : 'bg-[#030406]'
      }`}>
        {/* Absolute coordinates background details */}
        <div
          className={`absolute inset-0 pointer-events-none ${
            isThermalMode
              ? 'bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.12)_0%,transparent_75%)]'
              : 'bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.08)_0%,transparent_70%)]'
          }`}
        />
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(#1e293b 1px, transparent 1px)', backgroundSize: '16px 16px' }}
        />

        {/* Sector Boundary Label Watermarks */}
        <div className="absolute top-2 left-3 text-[7.5px] font-black text-slate-700 select-none uppercase pointer-events-none">
          SEC-7 [METRO CENTRAL]
        </div>
        <div className="absolute top-2 right-3 text-[7.5px] font-black text-slate-700 select-none uppercase pointer-events-none text-right">
          SEC-8 [HARBOR DOCKS]
        </div>
        <div className="absolute bottom-2 left-3 text-[7.5px] font-black text-slate-700 select-none uppercase pointer-events-none">
          SEC-9 [TECH PARK & SUBSTATION]
        </div>

        {/* Small Tactical overlay coordinates widget */}
        <div className="absolute top-8 left-3 p-1.5 border border-slate-800 bg-cyber-bg/90 backdrop-blur-md text-[7.5px] pointer-events-none hidden md:block">
          <div className="text-cyber-blue font-bold mb-0.5 uppercase tracking-wider">RADAR TELEMETRY</div>
          <div className="grid grid-cols-2 gap-x-2 text-slate-500">
            <span>UNITS</span><span className="text-slate-300 font-bold">{filteredUnits.length} ACTIVE</span>
            <span>NODES</span><span className="text-slate-300 font-bold">{filteredSensors.length} ONLINE</span>
            <span>GATEWAY</span><span className="text-cyan-400 font-bold">192.168.1.1</span>
          </div>
        </div>

        {/* Scanning Scanline */}
        {isScanning && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
            <div className="w-full h-[2.5px] bg-cyan-400 opacity-90 shadow-[0_0_15px_#22d3ee] animate-scan-line absolute" />
            <div className="absolute inset-0 bg-cyan-500/[0.04] animate-pulse" />
          </div>
        )}

        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full select-none"
          style={{ minHeight: isExpanded ? '460px' : '320px', maxHeight: isExpanded ? '640px' : '420px' }}
        >
          <defs>
            <linearGradient id="radarSweepGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0" />
              <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.3" />
            </linearGradient>
            <radialGradient id="thermalHotspot" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.4" />
              <stop offset="60%" stopColor="#f59e0b" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Sector Demarcation Dividing Grid Lines */}
          <line x1={width / 2} y1={30} x2={width / 2} y2={height - 30} stroke="#1e293b" strokeWidth="1" strokeDasharray="4,4" />
          <line x1={40} y1={height / 2} x2={width - 40} y2={height / 2} stroke="#1e293b" strokeWidth="1" strokeDasharray="4,4" />

          {/* Radar Circles with Range Markers */}
          <circle cx={width / 2} cy={height / 2} r={60} fill="none" stroke={isThermalMode ? "#ef4444" : "#3b82f6"} strokeWidth="0.5" strokeDasharray="3,3" className="opacity-25" />
          <text x={width / 2 + 65} y={height / 2 - 4} fill="#475569" className="text-[6px] font-mono select-none">500m</text>

          <circle cx={width / 2} cy={height / 2} r={120} fill="none" stroke={isThermalMode ? "#ef4444" : "#3b82f6"} strokeWidth="0.5" className="opacity-15" />
          <text x={width / 2 + 125} y={height / 2 - 4} fill="#475569" className="text-[6px] font-mono select-none">1000m</text>

          <circle cx={width / 2} cy={height / 2} r={190} fill="none" stroke={isThermalMode ? "#ef4444" : "#3b82f6"} strokeWidth="0.5" strokeDasharray="5,5" className="opacity-10 animate-[spin_60s_linear_infinite]" />
          <text x={width / 2 + 195} y={height / 2 - 4} fill="#475569" className="text-[6px] font-mono select-none">1500m</text>

          {/* Outer Boundary Border */}
          <rect x={20} y={20} width={width - 40} height={height - 40} fill="none" stroke={isThermalMode ? "#ef4444" : "#3b82f6"} strokeWidth="1" className="opacity-20" />

          {/* Continuous Sweeping Radar Beam */}
          <g transform={`translate(${width / 2}, ${height / 2})`}>
            <line
              x1="0"
              y1="0"
              x2="190"
              y2="0"
              stroke={isThermalMode ? "#ef4444" : "#22d3ee"}
              strokeWidth="1.25"
              className="opacity-35"
              style={{
                transformOrigin: '0 0',
                animation: 'spin 6s linear infinite',
              }}
            />
            <polygon
              points="0,0 190,-25 190,25"
              fill="url(#radarSweepGrad)"
              className="opacity-15"
              style={{
                transformOrigin: '0 0',
                animation: 'spin 6s linear infinite',
              }}
            />
          </g>

          {/* Thermal Hotspots in Thermal Mode */}
          {isThermalMode && filteredIncidents.map(inc => {
            const { x, y } = getCoords(inc.coordinates);
            return (
              <circle key={`thermal-${inc.id}`} cx={x} cy={y} r={35} fill="url(#thermalHotspot)" className="animate-pulse" />
            );
          })}

          {/* Draw Routing Lines from assigned Patrol Units to Incidents */}
          {filteredUnits.map((unit) => {
            if (unit.status === 'RESPONDING' && unit.assignedIncidentId) {
              const incident = incidents.find(i => i.id === unit.assignedIncidentId);
              if (incident) {
                const uCoords = getCoords(unit.coordinates);
                const iCoords = getCoords(incident.coordinates);
                return (
                  <g key={`route-${unit.id}-${incident.id}`}>
                    <line
                      x1={uCoords.x}
                      y1={uCoords.y}
                      x2={iCoords.x}
                      y2={iCoords.y}
                      stroke={incident.priority === 'HIGH' ? '#ef4444' : '#3b82f6'}
                      strokeWidth="1.25"
                      strokeDasharray="4,4"
                      className="opacity-70 animate-[pulse_1.5s_infinite]"
                    />
                    <circle
                      cx={(uCoords.x + iCoords.x) / 2}
                      cy={(uCoords.y + iCoords.y) / 2}
                      r="2.5"
                      fill={incident.priority === 'HIGH' ? '#ef4444' : '#3b82f6'}
                      className="animate-ping"
                    />
                  </g>
                );
              }
            }
            return null;
          })}

          {/* Draw Sensors Pins */}
          {filteredSensors.map((sensor) => {
            const { x, y } = getCoords(sensor.coordinates);
            const isCritical = sensor.status === 'CRITICAL';
            const isScanned = sensor.id === scanningSensorId;
            const strokeColor = isScanned ? '#22d3ee' : isCritical ? '#ef4444' : sensor.status === 'WARNING' ? '#f59e0b' : '#3b82f6';

            return (
              <g
                key={sensor.id}
                transform={`translate(${x}, ${y})`}
                className="cursor-pointer"
                onMouseEnter={() =>
                  setHoveredEntity({
                    type: 'SENSOR',
                    name: `${sensor.name} [${sensor.type}]`,
                    details: `Sector: ${sensor.sector || 'S-7'} | Loc: ${sensor.location} | Feed: "${sensor.lastDetectedText || 'Nominal'}" | Risk: ${Math.round(sensor.riskScore * 100)}%`,
                  })
                }
                onMouseLeave={() => setHoveredEntity(null)}
              >
                <circle cx="0" cy="0" r="10" fill="#050608" stroke={strokeColor} strokeWidth={isScanned ? '2' : '1'} className="opacity-90" />
                {isCritical && (
                  <circle cx="0" cy="0" r="16" fill="none" stroke="#ef4444" strokeWidth="1" className="animate-ping opacity-60" />
                )}
                {isScanned && (
                  <>
                    <circle cx="0" cy="0" r="20" fill="none" stroke="#22d3ee" strokeWidth="1.5" className="animate-ping opacity-85" />
                    <rect x="-14" y="-14" width="28" height="28" fill="none" stroke="#22d3ee" strokeWidth="0.75" strokeDasharray="2,2" className="animate-[spin_4s_linear_infinite]" />
                    <text x="-22" y="-18" fill="#22d3ee" className="text-[6.5px] font-black tracking-widest uppercase font-mono animate-pulse">
                      SCAN
                    </text>
                  </>
                )}

                {/* Sensor Type Visual Representation */}
                {sensor.type === 'CAMERA' && (
                  <g transform="translate(-4, -4) scale(0.55)">
                    <Camera style={{ color: strokeColor }} className="w-4.5 h-4.5" />
                  </g>
                )}
                {sensor.type === 'AUDIO' && (
                  <g transform="translate(-4, -4) scale(0.55)">
                    <Radio style={{ color: strokeColor }} className="w-4.5 h-4.5" />
                  </g>
                )}
                {sensor.type === 'THERMAL' && (
                  <circle cx="0" cy="0" r="3.5" fill="#f59e0b" className="animate-pulse" />
                )}
                {sensor.type === 'DRONE' && (
                  <polygon points="0,-4 3,3 -3,3" fill="#22d3ee" />
                )}
                {sensor.type === 'ANPR' && (
                  <rect x="-3" y="-3" width="6" height="6" fill="#3b82f6" />
                )}

                {/* ID Label */}
                <text x="12" y="4" fill={strokeColor} className="text-[7.5px] font-black select-none opacity-85 uppercase font-mono">
                  {sensor.id}
                </text>
              </g>
            );
          })}

          {/* Draw Active Incidents */}
          {filteredIncidents.filter(i => i.status !== 'RESOLVED').map((incident) => {
            const { x, y } = getCoords(incident.coordinates);
            const isHigh = incident.priority === 'HIGH';
            const color = isHigh ? '#ef4444' : '#f59e0b';

            return (
              <g
                key={incident.id}
                transform={`translate(${x}, ${y})`}
                className="cursor-pointer"
                onClick={() => handleIncidentClick(incident)}
                onMouseEnter={() =>
                  setHoveredEntity({
                    type: 'INCIDENT',
                    name: `INCIDENT-${incident.id.substring(0, 7)}`,
                    details: `Sector: ${incident.sector || 'S-7'} | [${incident.category.toUpperCase()}] Priority: ${incident.priority} | Threat: ${incident.threatScore}% | Status: ${incident.status}`,
                  })
                }
                onMouseLeave={() => setHoveredEntity(null)}
              >
                {/* Danger ring */}
                {isHigh && (
                  <circle cx="0" cy="0" r="22" fill="none" stroke="#ef4444" strokeWidth="0.5" strokeDasharray="3,3" className="animate-pulse opacity-40" />
                )}
                <rect x="-9" y="-9" width="18" height="18" fill="none" stroke={color} strokeWidth="1.5" className="animate-pulse" />
                <line x1="-14" y1="0" x2="14" y2="0" stroke={color} strokeWidth="0.75" />
                <line x1="0" y1="-14" x2="0" y2="14" stroke={color} strokeWidth="0.75" />
                <circle cx="0" cy="0" r="3" fill={color} className="animate-ping" />

                {selectedIncident?.id === incident.id && (
                  <rect x="-16" y="-16" width="32" height="32" fill="none" stroke="#3b82f6" strokeWidth="1.25" strokeDasharray="3,3" className="animate-[spin_4s_linear_infinite]" />
                )}

                <text x="14" y="-4" fill={color} className="text-[8px] font-black uppercase font-mono bg-[#050608] px-1 border border-slate-800">
                  {incident.id.substring(0, 8)}
                </text>
              </g>
            );
          })}

          {/* Draw Patrol Units with Distinct Type Geometry */}
          {filteredUnits.map((unit) => {
            const { x, y } = getCoords(unit.coordinates);
            const isSelected = selectedUnit?.id === unit.id;
            const statusColor = unit.status === 'RESPONDING' ? '#f59e0b' : unit.status === 'ON_SCENE' ? '#ef4444' : '#3b82f6';

            const headings: Record<string, number> = { N: 0, NE: 45, E: 90, SE: 135, S: 180, SW: 225, W: 270, NW: 315 };
            const angle = headings[unit.heading] || 0;

            return (
              <g
                key={unit.id}
                transform={`translate(${x}, ${y})`}
                className="cursor-pointer"
                onClick={() => handleUnitClick(unit)}
                onMouseEnter={() =>
                  setHoveredEntity({
                    type: 'UNIT',
                    name: `${unit.name} (${unit.officer})`,
                    details: `Sector: ${unit.sector || 'S-7'} | Status: ${unit.status} | Speed: ${unit.speed} MPH | Heading: ${unit.heading} | Class: ${unit.type}`,
                  })
                }
                onMouseLeave={() => setHoveredEntity(null)}
              >
                {isSelected && (
                  <circle cx="0" cy="0" r="16" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="2,2" className="animate-spin" />
                )}

                {/* Specific Visual Markers for Expanded Unit Types */}
                <g transform={`rotate(${angle})`}>
                  {unit.type === 'DRONE' ? (
                    // UAV Quadcopter Shape
                    <g>
                      <line x1="-7" y1="-7" x2="7" y2="7" stroke={statusColor} strokeWidth="1.5" />
                      <line x1="-7" y1="7" x2="7" y2="-7" stroke={statusColor} strokeWidth="1.5" />
                      <circle cx="-7" cy="-7" r="2" fill={statusColor} />
                      <circle cx="7" cy="7" r="2" fill={statusColor} />
                      <circle cx="-7" cy="7" r="2" fill={statusColor} />
                      <circle cx="7" cy="-7" r="2" fill={statusColor} />
                      <circle cx="0" cy="0" r="3" fill="#06b6d4" />
                    </g>
                  ) : unit.type === 'MARINE' ? (
                    // Marine Cutter Hull
                    <g>
                      <polygon points="0,-10 6,4 4,8 -4,8 -6,4" fill={isSelected ? '#3b82f6' : '#07090f'} stroke={statusColor} strokeWidth="1.5" />
                      <circle cx="0" cy="0" r="1.5" fill="#3b82f6" />
                    </g>
                  ) : unit.type === 'SWAT' ? (
                    // Heavy Tactical BearCat Shield
                    <g>
                      <polygon points="0,-9 7,-3 5,7 0,9 -5,7 -7,-3" fill={isSelected ? '#3b82f6' : '#07090f'} stroke={statusColor} strokeWidth="1.5" />
                      <circle cx="0" cy="1" r="2" fill={statusColor} />
                    </g>
                  ) : (
                    // Standard Patrol / Air Support Triangle
                    <g>
                      <polygon points="0,-9 -6,6 6,6" fill={isSelected ? '#3b82f6' : '#07090f'} stroke={isSelected ? '#3b82f6' : statusColor} strokeWidth="1.5" />
                      <circle cx="0" cy="2" r="1.5" fill={statusColor} />
                    </g>
                  )}
                </g>

                {/* ID Label */}
                <text x="10" y="10" fill={isSelected ? '#3b82f6' : '#94a3b8'} className="text-[7.5px] font-black font-mono bg-[#050608]/80 px-0.5">
                  {unit.id}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover details overlay inside canvas */}
        <AnimatePresence>
          {hoveredEntity && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-3 left-3 right-3 bg-[#07090f]/95 border border-slate-800 rounded-none p-2.5 text-[10px] text-slate-300 pointer-events-none flex flex-col gap-0.5 shadow-2xl z-20"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-1">
                <span className={`font-black ${
                  hoveredEntity.type === 'INCIDENT' ? 'text-red-400' : hoveredEntity.type === 'SENSOR' ? 'text-amber-400' : 'text-blue-400'
                }`}>
                  [{hoveredEntity.type}] {hoveredEntity.name}
                </span>
                <span className="text-slate-500 font-bold uppercase text-[8px]">Sector Grid Active</span>
              </div>
              <div className="font-mono text-slate-300 tracking-tight leading-tight pt-1">
                {hoveredEntity.details}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Grid Legend & Status Summary */}
      <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 border-t border-slate-800 pt-3 text-[8.5px] text-slate-500 font-bold uppercase">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 bg-red-950 border border-red-500 inline-block rounded-none relative">
            <span className="absolute inset-0 bg-red-500 rounded-none animate-pulse" />
          </span>
          <span className="text-red-500">Critical Threat</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 bg-amber-950 border border-amber-500 inline-block rounded-none" />
          <span className="text-amber-500">Standard Hazard</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 bg-blue-950 border border-blue-500 inline-block rounded-none" />
          <span className="text-blue-500">Patrol Fleet</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 bg-cyan-950 border border-cyan-400 inline-block rounded-none" />
          <span className="text-cyan-400">Drone / Sensor Mesh</span>
        </div>
      </div>
    </div>
  );
}
