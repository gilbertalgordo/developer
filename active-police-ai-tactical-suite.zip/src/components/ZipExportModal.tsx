import React, { useState } from 'react';
import { Archive, Download, FileText, CheckCircle2, AlertCircle, X, Shield, Database, Terminal, Layers } from 'lucide-react';
import { soundManager } from '../utils/audio';
import { Incident, PatrolUnit, SensorFeed, SystemLog } from '../types';

interface ZipExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  incidents: Incident[];
  units: PatrolUnit[];
  sensors: SensorFeed[];
  logs: SystemLog[];
}

export default function ZipExportModal({
  isOpen,
  onClose,
  incidents,
  units,
  sensors,
  logs
}: ZipExportModalProps) {
  const [downloadingType, setDownloadingType] = useState<'full' | 'telemetry' | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Download Full Application Suite ZIP from backend
  const handleDownloadFullZip = async () => {
    try {
      setDownloadingType('full');
      setErrorMessage(null);
      setDownloadSuccess(null);
      soundManager.playBlip();

      const res = await fetch('/api/download-zip');
      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'active-police-ai-tactical-suite.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      soundManager.playDownloadSuccess();
      setDownloadSuccess('Full Tactical Suite ZIP downloaded successfully.');
    } catch (err: any) {
      console.error('ZIP download error:', err);
      setErrorMessage(err.message || 'Failed to download deployment ZIP');
    } finally {
      setDownloadingType(null);
    }
  };

  // Download Telemetry & Incident Logs ZIP
  const handleDownloadTelemetryZip = async () => {
    try {
      setDownloadingType('telemetry');
      setErrorMessage(null);
      setDownloadSuccess(null);
      soundManager.playBlip();

      const res = await fetch('/api/download-telemetry-zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          incidents,
          units,
          sensors,
          logs
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `police-ai-telemetry-${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      soundManager.playDownloadSuccess();
      setDownloadSuccess('Incident and Telemetry ZIP exported successfully.');
    } catch (err: any) {
      console.error('Telemetry ZIP export error:', err);
      setErrorMessage(err.message || 'Failed to export telemetry archive');
    } finally {
      setDownloadingType(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in" id="zip-export-modal-overlay">
      <div className="bg-cyber-panel border border-cyan-500/40 w-full max-w-2xl text-slate-100 shadow-[0_0_30px_rgba(6,182,212,0.25)] flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="p-3.5 border-b border-slate-800 bg-[#0a0d14] flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="bg-cyan-950/60 border border-cyan-500 p-1.5 flex items-center justify-center">
              <Archive className="w-4 h-4 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-black tracking-widest text-slate-100 uppercase">
                  Tactical Deployment & Telemetry ZIP Exporter
                </h3>
                <span className="text-[8px] bg-cyan-950 border border-cyan-500/50 text-cyan-300 px-1.5 py-0.2 font-mono uppercase font-black">
                  .ZIP PACKAGE
                </span>
              </div>
              <p className="text-[9px] text-slate-400 font-mono tracking-tight">
                Archive and export the standalone tactical codebase or active incident and fleet datasets.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 font-mono text-xs">
          
          {downloadSuccess && (
            <div className="bg-emerald-950/40 border border-emerald-500/50 p-2.5 text-[10px] text-emerald-300 flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{downloadSuccess}</span>
            </div>
          )}

          {errorMessage && (
            <div className="bg-red-950/40 border border-red-500/50 p-2.5 text-[10px] text-red-300 flex items-center gap-2 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Option 1: Full Tactical Suite ZIP */}
          <div className="bg-[#0a0e18] border border-cyan-500/30 p-4 space-y-3 relative overflow-hidden group">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-cyan-950 border border-cyan-400 flex items-center justify-center shrink-0">
                  <Shield className="w-5 h-5 text-cyan-300" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                    Full Tactical Deployment Suite (.zip)
                    <span className="text-[8px] bg-cyan-950/80 border border-cyan-500 text-cyan-300 px-1 py-0.2">
                      OFFLINE READY
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Complete standalone bundle including Express backend, Vite frontend, autonomous fleet engines, PWA manifest, launcher scripts (<span className="text-cyan-400">install.sh</span>, <span className="text-cyan-400">install.bat</span>), and Docker configurations.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-[8.5px] text-slate-400 pt-1">
              <div className="bg-[#070a10] p-1.5 border border-slate-800 flex items-center gap-1.5">
                <Terminal className="w-3 h-3 text-cyan-400" />
                <span>1-Click Launchers</span>
              </div>
              <div className="bg-[#070a10] p-1.5 border border-slate-800 flex items-center gap-1.5">
                <Layers className="w-3 h-3 text-cyan-400" />
                <span>Sectors 7 • 8 • 9</span>
              </div>
              <div className="bg-[#070a10] p-1.5 border border-slate-800 flex items-center gap-1.5">
                <Database className="w-3 h-3 text-cyan-400" />
                <span>Subnet Override</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={handleDownloadFullZip}
                disabled={downloadingType === 'full'}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-[10px] font-black uppercase tracking-wider flex items-center gap-2 transition-colors shadow-[0_0_12px_rgba(6,182,212,0.3)] cursor-pointer disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{downloadingType === 'full' ? 'COMPRESSING & PACKAGING...' : 'DOWNLOAD FULL SUITE ZIP'}</span>
              </button>
            </div>
          </div>

          {/* Option 2: Telemetry & Incident Dump ZIP */}
          <div className="bg-[#0a0e18] border border-slate-800 p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5 text-slate-300" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                    Live Telemetry & Incident Logs Archive (.zip)
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Exports current operational data as structured datasets: formatted <span className="text-cyan-400">JSON</span> and <span className="text-cyan-400">CSV</span> files for incident history, system telemetry logs, active patrol unit coordinates, and sensor states.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[9px] text-slate-500 pt-1">
              <span>{incidents.length} Incidents • {logs.length} System Logs • {units.length} Fleet Units • {sensors.length} Sensors</span>
              <button
                onClick={handleDownloadTelemetryZip}
                disabled={downloadingType === 'telemetry'}
                className="px-4 py-2 bg-blue-950/50 hover:bg-blue-900/60 border border-cyber-blue text-cyber-blue text-[10px] font-black uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>{downloadingType === 'telemetry' ? 'EXPORTING DATA...' : 'EXPORT TELEMETRY ZIP'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-[#0a0d14] flex justify-between items-center text-[9px] text-slate-500 font-mono">
          <div>
            DEFLATE COMPRESSION ENGINE • MULTI-PLATFORM COMPATIBLE
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 uppercase font-black tracking-wider transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
