import React, { useState, useEffect } from 'react';
import { Incident, PatrolUnit, SensorFeed, SystemLog } from './types';
import TacticalGrid from './components/TacticalGrid';
import IncidentDispatcher from './components/IncidentDispatcher';
import SurveillanceFeeds from './components/SurveillanceFeeds';
import IncidentDatabase from './components/IncidentDatabase';
import SystemTelemetry from './components/SystemTelemetry';
import InstallerModal from './components/InstallerModal';
import ZipExportModal from './components/ZipExportModal';
import { Shield, Radio, Activity, Terminal, AlertTriangle, Play, Pause, Scan, Volume2, VolumeX, Layers, Lock, Cpu, Sparkles, Zap, Download, Archive } from 'lucide-react';
import { soundManager } from './utils/audio';

// Base fleet (Sector-7)
const BASE_UNITS: PatrolUnit[] = [
  {
    id: 'PATROL-12',
    name: 'Patrol Car 12',
    type: 'PATROL',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Sgt. Miller',
    coordinates: { x: 15, y: 25 },
    speed: 0,
    heading: 'N',
    sector: 'SECTOR-7'
  },
  {
    id: 'K9-03',
    name: 'K9 Team 03',
    type: 'K9',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Officer Chen & Jax',
    coordinates: { x: 75, y: 25 },
    speed: 0,
    heading: 'NE',
    sector: 'SECTOR-7'
  },
  {
    id: 'SWAT-ALPHA',
    name: 'SWAT Alpha',
    type: 'SWAT',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Cmdr. Vance',
    coordinates: { x: 50, y: 55 },
    speed: 0,
    heading: 'S',
    sector: 'SECTOR-7'
  },
  {
    id: 'AIR-SUPPORT',
    name: 'Falcon Air Unit',
    type: 'AIR_SUPPORT',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Pilot Ross',
    coordinates: { x: 80, y: 80 },
    speed: 0,
    heading: 'W',
    sector: 'SECTOR-7'
  }
];

// Expanded fleet (Sectors 7, 8, 9)
const EXPANDED_UNITS: PatrolUnit[] = [
  ...BASE_UNITS,
  {
    id: 'DRONE-X1',
    name: 'Skyway Recon UAV',
    type: 'DRONE',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Drone Pilot Silva',
    coordinates: { x: 35, y: 15 },
    speed: 0,
    heading: 'E',
    sector: 'SECTOR-7'
  },
  {
    id: 'SWAT-BRAVO',
    name: 'BearCat Tactical Assault',
    type: 'SWAT',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Officer Kowalski',
    coordinates: { x: 70, y: 45 },
    speed: 0,
    heading: 'SW',
    sector: 'SECTOR-8'
  },
  {
    id: 'MARINE-07',
    name: 'Harbor Tactical Cutter',
    type: 'MARINE',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Capt. Sterling',
    coordinates: { x: 85, y: 65 },
    speed: 0,
    heading: 'NW',
    sector: 'SECTOR-8'
  },
  {
    id: 'MCU-COMMAND',
    name: 'Mobile Command Unit',
    type: 'PATROL',
    status: 'IDLE',
    assignedIncidentId: null,
    officer: 'Det. Morales',
    coordinates: { x: 25, y: 80 },
    speed: 0,
    heading: 'N',
    sector: 'SECTOR-9'
  }
];

// Base sensor matrix (Sector-7)
const BASE_SENSORS: SensorFeed[] = [
  {
    id: 'CAM-101',
    name: 'CAM_101',
    type: 'CAMERA',
    location: 'Downtown Plaza Square',
    lastDetectedText: 'Normal pedestrian transit.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 20, y: 40 },
    sector: 'SECTOR-7'
  },
  {
    id: 'CAM-402',
    name: 'CAM_42',
    type: 'CAMERA',
    location: 'Jewelry District Alley',
    lastDetectedText: 'Static feed. Standard illumination.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 45, y: 20 },
    sector: 'SECTOR-7'
  },
  {
    id: 'AUDIO-901',
    name: 'AUDIO_09',
    type: 'AUDIO',
    location: 'Residential Sector West',
    lastDetectedText: 'Ambient sound levels nominal.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 85, y: 45 },
    sector: 'SECTOR-7'
  },
  {
    id: 'CAM-203',
    name: 'CAM_203',
    type: 'CAMERA',
    location: 'Subway Main Terminal',
    lastDetectedText: 'Transit passenger density clear.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 30, y: 75 },
    sector: 'SECTOR-7'
  }
];

// Expanded sensor matrix (Sectors 7, 8, 9)
const EXPANDED_SENSORS: SensorFeed[] = [
  ...BASE_SENSORS,
  {
    id: 'CAM-808',
    name: 'CAM_808 [FLIR]',
    type: 'THERMAL',
    location: 'Harbor Container Slip 4',
    lastDetectedText: 'Infrared scan: standard thermal dissipations.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 80, y: 60 },
    sector: 'SECTOR-8'
  },
  {
    id: 'UAV-FEED-01',
    name: 'UAV Sky-Eye 4K',
    type: 'DRONE',
    location: 'Waterfront Perimeter Skyway',
    lastDetectedText: 'Airborne optical sweep unobstructed.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 65, y: 35 },
    sector: 'SECTOR-8'
  },
  {
    id: 'ANPR-302',
    name: 'ANPR_302',
    type: 'ANPR',
    location: 'Highway Interchange Toll Gate',
    lastDetectedText: 'Automated plate reader: no active stolen flags.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 25, y: 65 },
    sector: 'SECTOR-9'
  },
  {
    id: 'SONAR-501',
    name: 'SONAR_501 [SEISMIC]',
    type: 'AUDIO',
    location: 'Tech Park Power Substation',
    lastDetectedText: 'Substation acoustic perimeter calibrated.',
    riskScore: 0.0,
    timestamp: '11:00:00',
    status: 'CLEAR',
    coordinates: { x: 40, y: 85 },
    sector: 'SECTOR-9'
  }
];

const INITIAL_LOGS: SystemLog[] = [
  {
    id: 'log-1',
    timestamp: new Date().toLocaleTimeString(),
    source: 'SYSTEM',
    message: 'Active Police AI Core Online: Synchronizing Tactical Knowledge Base.',
    type: 'INFO'
  },
  {
    id: 'log-2',
    timestamp: new Date().toLocaleTimeString(),
    source: 'EXPANSION',
    message: 'FULL EXPANSION SUITE ACTIVE: Sectors 7, 8, and 9 synchronized. Drone recon and thermal FLIR online.',
    type: 'CRITICAL'
  },
  {
    id: 'log-3',
    timestamp: new Date().toLocaleTimeString(),
    source: 'OVERRIDE',
    message: 'TACTICAL GATEWAY OVERRIDE [192.168.1.1]: Ports 22/80/443 bypassed. Full root privileges verified.',
    type: 'CRITICAL'
  }
];

const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'INC-39182',
    text: 'Acoustic peaks flagged verbal shouting on Westside subway platform.',
    category: 'Disturbance',
    priority: 'NORMAL',
    status: 'RESOLVED',
    threatScore: 28,
    timestamp: '10:14:55',
    recommendedAction: 'ROUTE GENERAL PATROL VEHICLE FOR ADVISAL AND DISPERSION',
    assignedUnits: ['PATROL-12'],
    summary: 'Minor auditory confrontation reported. Resolved verbally with no active threats.',
    coordinates: { x: 30, y: 75 },
    sector: 'SECTOR-7'
  },
  {
    id: 'INC-41092',
    text: 'Subnet gateway router 192.168.1.1 accessed with direct root administrative override.',
    category: 'Cyber Tactical Override',
    priority: 'HIGH',
    status: 'DISPATCHED',
    threatScore: 88,
    timestamp: new Date().toLocaleTimeString(),
    recommendedAction: 'MONITOR TELEMETRY MATRIX AND MAINTAIN ROOT SUBNET CONTROL',
    assignedUnits: ['DRONE-X1'],
    summary: 'Gateway 192.168.1.1 active override confirmed. All sector nodes running on prioritized telemetry.',
    coordinates: { x: 35, y: 15 },
    sector: 'SECTOR-7'
  }
];

export default function App() {
  const [isFullExpansion, setIsFullExpansion] = useState(true);
  const [overriddenIPs, setOverriddenIPs] = useState<string[]>(['192.168.1.1']);
  const [units, setUnits] = useState<PatrolUnit[]>(EXPANDED_UNITS);
  const [sensors, setSensors] = useState<SensorFeed[]>(EXPANDED_SENSORS);
  const [incidents, setIncidents] = useState<Incident[]>(INITIAL_INCIDENTS);
  const [logs, setLogs] = useState<SystemLog[]>(INITIAL_LOGS);

  const [serverConfig, setServerConfig] = useState({
    status: 'connecting',
    aiEngine: 'LOCAL_KAIZEN_HEURISTICS',
    geminiActive: false,
    precinct: 'Sector-7'
  });

  const [selectedUnit, setSelectedUnit] = useState<PatrolUnit | null>(null);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [isSimulating, setIsSimulating] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [scanningSensorId, setScanningSensorId] = useState<string | null>(null);
  const [isGridExpanded, setIsGridExpanded] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isInstallerOpen, setIsInstallerOpen] = useState(false);
  const [isZipExportOpen, setIsZipExportOpen] = useState(false);

  // Fetch server configuration on mount
  useEffect(() => {
    fetch('/api/config')
      .then(res => res.json())
      .then(data => {
        setServerConfig(data);
        addLog(`System sync complete. Active Engine: ${data.aiEngine}. Multi-Sector Expansion Ready.`, 'INFO', 'SYSTEM');
      })
      .catch(err => {
        console.error("Config fetch failed:", err);
        addLog(`Server telemetry offline. Running local client-side tactical rules.`, 'ALERT', 'SYSTEM');
      });
  }, []);

  const addLog = (
    message: string,
    type: 'INFO' | 'ALERT' | 'CRITICAL',
    source: 'SYSTEM' | 'AI' | 'SENSOR' | 'DISPATCH' | 'OVERRIDE' | 'EXPANSION' = 'SYSTEM'
  ) => {
    const newLog: SystemLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toLocaleTimeString(),
      source,
      message,
      type
    };
    setLogs(prev => [...prev, newLog]);
  };

  // Toggle Full Expansion Suite
  const toggleFullExpansion = () => {
    if (isFullExpansion) {
      // Turn off expansion: revert to base units and sensors
      setIsFullExpansion(false);
      setUnits(BASE_UNITS);
      setSensors(BASE_SENSORS);
      soundManager.playBlip();
      addLog('Expansion Suite Deactivated: Reverting fleet and sensors to Sector-7 perimeter.', 'INFO', 'EXPANSION');
    } else {
      // Turn on full expansion
      setIsFullExpansion(true);
      setUnits(EXPANDED_UNITS);
      setSensors(EXPANDED_SENSORS);
      if (!overriddenIPs.includes('192.168.1.1')) {
        setOverriddenIPs(prev => [...prev, '192.168.1.1']);
      }
      soundManager.playExpansionEngaged();
      addLog('FULL EXPANSION SUITE ENGAGED: Multi-Sector matrix (S7, S8, S9) deployed. Drone Skyway, Marine Cutter, and Thermal FLIR online.', 'CRITICAL', 'EXPANSION');
    }
  };

  // Sound toggle
  const toggleMute = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
    if (!muted) soundManager.playBlip();
  };

  // Simulate vehicle movement when units are RESPONDING to incidents
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setUnits(prevUnits => {
        return prevUnits.map(unit => {
          if (unit.status === 'RESPONDING' && unit.assignedIncidentId) {
            const incident = incidents.find(i => i.id === unit.assignedIncidentId);
            if (incident) {
              const dx = incident.coordinates.x - unit.coordinates.x;
              const dy = incident.coordinates.y - unit.coordinates.y;
              const distance = Math.sqrt(dx * dx + dy * dy);

              // Step speed based on unit type
              let speedValue = unit.type === 'DRONE' ? 14 : unit.type === 'AIR_SUPPORT' ? 12 : unit.type === 'MARINE' ? 10 : unit.type === 'SWAT' ? 6 : 8;
              let stepSize = speedValue / 4;

              if (distance <= stepSize) {
                setTimeout(() => {
                  soundManager.playChirp();
                  addLog(`PATROL UPDATE: ${unit.name} on scene at [${incident.coordinates.x}, ${incident.coordinates.y}]. Securing perimeter.`, 'INFO', 'DISPATCH');
                  
                  setUnits(currentUnits => 
                    currentUnits.map(cu => cu.id === unit.id ? { ...cu, status: 'ON_SCENE', speed: 0 } : cu)
                  );

                  setIncidents(currentIncidents =>
                    currentIncidents.map(ci => ci.id === incident.id ? { ...ci, status: 'ON SCENE' } : ci)
                  );
                }, 100);

                return {
                  ...unit,
                  coordinates: incident.coordinates,
                  speed: 0
                };
              } else {
                let heading = unit.heading;
                if (Math.abs(dx) > Math.abs(dy)) {
                  heading = dx > 0 ? 'E' : 'W';
                } else {
                  heading = dy > 0 ? 'S' : 'N';
                }

                const stepX = (dx / distance) * stepSize;
                const stepY = (dy / distance) * stepSize;

                return {
                  ...unit,
                  coordinates: {
                    x: Math.round((unit.coordinates.x + stepX) * 10) / 10,
                    y: Math.round((unit.coordinates.y + stepY) * 10) / 10
                  },
                  speed: speedValue * 5,
                  heading
                };
              }
            }
          }
          return unit;
        });
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimulating, incidents]);

  // Handle sensor intrusion injection
  const handleSensorIntrusion = async (feedId: string, text: string) => {
    try {
      soundManager.playBlip();
      const response = await fetch('/api/sensor-risk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feedId, text }),
      });

      if (!response.ok) {
        throw new Error('Sensor risk evaluation failed');
      }

      const data = await response.json();

      setSensors(prevSensors =>
        prevSensors.map(sensor =>
          sensor.id === feedId
            ? {
                ...sensor,
                riskScore: data.riskScore,
                status: data.status,
                lastDetectedText: text,
                timestamp: new Date().toLocaleTimeString()
              }
            : sensor
        )
      );

      if (data.status === 'CRITICAL') {
        soundManager.playAlarm();
        const autoIncidentId = `INC-${Math.floor(10000 + Math.random() * 90000)}`;
        const targetSensor = sensors.find(s => s.id === feedId);
        
        const autoIncident: Incident = {
          id: autoIncidentId,
          text: `AUTOMATED SENSOR ALERT: ${text} on feed ${feedId}`,
          category: 'Intrusion / Critical Hazard',
          priority: 'HIGH',
          status: 'PENDING',
          threatScore: Math.round(data.riskScore * 100),
          timestamp: new Date().toLocaleTimeString(),
          recommendedAction: 'IMMEDIATE TACTICAL INTERCEPT AND SCENE CONTAINMENT',
          assignedUnits: [],
          summary: `Automatic sensor trigger on ${feedId} (${targetSensor?.location || 'Sector'}). Risk: ${Math.round(data.riskScore * 100)}%.`,
          coordinates: targetSensor?.coordinates || { x: 50, y: 50 },
          sector: targetSensor?.sector || 'SECTOR-7'
        };

        setIncidents(prev => [autoIncident, ...prev]);
        addLog(`System auto-generated high-priority intercept target: ${autoIncidentId}`, 'CRITICAL', 'AI');
      } else if (data.status === 'WARNING') {
        soundManager.playChirp();
        addLog(`Surveillance Flagged: Warning at ${feedId} ("${text}"). Risk: ${Math.round(data.riskScore * 100)}%.`, 'ALERT', 'SENSOR');
      } else {
        addLog(`Surveillance Activity: Clear detection at ${feedId} ("${text}").`, 'INFO', 'SENSOR');
      }

    } catch (err) {
      console.error(err);
    }
  };

  // Confirm Dispatch & Route Units
  const handleDispatchConfirmed = (incidentData: Partial<Incident>, assignedUnitIds: string[]) => {
    soundManager.playDispatch();
    const newIncidentId = `INC-${Math.floor(10000 + Math.random() * 90000)}`;
    
    let chosenSector: 'SECTOR-7' | 'SECTOR-8' | 'SECTOR-9' = 'SECTOR-7';
    const lowerText = (incidentData.text || '').toLowerCase();
    
    if (lowerText.includes('sector-8') || lowerText.includes('harbor') || lowerText.includes('dock') || lowerText.includes('pier') || lowerText.includes('cutter') || lowerText.includes('marine')) {
      chosenSector = 'SECTOR-8';
    } else if (lowerText.includes('sector-9') || lowerText.includes('tech') || lowerText.includes('substation') || lowerText.includes('highway') || lowerText.includes('toll')) {
      chosenSector = 'SECTOR-9';
    } else if (assignedUnitIds.length > 0) {
      const matchedUnit = units.find(u => u.id === assignedUnitIds[0]);
      if (matchedUnit?.sector) {
        chosenSector = matchedUnit.sector;
      }
    }

    let sectorCoords = {
      x: Math.floor(20 + Math.random() * 35),
      y: Math.floor(20 + Math.random() * 30)
    };

    if (chosenSector === 'SECTOR-8') {
      sectorCoords = {
        x: Math.floor(65 + Math.random() * 23),
        y: Math.floor(35 + Math.random() * 35)
      };
    } else if (chosenSector === 'SECTOR-9') {
      sectorCoords = {
        x: Math.floor(20 + Math.random() * 25),
        y: Math.floor(65 + Math.random() * 23)
      };
    }

    const newIncident: Incident = {
      id: newIncidentId,
      text: incidentData.text || '',
      category: incidentData.category || 'General Incident',
      priority: incidentData.priority || 'NORMAL',
      status: 'DISPATCHED',
      threatScore: incidentData.threatScore || 15,
      timestamp: new Date().toLocaleTimeString(),
      recommendedAction: incidentData.recommendedAction || 'DISPATCH AREA PATROL',
      assignedUnits: assignedUnitIds,
      summary: incidentData.summary || 'Incident dispatched to units.',
      coordinates: sectorCoords,
      sector: chosenSector
    };

    setUnits(prevUnits =>
      prevUnits.map(unit =>
        assignedUnitIds.includes(unit.id)
          ? {
              ...unit,
              status: 'RESPONDING',
              assignedIncidentId: newIncidentId,
              speed: 45,
              heading: 'N'
            }
          : unit
      )
    );

    setIncidents(prev => [newIncident, ...prev]);
  };

  // Resolve Incident and Free Up Units
  const handleResolveIncident = (incidentId: string) => {
    soundManager.playBlip();
    setUnits(prevUnits =>
      prevUnits.map(unit =>
        unit.assignedIncidentId === incidentId
          ? {
              ...unit,
              status: 'IDLE',
              assignedIncidentId: null,
              speed: 0
            }
          : unit
      )
    );

    setIncidents(prev =>
      prev.map(inc => inc.id === incidentId ? { ...inc, status: 'RESOLVED' } : inc)
    );

    addLog(`INCIDENT RESOLVED: ${incidentId} marked clear. Assumed safe. Releasing units to vectors.`, 'INFO', 'DISPATCH');
    setSelectedIncident(null);
  };

  const handleFocusIncidentCoords = (coordinates: { x: number; y: number }) => {
    soundManager.playBlip();
    addLog(`RADAR FOCUS: Tracking coordinates [${coordinates.x}, ${coordinates.y}]`, 'INFO', 'SYSTEM');
  };

  // Auto Connect: pairs pending incidents with nearest idle patrol units
  const handleAutoConnect = () => {
    soundManager.playDispatch();
    const pendingIncidents = incidents.filter(inc => inc.status === 'PENDING');
    
    if (pendingIncidents.length === 0) {
      addLog("AUTO-CONNECT SCAN: No pending unassigned threats across sectors.", "INFO", "SYSTEM");
      return;
    }

    const idleUnits = units.filter(u => u.status === 'IDLE');
    if (idleUnits.length === 0) {
      addLog("AUTO-CONNECT SCAN: All patrol units are currently active.", "ALERT", "AI");
      return;
    }

    const dispatchedUnitIds: string[] = [];
    const updatedIncidents = incidents.map(incident => {
      if (incident.status === 'PENDING') {
        let closestUnit: PatrolUnit | null = null;
        let minDistance = Infinity;

        idleUnits.forEach(unit => {
          if (!dispatchedUnitIds.includes(unit.id)) {
            const dx = incident.coordinates.x - unit.coordinates.x;
            const dy = incident.coordinates.y - unit.coordinates.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < minDistance) {
              minDistance = distance;
              closestUnit = unit;
            }
          }
        });

        if (closestUnit) {
          const u: PatrolUnit = closestUnit;
          dispatchedUnitIds.push(u.id);
          addLog(`AUTO-CONNECT PAIR: Assigned ${u.name} to ${incident.id} (${incident.category}).`, "CRITICAL", "AI");
          return {
            ...incident,
            status: 'DISPATCHED',
            assignedUnits: [u.id]
          };
        }
      }
      return incident;
    });

    if (dispatchedUnitIds.length > 0) {
      setUnits(prevUnits =>
        prevUnits.map(unit => {
          if (dispatchedUnitIds.includes(unit.id)) {
            const incident = updatedIncidents.find(inc => inc.assignedUnits.includes(unit.id));
            return {
              ...unit,
              status: 'RESPONDING',
              assignedIncidentId: incident?.id || null,
              speed: 45,
              heading: 'N'
            };
          }
          return unit;
        })
      );
      setIncidents(updatedIncidents);
    }
  };

  // Auto Scan: Sweeps all sensors, runs automatic AI classification
  const handleAutoScan = async () => {
    if (isScanning) return;
    setIsScanning(true);
    soundManager.playChirp();
    addLog("COGNITIVE SWEEP INITIATED: Swarming camera, audio, thermal & drone matrix.", "INFO", "AI");

    for (let i = 0; i < sensors.length; i++) {
      const sensor = sensors[i];
      setScanningSensorId(sensor.id);
      addLog(`COGNITIVE SCANNING [${sensor.id}]: Sensor focus on ${sensor.location}.`, "INFO", "AI");
      
      await new Promise(resolve => setTimeout(resolve, 1200));

      const roll = Math.random();
      if (roll < 0.25) {
        const scenarios = [
          "weapon detected and shouting heard running east",
          "thermal hotspot intrusion detected at gateway line",
          "high-speed pursuit passing perimeter marker"
        ];
        const scenarioText = scenarios[Math.floor(Math.random() * scenarios.length)];
        await handleSensorIntrusion(sensor.id, scenarioText);
      } else if (roll < 0.5) {
        const scenarios = [
          "shouting and loitering individual",
          "acoustic peak warning near terminal",
          "loitering group moving past perimeter"
        ];
        const scenarioText = scenarios[Math.floor(Math.random() * scenarios.length)];
        await handleSensorIntrusion(sensor.id, scenarioText);
      } else {
        const scenarios = [
          "routine patrol passing clear",
          "standard pedestrian transit clear",
          "ambient telemetry nominal"
        ];
        const scenarioText = scenarios[Math.floor(Math.random() * scenarios.length)];
        await handleSensorIntrusion(sensor.id, scenarioText);
      }
    }

    setScanningSensorId(null);
    setIsScanning(false);
    addLog("COGNITIVE SWEEP COMPLETED: Multi-Sector array aligned and nominal.", "INFO", "AI");
  };

  // Manual Subnet Override (e.g. override 192.168.1.1)
  const handleOverrideIP = (ip: string) => {
    const cleanIP = ip.trim();
    if (!cleanIP) return;

    soundManager.playOverride();

    if (overriddenIPs.includes(cleanIP)) {
      addLog(`OVERRIDE CONSOLE: Target node [${cleanIP}] is already controlled.`, 'INFO', 'OVERRIDE');
      return;
    }

    setOverriddenIPs(prev => [...prev, cleanIP]);
    addLog(`BYPASS PROTOCOL: Initializing tactical exploit on gateway node [${cleanIP}]...`, 'CRITICAL', 'OVERRIDE');

    setTimeout(() => {
      addLog(`SECURITY INTEGRATION: Port scanner on [${cleanIP}]: 22, 80, 443 bypassed successfully.`, 'ALERT', 'OVERRIDE');
    }, 500);

    setTimeout(() => {
      addLog(`KAIZEN SHIELD: Injecting cognitive feedback loop. Routing bypass vectors.`, 'ALERT', 'OVERRIDE');
    }, 1000);

    setTimeout(() => {
      addLog(`OVERRIDE SECURE: Root shell accessed on gateway [${cleanIP}]. Multi-Sector sensors boosted to absolute priority.`, 'CRITICAL', 'OVERRIDE');
      
      setSensors(prevSensors => 
        prevSensors.map(sensor => {
          if (sensor.status === 'CLEAR') {
            return {
              ...sensor,
              status: 'WARNING',
              riskScore: 0.85,
              lastDetectedText: `OVERRIDDEN BY GATEWAY CONTROL [${cleanIP}]`
            };
          }
          return sensor;
        })
      );
    }, 1500);
  };

  const handleClearOverrides = () => {
    soundManager.playBlip();
    setOverriddenIPs([]);
    addLog("OVERRIDE CONSOLE: Releasing subnet manual overrides. Securing firewall ports.", "INFO", "OVERRIDE");
    
    setSensors(prevSensors =>
      prevSensors.map(sensor => {
        if (sensor.lastDetectedText.includes("OVERRIDDEN BY GATEWAY")) {
          return {
            ...sensor,
            status: 'CLEAR',
            riskScore: 0.0,
            lastDetectedText: 'Routine system check: Normal.'
          };
        }
        return sensor;
      })
    );
  };

  // Emergency lockdown trigger
  const handleTriggerLockdown = () => {
    soundManager.playAlarm();
    addLog("EMERGENCY LOCKDOWN INITIATED: All perimeter gates sealing. Units routed to defense stations.", "CRITICAL", "EXPANSION");
  };

  return (
    <div className="min-h-screen bg-cyber-bg text-slate-100 flex flex-col font-mono selection:bg-cyber-blue selection:text-white" id="main-hud-workspace">
      
      {/* Top HUD Status Banner */}
      <header className="bg-cyber-panel border-b border-slate-800 p-3 flex flex-wrap justify-between items-center relative overflow-hidden shrink-0 gap-2">
        <div className="absolute inset-x-0 bottom-0 h-[1px] bg-gradient-to-r from-transparent via-cyber-blue/35 to-transparent" />
        
        {/* Brand & App Title */}
        <div className="flex items-center gap-2.5">
          <div className="bg-[#0a0c12] border border-slate-800 p-2 rounded-none relative flex items-center justify-center shadow-[0_0_8px_rgba(59,130,246,0.15)]">
            <Shield className="w-5 h-5 text-cyber-blue animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-black tracking-widest text-slate-100 uppercase font-mono flex items-center gap-1.5 leading-none">
                Active Police AI Command Desk
              </h1>
              <span className="text-[8.5px] bg-cyber-bg border border-slate-800 text-cyber-blue rounded-none px-1.5 py-0.2 font-black uppercase">
                v2.5
              </span>
              {isFullExpansion && (
                <span className="text-[8px] bg-cyan-950/60 border border-cyan-400 text-cyan-300 rounded-none px-1.5 py-0.2 font-black uppercase tracking-wider animate-pulse flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-cyan-300" />
                  FULL EXPANSION ACTIVE
                </span>
              )}
            </div>
            <p className="text-[9.5px] text-slate-500 font-mono tracking-tight font-bold uppercase leading-none mt-1">
              Multi-Sector Tactical Matrix • Autonomous Fleet & Drone HUD
            </p>
          </div>
        </div>

        {/* Tactical Control Badges & Actions */}
        <div className="flex items-center flex-wrap gap-2 text-[9px] font-mono">
          {/* Sector Badge */}
          <div className="hidden sm:flex flex-col text-right leading-none border-r border-slate-800 pr-3">
            <span className="text-slate-500 font-bold uppercase text-[7.5px] mb-1">Coverage Scope</span>
            <span className="text-slate-200 font-black">
              {isFullExpansion ? 'SECTOR 7 • 8 • 9' : 'SECTOR 7 (LOCAL)'}
            </span>
          </div>

          {/* Subnet Gateway Badge */}
          <div className="hidden md:flex flex-col text-right leading-none border-r border-slate-800 pr-3">
            <span className="text-slate-500 font-bold uppercase text-[7.5px] mb-1">Gateway Control</span>
            <span className={`font-black flex items-center gap-1 ${overriddenIPs.includes('192.168.1.1') ? 'text-cyan-400' : 'text-slate-400'}`}>
              192.168.1.1 {overriddenIPs.includes('192.168.1.1') ? '[BYPASS]' : '[RESTRICTED]'}
            </span>
          </div>

          {/* Audio SFX Toggle */}
          <button
            onClick={toggleMute}
            className={`p-1.5 border text-[8.5px] font-bold uppercase flex items-center gap-1 transition-colors cursor-pointer ${
              isMuted
                ? 'bg-cyber-bg border-slate-800 text-slate-600 hover:text-slate-400'
                : 'bg-cyan-950/30 border-cyan-500/50 text-cyan-400'
            }`}
            title={isMuted ? 'Unmute tactical audio feedback' : 'Mute tactical audio feedback'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span>{isMuted ? 'MUTED' : 'SFX'}</span>
          </button>

          {/* Full Expansion Toggle Button */}
          <button
            onClick={toggleFullExpansion}
            className={`p-1.5 border text-[8.5px] font-black uppercase flex items-center gap-1 transition-colors cursor-pointer ${
              isFullExpansion
                ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                : 'bg-cyber-bg border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
            title="Toggle full expansion features (Sectors 7, 8, 9, UAV Drones, Marine, Thermal FLIR)"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isFullExpansion ? 'EXPANSION: ACTIVE' : 'ENABLE EXPANSION'}</span>
          </button>

          {/* Simulation Pause Button */}
          <button
            onClick={() => {
              soundManager.playBlip();
              setIsSimulating(!isSimulating);
            }}
            className={`p-1.5 border text-[8.5px] font-black uppercase flex items-center gap-1 transition-colors cursor-pointer ${
              isSimulating 
                ? 'bg-cyber-bg border-slate-800 text-amber-500 hover:border-amber-500/40' 
                : 'bg-blue-950/30 border-cyber-blue/60 text-cyber-blue'
            }`}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isSimulating ? 'Pause' : 'Resume'}</span>
          </button>

          {/* Auto Connect Button */}
          <button
            onClick={handleAutoConnect}
            className="p-1.5 border border-cyber-blue/50 bg-blue-950/20 text-cyber-blue hover:bg-blue-950/40 transition-colors cursor-pointer flex items-center gap-1 text-[8.5px] font-black uppercase shadow-[0_0_8px_rgba(59,130,246,0.2)]"
            title="Auto Connect pending threats to closest idle units"
          >
            <Activity className="w-3.5 h-3.5 animate-pulse text-cyber-blue" />
            <span>Connect</span>
          </button>

          {/* Auto Scan Button */}
          <button
            onClick={handleAutoScan}
            disabled={isScanning}
            className={`p-1.5 border text-[8.5px] font-black uppercase flex items-center gap-1 transition-colors cursor-pointer shadow-[0_0_8px_rgba(6,182,212,0.2)] ${
              isScanning 
                ? 'bg-cyan-950/30 border-cyan-500/60 text-cyan-400 cursor-not-allowed'
                : 'border-cyan-500/40 bg-cyan-950/20 text-cyan-400 hover:bg-cyan-950/40'
            }`}
            title="Auto Scan all sensor nodes"
          >
            <Scan className={`w-3.5 h-3.5 text-cyan-400 ${isScanning ? 'animate-spin' : 'animate-pulse'}`} />
            <span>{isScanning ? 'Scanning...' : 'Scan'}</span>
          </button>

          {/* Installer Button */}
          <button
            onClick={() => {
              soundManager.playInstallPrompt();
              setIsInstallerOpen(true);
            }}
            className="p-1.5 border border-emerald-500/50 bg-emerald-950/30 text-emerald-400 hover:bg-emerald-950/50 transition-colors cursor-pointer flex items-center gap-1 text-[8.5px] font-black uppercase shadow-[0_0_8px_rgba(16,185,129,0.25)]"
            title="Open PWA App Installer & Standalone Setup"
            id="open-installer-btn"
          >
            <Download className="w-3.5 h-3.5 text-emerald-300" />
            <span>Installer</span>
          </button>

          {/* ZIP File Export Button */}
          <button
            onClick={() => {
              soundManager.playDownloadSuccess();
              setIsZipExportOpen(true);
            }}
            className="p-1.5 border border-purple-500/50 bg-purple-950/30 text-purple-300 hover:bg-purple-950/50 transition-colors cursor-pointer flex items-center gap-1 text-[8.5px] font-black uppercase shadow-[0_0_8px_rgba(168,85,247,0.25)]"
            title="Download Deployment ZIP Archive & Incident History"
            id="open-zip-export-btn"
          >
            <Archive className="w-3.5 h-3.5 text-purple-300" />
            <span>ZIP File</span>
          </button>
        </div>
      </header>

      {/* Main dashboard body */}
      <main className="flex-1 p-3 sm:p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 overflow-y-auto">
        
        {/* Left Column - Radar & Telemetry (Columns: 7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="flex-1 min-h-[380px]">
            <TacticalGrid
              units={units}
              incidents={incidents}
              sensors={sensors}
              selectedUnit={selectedUnit}
              onSelectUnit={setSelectedUnit}
              selectedIncident={selectedIncident}
              onSelectIncident={setSelectedIncident}
              isScanning={isScanning}
              scanningSensorId={scanningSensorId}
              isExpanded={isGridExpanded}
              onToggleExpand={() => setIsGridExpanded(!isGridExpanded)}
              isFullExpansion={isFullExpansion}
            />
          </div>
          
          <div className="h-auto">
            <SystemTelemetry
              logs={logs}
              units={units}
              geminiActive={serverConfig.geminiActive}
              aiEngine={serverConfig.aiEngine}
              overriddenIPs={overriddenIPs}
              onExecuteOverride={handleOverrideIP}
              onClearOverrides={handleClearOverrides}
              onToggleFullExpansion={toggleFullExpansion}
              isFullExpansion={isFullExpansion}
              onTriggerLockdown={handleTriggerLockdown}
              onAutoScan={handleAutoScan}
              onAutoConnect={handleAutoConnect}
              onOpenInstaller={() => setIsInstallerOpen(true)}
              onOpenZipExport={() => setIsZipExportOpen(true)}
            />
          </div>
        </div>

        {/* Right Column - Dispatcher & Feeds (Columns: 5) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="flex-shrink-0">
            <IncidentDispatcher
              availableUnits={units}
              onDispatchConfirmed={handleDispatchConfirmed}
              geminiActive={serverConfig.geminiActive}
              onAddLog={addLog}
            />
          </div>

          <div className="flex-1 flex flex-col gap-4">
            <div className="flex-1">
              <SurveillanceFeeds
                feeds={sensors}
                onTriggerIntrusion={handleSensorIntrusion}
                onAddLog={addLog}
              />
            </div>

            <div className="flex-1">
              <IncidentDatabase
                incidents={incidents}
                onResolveIncident={handleResolveIncident}
                selectedIncident={selectedIncident}
                onSelectIncident={setSelectedIncident}
                onFocusIncidentCoords={handleFocusIncidentCoords}
              />
            </div>
          </div>
        </div>

      </main>

      {/* Low-profile bottom HUD info line */}
      <footer className="bg-cyber-panel border-t border-slate-800 py-1.5 px-4 flex justify-between items-center text-[8px] text-slate-500 font-mono tracking-widest uppercase shrink-0">
        <div>
          ACTIVE POLICE AI TAC-NET • PROTOCOLS: KAIZEN & ARCHANGEL • {isFullExpansion ? 'EXPANDED 3-SECTOR MESH' : 'SECTOR-7 ISOLATED'}
        </div>
        <div className="hidden sm:block">
          AUTHORIZATION LEVEL: TAC-4 ROOT • SUBNET 192.168.1.0/24
        </div>
      </footer>

      {/* Standalone Installer Modal */}
      <InstallerModal
        isOpen={isInstallerOpen}
        onClose={() => setIsInstallerOpen(false)}
      />

      {/* Tactical ZIP Export Modal */}
      <ZipExportModal
        isOpen={isZipExportOpen}
        onClose={() => setIsZipExportOpen(false)}
        incidents={incidents}
        units={units}
        sensors={sensors}
        logs={logs}
      />

    </div>
  );
}
