# Active Police AI - Tactical Command Desk v2.5

Real-time multi-sector incident response and tactical dispatch HUD powered by Active Police AI.

## Quick Installation & Launch

### Option 1: One-Click Installer Script
- **macOS / Linux**:
  ```bash
  chmod +x install.sh
  ./install.sh
  ```
- **Windows**:
  Double-click `install.bat` or run:
  ```cmd
  install.bat
  ```

### Option 2: Manual Node.js Launch
1. Ensure Node.js 18+ is installed.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the Command Desk:
   ```bash
   npm run dev
   ```
4. Open your browser at:
   `http://localhost:3000`

### Option 3: Docker Deployment
```bash
docker-compose up --build -d
```

## Features
- Multi-Sector Radar Matrix (Sectors 7, 8, and 9)
- Autonomous 8-Unit Patrol Fleet (Patrol, K9, SWAT, UAV Drones, Marine Cutters)
- Multi-Spectrum Sensor Grid (Optical, FLIR Thermal, ANPR, Acoustic Sonar)
- Subnet Gateway 192.168.1.1 Root Override
- Full Offline Progressive Web App (PWA) Support
