#!/usr/bin/env bash
echo "Launching Active Police AI Command Desk..."
npm run dev
