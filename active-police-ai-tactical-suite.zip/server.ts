import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import JSZip from "jszip";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey.trim() !== "") {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
      console.log("🤖 Gemini AI Client initialized successfully.");
    } else {
      console.log("ℹ️ No valid GEMINI_API_KEY found. Falling back to local heuristic engines.");
    }
  }
  return aiClient;
}

// Local rule-based incident classifier fallback (Kaizen/Vigilance simulation)
function classifyIncidentLocally(text: string) {
  const lowercase = text.toLowerCase();
  
  // Threat indicators
  const robberyWords = ["rob", "robbery", "steal", "jewelry", "bank", "vault", "jewelry store", "burglar", "break into", "theft"];
  const assaultWords = ["assault", "fight", "altercation", "attack", "hit", "shove", "beat", "stab", "weapon", "gun", "knife", "pistol", "shoot"];
  const disturbanceWords = ["loud", "music", "shout", "scream", "noise", "disturbance", "complaint", "party", "loitering"];
  const emergencyWords = ["fire", "accident", "crash", "heart", "medical", "ambulance", "dying", "hurt"];

  let category = "General Incident";
  let priority: 'HIGH' | 'NORMAL' = "NORMAL";
  let threatScore = 15;
  let recommendedAction = "DISPATCH REGULAR PATROL UNIT FOR SCENE INVESTIGATION";
  let summary = "Patrol dispatched to evaluate scene and establish initial reporting.";
  let suggestedUnits = ["PATROL"];

  const hasWord = (words: string[]) => words.some(w => lowercase.includes(w));

  if (hasWord(assaultWords)) {
    category = "Assault";
    priority = "HIGH";
    threatScore = 85;
    recommendedAction = "TACTICAL INTERCEPT: DISPATCH SWAT AND PARMEDICS. SECURE APPREHENSION CAPABILITY.";
    summary = "Critical threat level: physical altercation/weapons detected. Emergency armed units dispatched.";
    suggestedUnits = ["SWAT", "PATROL"];
  } else if (hasWord(robberyWords)) {
    category = "Robbery / Theft";
    priority = lowercase.includes("jewelry") || lowercase.includes("bank") || lowercase.includes("break") ? "HIGH" : "NORMAL";
    threatScore = priority === "HIGH" ? 75 : 45;
    recommendedAction = "ESTABLISH PARKING PERIMETER AND DISPATCH FIELD RESPONSE UNITS FOR ACQUISITION LOCKDOWN.";
    summary = "Active property invasion or robbery reported. Mobilize intercept patrols to intercept fleeing suspects.";
    suggestedUnits = priority === "HIGH" ? ["PATROL", "K9"] : ["PATROL"];
  } else if (hasWord(emergencyWords)) {
    category = "Emergency";
    priority = "HIGH";
    threatScore = 90;
    recommendedAction = "URGENT FIRST-RESPONDER ROUTING. DISPATCH MEDIC AND COORDINATE SAFETY CORRIDORS.";
    summary = "High-priority life safety hazard. Coordinating emergency response teams to stabilize victims.";
    suggestedUnits = ["PATROL"];
  } else if (hasWord(disturbanceWords)) {
    category = "Disturbance";
    priority = "NORMAL";
    threatScore = 30;
    recommendedAction = "DISPATCH PATROL OFFICER TO ADVISE RESOLUTION AND RESTORE ORDER.";
    summary = "Acoustic anomaly or active minor disturbance reported. Area patrol dispatched to advise compliance.";
    suggestedUnits = ["PATROL"];
  }

  return {
    category,
    priority,
    threatScore,
    recommendedAction,
    summary,
    suggestedUnits,
  };
}

// Calculate Risk Score for Sensor Feeds (GuardianAI Heuristics + Expansion Vectors)
function calculateSensorRiskScore(metadata: string): { riskScore: number; status: 'CLEAR' | 'WARNING' | 'CRITICAL' } {
  const lowercase = metadata.toLowerCase();
  const weights: Record<string, number> = {
    weapon: 0.9,
    shouting: 0.4,
    running: 0.3,
    loitering: 0.1,
    breach: 0.85,
    hostage: 0.95,
    explosion: 0.95,
    pursuit: 0.75,
    thermal: 0.7,
    intruder: 0.7,
    unauthorized: 0.5,
    override: 0.8,
    speeding: 0.4,
    tamper: 0.65
  };
  
  // Split metadata and calculate threat score sum
  const words = lowercase.split(/\s+/);
  let score = 0;
  for (const word of words) {
    // Clean up punctuation
    const cleanWord = word.replace(/[^a-z]/g, "");
    if (weights[cleanWord] !== undefined) {
      score += weights[cleanWord];
    }
  }
  
  const riskScore = Math.min(score, 1.0);
  let status: 'CLEAR' | 'WARNING' | 'CRITICAL' = "CLEAR";
  if (riskScore >= 0.75) {
    status = "CRITICAL";
  } else if (riskScore >= 0.3) {
    status = "WARNING";
  }

  return {
    riskScore,
    status
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Endpoint: Check connection and config state
  app.get("/api/config", (req: Request, res: Response) => {
    const hasKey = !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY";
    res.json({
      status: "online",
      aiEngine: hasKey ? "GEMINI_3.5_FLASH" : "LOCAL_KAIZEN_HEURISTICS",
      geminiActive: hasKey,
      precinct: "Sector-7 / Expanded Multi-Sector Matrix",
      expansionFeaturesAvailable: true,
      expansionVectors: ["SECTOR-7", "SECTOR-8", "SECTOR-9"]
    });
  });

  // API Endpoint: Analyze Incident report
  app.post("/api/analyze-incident", async (req: Request, res: Response) => {
    const { text } = req.body;
    
    if (!text || typeof text !== "string" || text.trim() === "") {
      res.status(400).json({ error: "Incident text must be a valid non-empty string" });
      return;
    }

    const ai = getAIClient();
    if (!ai) {
      // Local Heuristic Fallback
      const result = classifyIncidentLocally(text);
      res.json({
        ...result,
        source: "LOCAL_HEURISTICS"
      });
      return;
    }

    try {
      console.log(`🤖 Invoking Gemini to analyze incident: "${text}"`);
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Analyze the following raw incident description or emergency call transcript. Extract key tactical dispatch attributes into the specified JSON format.
        
Incident Description: "${text}"`,
        config: {
          systemInstruction: `You are the Active Police AI system core (Guardian-9, Sector-7 tactical dispatcher). 
Your directive is absolute precision, vigilance, and safety.
Analyze the incident carefully. Determine if there is physical danger, weapons, or intrusion.
Keep the "recommendedAction" short, operational, and in uppercase (e.g. 'DEPLOY SWAT & ESTABLISH PERIMETER').
Keep the "summary" as a dense, professional sitrep, strictly literal and serious (no flowery or dramatic language, write like a seasoned command officer).`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              category: { 
                type: Type.STRING, 
                description: "Incident class (e.g., Robbery, Assault, Theft, Disturbance, Emergency, Traffic Accident, Fire)" 
              },
              priority: { 
                type: Type.STRING, 
                description: "Priority rating. Must be exactly 'HIGH' or 'NORMAL'." 
              },
              threatScore: { 
                type: Type.INTEGER, 
                description: "Numeric threat assessment score between 0 and 100 based on hazard." 
              },
              recommendedAction: { 
                type: Type.STRING, 
                description: "Command directives, uppercase operational task. (e.g., DEPLOY SWAT, DISPATCH PATROL, DISPATCH PARAMEDICS)" 
              },
              summary: { 
                type: Type.STRING, 
                description: "A highly specific, concise tactical situational summary of the incident details." 
              },
              suggestedUnits: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Suggested unit categories to deploy, e.g. ['SWAT', 'PATROL'], ['PATROL', 'K9'], or ['AIR_SUPPORT', 'PATROL']."
              }
            },
            required: ["category", "priority", "threatScore", "recommendedAction", "summary", "suggestedUnits"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Empty response from Gemini API");
      }

      const cleanJson = responseText.trim();
      const parsed = JSON.parse(cleanJson);

      // Clean up priority formatting if model deviates
      let finalPriority: 'HIGH' | 'NORMAL' = "NORMAL";
      if (parsed.priority && parsed.priority.toUpperCase() === "HIGH") {
        finalPriority = "HIGH";
      }

      res.json({
        category: parsed.category || "General Incident",
        priority: finalPriority,
        threatScore: Math.max(0, Math.min(100, parsed.threatScore || 15)),
        recommendedAction: parsed.recommendedAction || "DISPATCH STANDARD PATROL AREA UNIT",
        summary: parsed.summary || "Assessing scene report.",
        suggestedUnits: parsed.suggestedUnits || ["PATROL"],
        source: "GEMINI_AI"
      });

    } catch (error) {
      console.error("⚠️ Gemini API Call failed. Falling back to local heuristic analysis:", error);
      const result = classifyIncidentLocally(text);
      res.json({
        ...result,
        source: "LOCAL_HEURISTICS_FALLBACK",
        error: error instanceof Error ? error.message : "API Call failed"
      });
    }
  });

  // API Endpoint: Analyze Sensor Feed Metadata (GuardianAI Simulation & Sensor Risk)
  const handleSensorRisk = (req: Request, res: Response) => {
    const text = req.body.text || req.body.metadata || "";
    if (typeof text !== "string") {
      res.status(400).json({ error: "Sensor text or metadata string is required" });
      return;
    }

    const assessment = calculateSensorRiskScore(text);
    res.json({
      feedId: req.body.feedId || null,
      metadata: text,
      text,
      ...assessment,
      timestamp: new Date().toLocaleTimeString()
    });
  };

  app.post("/api/analyze-sensor", handleSensorRisk);
  app.post("/api/sensor-risk", handleSensorRisk);

  // Expansion features status endpoint
  app.get("/api/expansion/status", (req: Request, res: Response) => {
    res.json({
      expansionActive: true,
      sectors: ["SECTOR-7", "SECTOR-8", "SECTOR-9"],
      fleetUnits: 8,
      sensorFeeds: 8,
      droneTelemetry: "ACTIVE",
      thermalInfrared: "CALIBRATED",
      gatewayNode: "192.168.1.1",
      bypassedPorts: [22, 80, 443, 8080],
      status: "NOMINAL"
    });
  });

  // Helper to recursively collect files for zip archive
  function addDirectoryToZip(zip: JSZip, dirPath: string, prefix: string = "") {
    if (!fs.existsSync(dirPath)) return;
    const entries = fs.readdirSync(dirPath);
    for (const entry of entries) {
      if (
        entry === "node_modules" ||
        entry === ".git" ||
        entry === "dist" ||
        entry === ".cache" ||
        entry === ".DS_Store"
      ) {
        continue;
      }
      const fullPath = path.join(dirPath, entry);
      const zipPath = prefix ? `${prefix}/${entry}` : entry;
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirectoryToZip(zip, fullPath, zipPath);
      } else {
        zip.file(zipPath, fs.readFileSync(fullPath));
      }
    }
  }

  // API Endpoint: Download Full Tactical Suite ZIP Archive
  app.get("/api/download-zip", async (req: Request, res: Response) => {
    try {
      const zip = new JSZip();
      const rootDir = process.cwd();

      // Add project directories
      addDirectoryToZip(zip, path.join(rootDir, "src"), "src");
      addDirectoryToZip(zip, path.join(rootDir, "public"), "public");

      // Add top-level config & source files
      const rootFiles = [
        "package.json",
        "server.ts",
        "index.html",
        "vite.config.ts",
        "tsconfig.json",
        "metadata.json",
        ".env.example"
      ];

      for (const fileName of rootFiles) {
        const filePath = path.join(rootDir, fileName);
        if (fs.existsSync(filePath)) {
          zip.file(fileName, fs.readFileSync(filePath));
        }
      }

      // Add automated local installer & launcher scripts
      zip.file(
        "install.sh",
        `#!/usr/bin/env bash
set -e
echo "=========================================================="
echo "    ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       "
echo "=========================================================="
echo "Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js 18+ is required. Install from https://nodejs.org"
    exit 1
fi
echo "Installing dependencies..."
npm install
echo "Building tactical production bundles..."
npm run build
echo "Installation complete!"
echo "Starting Active Police AI Tactical Desk on port 3000..."
npm run dev
`
      );

      zip.file(
        "install.bat",
        `@echo off
echo ==========================================================
echo     ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       
echo ==========================================================
echo Checking Node.js environment...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js not found. Please install Node.js 18+ from https://nodejs.org
    pause
    exit /b 1
)
echo Installing dependencies...
call npm install
echo Building application...
call npm run build
echo Launching Tactical Command Desk on http://localhost:3000...
call npm run dev
pause
`
      );

      zip.file(
        "start.sh",
        `#!/usr/bin/env bash
echo "Launching Active Police AI Command Desk..."
npm run dev
`
      );

      zip.file(
        "start.bat",
        `@echo off
echo Launching Active Police AI Command Desk on http://localhost:3000...
npm run dev
`
      );

      zip.file(
        "Dockerfile",
        `FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
`
      );

      zip.file(
        "docker-compose.yml",
        `version: '3.8'
services:
  police-ai-tactical:
    build: .
    ports:
      - "3000:3000"
    restart: unless-stopped
    environment:
      - NODE_ENV=production
`
      );

      zip.file(
        "README.md",
        `# Active Police AI - Tactical Command Desk v2.5

Real-time multi-sector incident response and tactical dispatch HUD powered by Active Police AI.

## Quick Installation & Launch

### Option 1: One-Click Installer Script
- **macOS / Linux**:
  \`\`\`bash
  chmod +x install.sh
  ./install.sh
  \`\`\`
- **Windows**:
  Double-click \`install.bat\` or run:
  \`\`\`cmd
  install.bat
  \`\`\`

### Option 2: Manual Node.js Launch
1. Ensure Node.js 18+ is installed.
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Start the Command Desk:
   \`\`\`bash
   npm run dev
   \`\`\`
4. Open your browser at:
   \`http://localhost:3000\`

### Option 3: Docker Deployment
\`\`\`bash
docker-compose up --build -d
\`\`\`

## Features
- Multi-Sector Radar Matrix (Sectors 7, 8, and 9)
- Autonomous 8-Unit Patrol Fleet (Patrol, K9, SWAT, UAV Drones, Marine Cutters)
- Multi-Spectrum Sensor Grid (Optical, FLIR Thermal, ANPR, Acoustic Sonar)
- Subnet Gateway 192.168.1.1 Root Override
- Full Offline Progressive Web App (PWA) Support
`
      );

      const buffer = await zip.generateAsync({
        type: "nodebuffer",
        compression: "DEFLATE",
        compressionOptions: { level: 6 }
      });

      res.setHeader(
        "Content-Disposition",
        'attachment; filename="active-police-ai-tactical-suite.zip"'
      );
      res.setHeader("Content-Type", "application/zip");
      res.send(buffer);
    } catch (err: any) {
      console.error("ZIP Generation error:", err);
      res.status(500).json({ error: "Failed to create deployment ZIP archive", details: err.message });
    }
  });

  // API Endpoint: Export Incident & Telemetry Dump as ZIP
  app.post("/api/download-telemetry-zip", async (req: Request, res: Response) => {
    try {
      const { incidents = [], logs = [], units = [], sensors = [] } = req.body;
      const zip = new JSZip();
      const timestamp = new Date().toISOString().replace(/[:.]/g, "-");

      // Save raw JSON
      zip.file("incidents.json", JSON.stringify(incidents, null, 2));
      zip.file("system-logs.json", JSON.stringify(logs, null, 2));
      zip.file("units.json", JSON.stringify(units, null, 2));
      zip.file("sensors.json", JSON.stringify(sensors, null, 2));

      // Build formatted CSV for incidents
      const incidentHeaders = "ID,Category,Priority,Status,ThreatScore,Sector,Timestamp,Summary\n";
      const incidentRows = (incidents as any[]).map(inc => 
        `"${inc.id}","${inc.category}","${inc.priority}","${inc.status}",${inc.threatScore},"${inc.sector}","${inc.timestamp}","${(inc.summary || '').replace(/"/g, '""')}"`
      ).join("\n");
      zip.file("incidents.csv", incidentHeaders + incidentRows);

      // Build formatted CSV for logs
      const logHeaders = "Timestamp,Source,Type,Message\n";
      const logRows = (logs as any[]).map(log => 
        `"${log.timestamp}","${log.source}","${log.type}","${(log.message || '').replace(/"/g, '""')}"`
      ).join("\n");
      zip.file("system-logs.csv", logHeaders + logRows);

      // Manifest
      zip.file("export-manifest.txt", `ACTIVE POLICE AI - TELEMETRY ARCHIVE\nTimestamp: ${new Date().toLocaleString()}\nTotal Incidents: ${incidents.length}\nTotal Logs: ${logs.length}\nFleet Units: ${units.length}\nSensors: ${sensors.length}\nSubnet Gateway: 192.168.1.1\n`);

      const buffer = await zip.generateAsync({
        type: "nodebuffer",
        compression: "DEFLATE"
      });

      res.setHeader(
        "Content-Disposition",
        `attachment; filename="police-ai-telemetry-${timestamp}.zip"`
      );
      res.setHeader("Content-Type", "application/zip");
      res.send(buffer);
    } catch (err: any) {
      console.error("Telemetry ZIP Export error:", err);
      res.status(500).json({ error: "Failed to export telemetry ZIP archive" });
    }
  });

  // Serve static UI using Vite / express static
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🛡️ Active Police AI server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("❌ Failed to start Active Police AI server:", err);
});
