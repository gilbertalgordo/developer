@echo off
echo ==========================================================
echo     ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       
echo ==========================================================
echo Checking Node.js environment...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js not found. Please install Node.js 18+ from https://nodejs.org
    pause
    exit /b 1
)
echo Installing dependencies...
call npm install
echo Building application...
call npm run build
echo Launching Tactical Command Desk on http://localhost:3000...
call npm run dev
pause
