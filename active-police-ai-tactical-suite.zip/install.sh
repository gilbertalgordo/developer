#!/usr/bin/env bash
set -e
echo "=========================================================="
echo "    ACTIVE POLICE AI COMMAND DESK - LOCAL INSTALLER       "
echo "=========================================================="
echo "Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js 18+ is required. Install from https://nodejs.org"
    exit 1
fi
echo "Installing dependencies..."
npm install
echo "Building tactical production bundles..."
npm run build
echo "Installation complete!"
echo "Starting Active Police AI Tactical Desk on port 3000..."
npm run dev
