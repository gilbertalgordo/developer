#!/usr/bin/env bash
# ==============================================================================
# UNLIMITED STUDIO API & MEDIA ENGINE - AUTOMATED INSTALLER
# ==============================================================================
# Veo 3.1 Video Generation Workstation & Neural Audio Engine
# Target Port: 3000
# ==============================================================================

set -e

# Visual colors
CYAN='\033[0;36m'
EMERALD='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}"
echo "  _   _ _   _ _     ___ __  __ ___ _____ _____ ____  "
echo " | | | | \ | | |   |_ _|  \/  |_ _|_   _| ____|  _ \ "
echo " | | | |  \| | |    | || |\/| || |  | | |  _| | | | |"
echo " | |_| | |\  | |___ | || |  | || |  | | | |___| |_| |"
echo "  \___/|_| \_|_____|___|_|  |_|___| |_| |_____|____/ "
echo "   >>> UNLIMITED STUDIO API & MEDIA ENGINE <<<       "
echo -e "${NC}"

echo -e "${CYAN}[1/5] Checking environment & system dependencies...${NC}"

# Check for Node.js
if ! command -v node >/dev/null 2>&1; then
    echo -e "${RED}Error: Node.js is not installed.${NC}"
    echo "Please install Node.js v20.x or higher: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${AMBER}Warning: Node.js version $NODE_VERSION detected. Node.js 20+ is recommended.${NC}"
else
    echo -e "${EMERALD}✓ Node.js $(node -v) verified${NC}"
fi

# Check for npm
if ! command -v npm >/dev/null 2>&1; then
    echo -e "${RED}Error: npm is not installed.${NC}"
    exit 1
fi
echo -e "${EMERALD}✓ npm $(npm -v) verified${NC}"

echo -e "${CYAN}[2/5] Configuring environment variables...${NC}"
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        echo -e "${EMERALD}✓ Created .env from .env.example${NC}"
    else
        cat <<EOF > .env
PORT=3000
GEMINI_API_KEY=
NODE_ENV=production
ZERO_BILLING_MODE=true
EOF
        echo -e "${EMERALD}✓ Generated new .env configuration${NC}"
    fi
else
    echo -e "${AMBER}Notice: Existing .env file detected, preserving configuration.${NC}"
fi

echo -e "${CYAN}[3/5] Installing project dependencies with npm...${NC}"
npm install

echo -e "${CYAN}[4/5] Compiling production build (Vite & Express server)...${NC}"
npm run build

echo -e "${CYAN}[5/5] Finalizing deployment & permissions...${NC}"
chmod +x ./start.sh 2>/dev/null || true

echo -e "${EMERALD}"
echo "=============================================================================="
echo "✓ UNLIMITED STUDIO SUCCESSFULLY INSTALLED!"
echo "=============================================================================="
echo -e "${NC}"
echo -e "To launch the engine now, run:"
echo -e "  ${CYAN}npm start${NC}  or  ${CYAN}./start.sh${NC}"
echo ""
echo -e "Studio will be live at: ${CYAN}http://localhost:3000${NC}"
echo -e "To configure your Gemini API Key for Veo 3.1 video generation, edit: ${AMBER}.env${NC}"
echo "=============================================================================="
