@echo off
TITLE Unlimited Studio API & Media Engine - Setup
COLOR 0B

echo ==============================================================================
echo   UNLIMITED STUDIO API & MEDIA ENGINE - WINDOWS INSTALLER
echo ==============================================================================
echo.

echo [1/4] Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    COLOR 0C
    echo Error: Node.js is not installed or not in PATH!
    echo Please install Node.js 20+ from https://nodejs.org/
    pause
    exit /b 1
)

node -v
echo [OK] Node.js detected.
echo.

echo [2/4] Setting up environment configuration...
if not exist .env (
    if exist .env.example (
        copy .env.example .env >nul
        echo [OK] Created .env from .env.example
    ) else (
        (
            echo PORT=3000
            echo GEMINI_API_KEY=
            echo NODE_ENV=production
            echo ZERO_BILLING_MODE=true
        ) > .env
        echo [OK] Generated .env file
    )
) else (
    echo [OK] Existing .env file found.
)
echo.

echo [3/4] Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    COLOR 0C
    echo [ERROR] npm install failed.
    pause
    exit /b 1
)
echo.

echo [4/4] Building production bundles...
call npm run build
if %errorlevel% neq 0 (
    COLOR 0C
    echo [ERROR] Build failed.
    pause
    exit /b 1
)

COLOR 0A
echo.
echo ==============================================================================
echo   INSTALLATION COMPLETED SUCCESSFULLY!
echo ==============================================================================
echo.
echo Launching Unlimited Studio on http://localhost:3000 ...
echo Press Ctrl+C anytime to stop the server.
echo.
call npm start
pause
