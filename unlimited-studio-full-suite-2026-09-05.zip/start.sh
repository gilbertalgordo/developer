#!/usr/bin/env bash
# Unlimited Studio Runner
export PORT=${PORT:-3000}
export NODE_ENV=${NODE_ENV:-production}

echo "Starting Unlimited Studio API & Media Engine on port $PORT..."
if [ -f "dist/server.cjs" ]; then
    node dist/server.cjs
else
    echo "Running build first..."
    npm run build
    node dist/server.cjs
fi
