# Unlimited Studio API & Media Engine

A boundless media expansion engine, Google Veo 3.1 video generation workstation, companion procedural neural audio synthesizer, telemetry HUD, and unlimited API orchestration suite.

## 🚀 Quick Start

### Option 1: Automated Shell Installer (macOS & Linux)
```bash
chmod +x ./install.sh
./install.sh
```

### Option 2: Automated Batch Installer (Windows)
Double-click `install.bat` or run:
```cmd
install.bat
```

### Option 3: Manual Setup
```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env and insert your GEMINI_API_KEY (optional, zero-billing mode works offline)

# 3. Build & Run
npm run build
npm start
```
The application will launch on `http://localhost:3000`.

### Option 4: Docker & Docker Compose
```bash
docker-compose up --build
```

## 🛠️ Key Capabilities
- **Veo 3.1 Studio**: Real-time Google Veo 3.1 Fast/Lite video generation with asynchronous operation polling.
- **Infinite Media Expansion Engine**: Latent frame chaining outpainting forward & reverse, optical flow interpolation, and resolution expansion.
- **Procedural Neural Audio DSP**: Web Audio API Solfeggio harmonic drone synthesizer and pure binary WAV buffer exporter.
- **Auto-Connect Real-Time Gateway**: Micro-services cluster diagnostics with sub-5ms heartbeat ping daemon.
- **Deep Engine Auto-Scan**: 5-point hardware tensor and memory pipeline auditor.
- **OpenAPI & YAML Spec**: Complete endpoint documentation and curl / python code samples.

## 🔑 Environment Variables
| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port for HTTP/2 & WebSocket server | `3000` |
| `GEMINI_API_KEY` | Google Gemini & Veo 3.1 API Key | `""` (triggers Zero-Billing mode) |
| `NODE_ENV` | Environment mode | `production` |
| `ZERO_BILLING_MODE` | Procedural fallback without billing | `true` |
