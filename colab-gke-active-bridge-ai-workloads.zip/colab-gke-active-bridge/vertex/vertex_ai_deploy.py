# ==============================================================================
# Vertex AI Deployment Pipeline: Upload Model Artifacts & Deploy Endpoint
# ==============================================================================

import os
from google.cloud import aiplatform

PROJECT_ID = "my-gcp-ai-project"
REGION = "us-central1"
DISPLAY_NAME = "colab-gke-active-ai-model"

print(f"Initializing Vertex AI SDK for project: {PROJECT_ID} in region {REGION}...")
aiplatform.init(project=PROJECT_ID, location=REGION)

# Upload Model to Vertex AI Model Registry
print("Uploading model artifact to Vertex AI Model Registry...")
model = aiplatform.Model.upload(
    display_name=DISPLAY_NAME,
    artifact_uri=os.environ.get("MODEL_ARTIFACT_GCS", f"gs://{PROJECT_ID}-ai-models/v2/"),
    serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/sklearn-cpu.0-24:latest"
)
print(f"Model created: {model.resource_name}")

# Deploy to high-availability Endpoint
print("Deploying model to Endpoint...")
endpoint = model.deploy(
    machine_type="n1-standard-4",
    min_replica_count=1,
    max_replica_count=2
)
print(f"Endpoint live: {endpoint.resource_name}")

# Verify with test instance prediction
prediction = endpoint.predict(instances=[[0.1, 0.2, 0.3]])
print("Test prediction response:", prediction)
