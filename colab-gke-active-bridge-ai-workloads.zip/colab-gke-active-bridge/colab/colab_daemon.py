# ==============================================================================
# Colab Daemon: Run this script inside a Google Colab GPU runtime notebook cell.
# Requirements:
#   !pip install -q fastapi uvicorn pyngrok pydantic
# ==============================================================================

import os
import threading
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from pyngrok import ngrok

app = FastAPI(
    title="Colab Active AI Daemon",
    description="GPU-accelerated inference backend connected to GKE Dispatcher",
    version="2.0.0"
)

# Optional: Set ngrok auth token if configured
NGROK_TOKEN = "" or os.environ.get("NGROK_AUTHTOKEN", "")
if NGROK_TOKEN:
    ngrok.set_auth_token(NGROK_TOKEN)

class InferencePayload(BaseModel):
    prompt: str
    temperature: float = 0.7
    max_tokens: int = 512

@app.get("/healthz")
async def health_check():
    return {"status": "ok", "runtime": "google-colab-gpu", "daemon_version": "2.0"}

@app.post("/api/v1/execute")
async def execute_task(req: InferencePayload):
    try:
        # User model inference hook:
        # Replace or augment this logic with your PyTorch / HuggingFace / Gemini model call.
        processed_result = f"[Colab GPU Engine] Successfully processed task prompt: '{req.prompt}'"
        
        return {
            "status": "success",
            "node": "google-colab-active-runtime",
            "processed_prompt": req.prompt,
            "output": processed_result,
            "telemetry": {
                "engine": "active-gpu-core",
                "allocated_memory": "Tesla T4 / A100 Active VRAM",
                "temperature": req.temperature,
                "max_tokens": req.max_tokens
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def start_server():
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")

if __name__ == "__main__":
    print("Starting Active Colab Daemon on port 8000...")
    # Open PyNgrok Tunnel
    tunnel = ngrok.connect(8000)
    print("=" * 60)
    print(f"🚀 ACTIVE COLAB TUNNEL URL: {tunnel.public_url}")
    print(f"   Copy this URL into your GKE SecretManager or installer config!")
    print("=" * 60)

    # Run in background daemon thread
    thread = threading.Thread(target=start_server, daemon=True)
    thread.start()
    print("FastAPI daemon is live and listening for GKE dispatches.")
