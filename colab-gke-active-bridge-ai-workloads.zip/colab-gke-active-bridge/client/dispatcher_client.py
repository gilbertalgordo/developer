#!/usr/bin/env python3
"""
Dispatcher Client Bridge
Connects upstream applications to the Colab & GKE Active AI bridge.
"""

import os
import requests
import json

class ColabBridgeClient:
    def __init__(self, endpoint_url: str = None):
        self.endpoint_url = (endpoint_url or os.environ.get("COLAB_TUNNEL_URL") or "https://colab-active-bridge.ngrok-free.app").rstrip("/")
        
    def execute(self, prompt: str, temperature: float = 0.7, max_tokens: int = 512):
        url = f"{self.endpoint_url}/api/v1/execute"
        headers = {"Content-Type": "application/json"}
        payload = {
            "prompt": prompt,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as err:
            return {
                "status": "error",
                "message": f"Bridge request failed: {str(err)}"
            }

if __name__ == "__main__":
    client = ColabBridgeClient()
    print(f"Connecting to: {client.endpoint_url}")
    result = client.execute("Perform active multi-token inference benchmark.")
    print("Response payload:")
    print(json.dumps(result, indent=2))
