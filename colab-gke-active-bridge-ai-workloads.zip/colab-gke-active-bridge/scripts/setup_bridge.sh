#!/usr/bin/env bash
# ==============================================================================
# Colab & GKE Active AI Bridge - Automated Deployment Installer
# Target GCP Project: my-gcp-ai-project
# Cluster: colab-ai-gke-cluster (us-central1)
# ==============================================================================

set -eo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

PROJECT_ID="${GCP_PROJECT_ID:-my-gcp-ai-project}"
CLUSTER_NAME="${GKE_CLUSTER:-colab-ai-gke-cluster}"
REGION="${GKE_REGION:-us-central1}"
NAMESPACE="ai-workloads"
SECRET_NAME="colab-bridge-secrets"
TUNNEL_URL="${COLAB_TUNNEL_URL:-https://colab-active-bridge.ngrok-free.app}"

echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}  Colab & GKE Active AI Bridge Installer v2.0         ${NC}"
echo -e "${BLUE}======================================================${NC}"
echo -e "Project ID  : ${GREEN}${PROJECT_ID}${NC}"
echo -e "Cluster     : ${GREEN}${CLUSTER_NAME} (${REGION})${NC}"
echo -e "Namespace   : ${GREEN}${NAMESPACE}${NC}"
echo -e "Tunnel URL  : ${GREEN}${TUNNEL_URL}${NC}"
echo ""

# 1. Prerequisite checks
echo -e "${BLUE}[1/6] Checking installed CLI dependencies...${NC}"
for cmd in gcloud kubectl docker; do
  if ! command -v "$cmd" &> /dev/null; then
    echo -e "${RED}Error: $cmd is not installed or not in PATH.${NC}"
    exit 1
  fi
  echo -e "  - $cmd: ${GREEN}OK${NC}"
done

# 2. Configure GCP project & enable required APIs
echo -e "${BLUE}[2/6] Configuring GCP Project & Enabling Services...${NC}"
gcloud config set project "${PROJECT_ID}"
gcloud services enable \
  container.googleapis.com \
  secretmanager.googleapis.com \
  aiplatform.googleapis.com \
  artifactregistry.googleapis.com

# 3. Authenticate to GKE Cluster
echo -e "${BLUE}[3/6] Fetching GKE cluster credentials...${NC}"
gcloud container clusters get-credentials "${CLUSTER_NAME}" --region "${REGION}"

# Create namespace if missing
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -

# 4. Provision SecretManager & k8s Secret
echo -e "${BLUE}[4/6] Synchronizing SecretManager tunnel credentials...${NC}"
if ! gcloud secrets describe "${SECRET_NAME}" &> /dev/null; then
  echo "Creating SecretManager secret '${SECRET_NAME}'..."
  gcloud secrets create "${SECRET_NAME}" --replication-policy="automatic"
fi

# Add secret version
echo -n "${TUNNEL_URL}" | gcloud secrets versions add "${SECRET_NAME}" --data-file=-
echo -e "  Secret '${SECRET_NAME}' version updated successfully."

# Mirror as Kubernetes Secret in namespace
kubectl create secret generic "${SECRET_NAME}" \
  --namespace="${NAMESPACE}" \
  --from-literal=tunnel-url="${TUNNEL_URL}" \
  --dry-run=client -o yaml | kubectl apply -f -

# 5. Apply Kubernetes Manifests
echo -e "${BLUE}[5/6] Deploying GKE Dispatcher Workload & Ingress...${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST_PATH="${SCRIPT_DIR}/../k8s/google_colab_gke.yaml"

if [ ! -f "$MANIFEST_PATH" ]; then
  MANIFEST_PATH="google_colab_gke.yaml"
fi

kubectl apply -f "$MANIFEST_PATH"

echo -e "Waiting for deployment pods to be ready..."
kubectl rollout status deployment/colab-gke-active-bridge -n "${NAMESPACE}" --timeout=120s

# 6. Verification smoke test
echo -e "${BLUE}[6/6] Verifying end-to-end inference routing...${NC}"
POD_NAME=$(kubectl get pods -n "${NAMESPACE}" -l app=colab-gke-bridge -o jsonpath='{.items[0].metadata.name}')
echo -e "Testing pod ${GREEN}${POD_NAME}${NC}..."

kubectl exec -n "${NAMESPACE}" "${POD_NAME}" -- curl -s -X POST http://localhost:8000/api/v1/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Self-check verification from automated installer", "temperature": 0.2}' || true

echo ""
echo -e "${GREEN}======================================================${NC}"
echo -e "${GREEN}  Bridge Successfully Installed & Deployed!           ${NC}"
echo -e "${GREEN}======================================================${NC}"
echo -e "Check ingress IP: ${YELLOW}kubectl get ingress -n ${NAMESPACE}${NC}"
echo -e "Monitor logs     : ${YELLOW}kubectl logs -f -n ${NAMESPACE} deployment/colab-gke-active-bridge${NC}"
