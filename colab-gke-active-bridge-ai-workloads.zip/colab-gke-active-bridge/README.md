# Colab & GKE Active AI Bridge

Complete hybrid deployment bundle connecting Google Colab GPU runtime instances to Google Kubernetes Engine (GKE) clusters and Vertex AI endpoints.

## Configured Parameters
- **GCP Project ID**: `my-gcp-ai-project`
- **GKE Cluster**: `colab-ai-gke-cluster` in `us-central1`
- **Kubernetes Namespace**: `ai-workloads`
- **Active Replicas**: `2`
- **Colab Tunnel URL**: `https://colab-active-bridge.ngrok-free.app`
- **SecretManager Secret**: `colab-bridge-secrets`

---

## 🚀 3-Step Quick Start

### Step 1: Launch Colab Daemon (in Google Colab)
1. Open a Google Colab notebook with **GPU hardware acceleration enabled**.
2. Run the code from `colab/colab_daemon.py`.
3. Note the generated public tunnel URL (e.g., `https://xxxx-xx-xx.ngrok-free.app`).

### Step 2: Run the Automated Installer
From your workstation or Cloud Shell:
```bash
chmod +x scripts/setup_bridge.sh
./scripts/setup_bridge.sh
```

The installer automatically:
- Validates GCP authentication and sets project `my-gcp-ai-project`
- Enables APIs: `container.googleapis.com`, `secretmanager.googleapis.com`, `aiplatform.googleapis.com`
- Fetches GKE credentials for `colab-ai-gke-cluster`
- Creates namespace `ai-workloads`
- Stores the active tunnel URL securely in GCP Secret Manager
- Applies `google_colab_gke.yaml` with `2` replicas
- Runs readiness checks against `/api/v1/execute`

### Step 3: Test Real-Time Inference
Query your live dispatcher using `dispatcher_client.py` or `curl`:
```bash
python3 client/dispatcher_client.py
```

Or via `curl`:
```bash
curl -X POST "http://<INGRESS_IP>/api/v1/execute" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Classify incoming real-time telemetry sensor records", "temperature": 0.5}'
```

---

## 📁 Package Structure
```
├── k8s/
│   ├── google_colab_gke.yaml   # Main GKE Deployment, Service, Ingress
│   └── k8s-secret.yaml         # Secret template
├── scripts/
│   └── setup_bridge.sh         # Executable bash installer
├── colab/
│   └── colab_daemon.py         # Colab notebook server
├── vertex/
│   └── vertex_ai_deploy.py     # Vertex AI endpoint rollout
├── client/
│   └── dispatcher_client.py    # Python inference client
├── docker/
│   └── Dockerfile              # Dispatcher container definition
├── docker-compose.yml          # Local runner
├── architecture_diagram.svg    # Scalable architecture vector
└── README.md                   # This documentation
```
